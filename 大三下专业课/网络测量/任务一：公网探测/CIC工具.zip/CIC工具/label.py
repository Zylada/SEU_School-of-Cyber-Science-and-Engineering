import pandas as pd
import glob
import os

# ---------------- 配置区域 ----------------
# 设置存放CSV文件的文件夹路径 (例如: './data' 或 'C:/Users/name/Documents')
folder_path = 'D:/26418/python code/feature'  # './' 表示当前脚本所在的文件夹
# 设置输出文件的名称
output_file = 'merged_result.csv'


# ----------------------------------------

def merge_csv_files():
    # 1. 获取文件夹下所有的 .csv 文件路径
    all_files = glob.glob(os.path.join(folder_path, "*.csv"))

    # 排除掉输出文件本身，防止死循环读取（如果输出文件也在同目录下）
    all_files = [f for f in all_files if not f.endswith(output_file)]

    if not all_files:
        print("未找到任何CSV文件！")
        return

    print(f"找到 {len(all_files)} 个文件，开始合并...")

    # 2. 读取所有文件并存入列表
    df_list = []
    for filename in all_files:
        try:
            # 读取csv
            df = pd.read_csv(filename)
            df_list.append(df)
            print(f"已读取: {filename}")
        except Exception as e:
            print(f"读取文件 {filename} 失败: {e}")

    # 3. 合并数据
    if df_list:
        # ignore_index=True 表示重置索引，不保留原文件的索引
        combined_df = pd.concat(df_list, ignore_index=True)

        # 4. 保存为新文件
        # encoding='utf-8-sig' 可以解决Excel打开中文乱码的问题
        combined_df.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"\n成功合并！文件已保存为: {output_file}")
        print(f"总行数: {len(combined_df)}")
    else:
        print("没有可合并的数据。")


if __name__ == "__main__":
    merge_csv_files()