# ===== 方案1：特征精简（仅保留F值最高的5个特征）=====
# 基于之前的特征工程，但只使用 active_hours, num_isps, num_countries, night_ratio, ttl_cv
# 输出与高分作业标签的 NMI，并保存聚类结果

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import normalized_mutual_info_score

# ==================== 配置路径 ====================
base = r'C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question'
high_label_path = 'label-3.csv'   # 高分作业标签文件
# =================================================

# -------------------- 1. 读取原始数据 --------------------
print("正在读取原始数据...")
fqdn_all = pd.read_csv(f"{base}/fqdn.csv")
access_all = pd.read_csv(f"{base}/access.csv")
flint_all = pd.read_csv(f"{base}/flint.csv")
ip_v4 = pd.read_csv(f"{base}/ip.csv")
ip_v6 = pd.read_csv(f"{base}/ipv6.csv")
ip_all = pd.concat([ip_v4, ip_v6], ignore_index=True)
print(f"合并后 IP 信息表形状: {ip_all.shape}")

# -------------------- 2. 特征工程 --------------------
print("正在聚合 access 特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique'),
    active_hours=('hour', 'nunique'),
    request_variance=('request_cnt', 'var')
).reset_index()

# 夜间活动比例
access_all['night'] = access_all['hour'].between(2, 5).astype(int)
night_ratio = access_all.groupby('fqdn_no')['night'].mean().reset_index()
night_ratio.columns = ['fqdn_no', 'night_ratio']

print("正在聚合 flint 特征...")
flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean'),
    ttl_std=('ttl', 'std'),
    unique_resolved_values=('encoded_value', 'nunique')
).reset_index()
# TTL 变异系数
flint_feat['ttl_cv'] = flint_feat['ttl_std'] / (flint_feat['avg_ttl'] + 1e-6)

print("正在聚合 IP 特征...")
ip_info = ip_all[['encoded_ip', 'country', 'city', 'isp']]
access_with_ip = access_all.merge(ip_info, on='encoded_ip', how='left')
ip_feat = access_with_ip.groupby('fqdn_no').agg(
    num_countries=('country', 'nunique'),
    overseas_ratio=('country', lambda x: (x != '中国').mean()),
    num_cities=('city', 'nunique'),
    num_isps=('isp', 'nunique'),
    cloud_ratio=('isp', lambda x: x.str.lower().str.contains(
        'amazon|google|cloud|azure|tencent|aliyun', na=False).mean())
).reset_index()
ip_feat.fillna({'num_countries': 0, 'overseas_ratio': 0,
                'num_cities': 0, 'num_isps': 0, 'cloud_ratio': 0}, inplace=True)

# 拼接所有特征
features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features = features.merge(ip_feat, on='fqdn_no', how='left')
features = features.merge(night_ratio, on='fqdn_no', how='left')
features.fillna(0, inplace=True)
print(f"特征矩阵形状: {features.shape}")

# -------------------- 3. 读取高分标签用于评估（但不用于训练）--------------------
high_labels = pd.read_csv(high_label_path)
data_with_label = features.merge(high_labels, on='fqdn_no', how='inner')
print(f"合并后用于评估的样本数: {len(data_with_label)}")

# -------------------- 4. 特征精简：只保留5个高F值特征 --------------------
selected_features = ['active_hours', 'num_isps', 'num_countries', 'night_ratio', 'ttl_cv']
print(f"\n使用的特征: {selected_features}")

# 数据预处理
X = features[selected_features].copy()
# 对计数类特征做对数变换
for col in ['num_isps', 'num_countries']:
    X[col] = np.log1p(X[col])
# 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# -------------------- 5. KMeans 聚类 (K=5) --------------------
print("\n===== KMeans 聚类 =====")
kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
kmeans_labels = kmeans.fit_predict(X_scaled)

# 与高分作业标签对比 NMI
pred_df = pd.DataFrame({'fqdn_no': features['fqdn_no'], 'pred': kmeans_labels})
merged = data_with_label[['fqdn_no', 'label']].merge(pred_df, on='fqdn_no')
nmi = normalized_mutual_info_score(merged['label'], merged['pred'])
print(f"特征精简方案 NMI: {nmi:.4f}")

# -------------------- 6. 保存结果 --------------------
features['label'] = kmeans_labels
submit = features[['fqdn_no', 'label']]
submit.to_csv('result_scheme1.csv', index=False)
print("\n结果已保存为 result_scheme1.csv")
print("各簇数量分布：")
print(submit['label'].value_counts().sort_index())