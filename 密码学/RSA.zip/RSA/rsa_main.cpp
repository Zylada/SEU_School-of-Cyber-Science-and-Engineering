#include <miracl.h>  
using namespace std;

void generateKeys(miracl* mip, big p, big q, big n, big e, big d) 
{

    big phi, tmp;
    mirsys(1024, 0); // 初始化Miracl系统  
    random(p, mip->getrand()); // 生成大素数p  
    random(q, mip->getrand()); // 生成大素数q  
    mul(n, p, q); // 计算n=pq  
    sub(phi, p, mirconst(1)); // 计算φ(n)中的p-1  
    sub(tmp, q, mirconst(1)); // 计算φ(n)中的q-1  
    mul(phi, phi, tmp); // 计算φ(n)=(p-1)(q-1)  
    invmod(d, e, phi); // 计算d，满足ed≡1(mod φ(n))  
    miracl::iobase = 10; // 设置输出基数为10  
}

big encrypt(big m, big e, big n) 
{
    big c;
    powmod(c, m, e, n); // 计算c=m^e(mod n)  
    return c;
}

big decrypt(big c, big d, big n)
{
    big m;
    powmod(m, c, d, n); // 计算m=c^d(mod n)  
    return m;
}

big homomorphicProperty(big m1, big m2, big e, big n) 
{
    big c1 = encrypt(m1, e, n); // 加密第一个消息  
    big c2 = encrypt(m2, e, n); // 加密第二个消息  
    big c_prod;
    mul(c_prod, c1, c2); // 计算密文的乘积  
    big m_prod = decrypt(c_prod, d, n); // 解密密文的乘积  
    return m_prod;
}