import struct

from BasicPacketInfo import BasicPacketInfo
from utils import IdGenerator


class PacketReader:
    """
    Read packets from a PCAP file and convert supported IPv4 TCP/UDP packets
    into BasicPacketInfo instances.
    """

    ETHERNET_HEADER_LEN = 14
    IPV4_ETHER_TYPE = b"\x08\x00"
    TCP_PROTOCOL = 6
    UDP_PROTOCOL = 17

    def __init__(self, filename):
        with open(filename, "rb") as open_file:
            self.pcapData = open_file.read()

        self.pcapLen = len(self.pcapData)
        self.pcapPtr = 24

        if self.pcapData[0:4] == b"\xa1\xb2\xc3\xd4":
            self.typeI = "!I"
        else:
            self.typeI = "I"

        # Network headers are always parsed in network byte order.
        self.typeH = "!H"

        self.generator = IdGenerator()
        self.totGen = IdGenerator()

    def nextPacket(self):
        """
        Return the next supported IPv4 TCP/UDP packet as BasicPacketInfo.
        """

        packetInfo = None

        while self.pcapPtr < self.pcapLen:
            self.totGen.nextId()

            if self.pcapPtr + 16 > self.pcapLen:
                break

            timeHigh = struct.unpack(
                self.typeI, self.pcapData[self.pcapPtr : self.pcapPtr + 4]
            )[0]
            timeLow = struct.unpack(
                self.typeI, self.pcapData[self.pcapPtr + 4 : self.pcapPtr + 8]
            )[0]
            timeStamp = 1000000 * timeHigh + timeLow

            caplen = struct.unpack(
                self.typeI, self.pcapData[self.pcapPtr + 8 : self.pcapPtr + 12]
            )[0]

            self.pcapPtr += 16

            packetData = self.pcapData[self.pcapPtr : self.pcapPtr + caplen]
            self.pcapPtr += caplen

            if self.isSupportedIpv4Packet(packetData):
                packetInfo = self.getIpv4Info(packetData, timeStamp)
                if packetInfo is not None:
                    break

        return packetInfo

    def isSupportedIpv4Packet(self, packetData):
        if len(packetData) < self.ETHERNET_HEADER_LEN + 20:
            return False

        if packetData[12:14] != self.IPV4_ETHER_TYPE:
            return False

        packetIp = packetData[self.ETHERNET_HEADER_LEN :]
        if (packetIp[0] >> 4) != 4:
            return False

        ipHeadLen = (packetIp[0] & 0x0F) << 2
        if len(packetIp) < ipHeadLen or ipHeadLen < 20:
            return False

        return packetIp[9] in (self.TCP_PROTOCOL, self.UDP_PROTOCOL)

    def getIpv4Info(self, packetData, timeStamp):
        packetIp = packetData[self.ETHERNET_HEADER_LEN :]
        ipHeadLen = (packetIp[0] & 0x0F) << 2
        protocol = packetIp[9]

        totalLength = struct.unpack(self.typeH, packetIp[2:4])[0]
        if totalLength >= ipHeadLen:
            packetIp = packetIp[: min(totalLength, len(packetIp))]

        if len(packetIp) < ipHeadLen:
            return None

        srcIP = ".".join(str(i) for i in packetIp[12:16])
        dstIP = ".".join(str(i) for i in packetIp[16:20])
        packetTransport = packetIp[ipHeadLen:]

        if protocol == self.TCP_PROTOCOL:
            return self.getTcpInfo(packetTransport, timeStamp, srcIP, dstIP, protocol)

        if protocol == self.UDP_PROTOCOL:
            return self.getUdpInfo(packetTransport, timeStamp, srcIP, dstIP, protocol)

        return None

    def getTcpInfo(self, packetTCP, timeStamp, srcIP, dstIP, protocol):
        if len(packetTCP) < 20:
            return None

        srcPort = struct.unpack(self.typeH, packetTCP[0:2])[0]
        dstPort = struct.unpack(self.typeH, packetTCP[2:4])[0]
        tcpHeadLen = (packetTCP[12] & 0xF0) >> 2

        if tcpHeadLen < 20 or len(packetTCP) < tcpHeadLen:
            return None

        flags = packetTCP[13]
        windowSize = struct.unpack(self.typeH, packetTCP[14:16])[0]
        payload = packetTCP[tcpHeadLen:]

        return self.buildPacketInfo(
            srcIP=srcIP,
            dstIP=dstIP,
            srcPort=srcPort,
            dstPort=dstPort,
            protocol=protocol,
            timeStamp=timeStamp,
            headBytes=tcpHeadLen,
            payload=payload,
            flags=flags,
            tcpWindow=windowSize,
        )

    def getUdpInfo(self, packetUDP, timeStamp, srcIP, dstIP, protocol):
        if len(packetUDP) < 8:
            return None

        srcPort = struct.unpack(self.typeH, packetUDP[0:2])[0]
        dstPort = struct.unpack(self.typeH, packetUDP[2:4])[0]
        udpLength = struct.unpack(self.typeH, packetUDP[4:6])[0]

        payloadEnd = len(packetUDP)
        if udpLength >= 8:
            payloadEnd = min(len(packetUDP), udpLength)

        payload = packetUDP[8:payloadEnd]

        return self.buildPacketInfo(
            srcIP=srcIP,
            dstIP=dstIP,
            srcPort=srcPort,
            dstPort=dstPort,
            protocol=protocol,
            timeStamp=timeStamp,
            headBytes=8,
            payload=payload,
            flags=0,
            tcpWindow=0,
        )

    def buildPacketInfo(
        self,
        srcIP,
        dstIP,
        srcPort,
        dstPort,
        protocol,
        timeStamp,
        headBytes,
        payload,
        flags,
        tcpWindow,
    ):
        return BasicPacketInfo(
            generator=self.generator,
            srcIP=srcIP,
            dstIP=dstIP,
            srcPort=srcPort,
            dstPort=dstPort,
            protocol=protocol,
            timeStamp=timeStamp,
            headBytes=headBytes,
            payloadBytes=len(payload),
            flags=flags,
            TCPWindow=tcpWindow,
            payload=payload,
        )
