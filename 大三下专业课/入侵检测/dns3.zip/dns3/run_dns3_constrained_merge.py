"""
DNS3 猜猜我是谁之域名大分类：约束微簇合并版。

本脚本对应大作业 PDF 中 DNS3 的无监督聚类任务：
1. 读取项目内 data/dns3 的 fqdn/access/flint/ip/ipv6 数据；
2. 从域名结构、访问时序、DNS 解析行为、解析 IP 地理/ISP 和共享解析资源图中提取特征；
3. 将结构化特征、类别特征和 encoded_fqdn 字符 n-gram 合并成统一向量；
4. 引入 DNS2 prediction_detail.csv 的黑白分数和图规则分数；
5. 按 DNS2 分数分成高风险、低风险和中间不确定层，再做层内聚类；
6. 以 dns2_split_k12 为主线做层内过聚类，得到更细的高/低风险微簇；
7. 将低度 flint 共享资源、CNAME 链、DNS2 分数相近性转成微簇图边；
8. 在微簇层面做约束合并，一次生成多组候选提交。

注意：data/dns3/label.csv 是题目给出的提交格式示例，只有少量样例行，不是训练标签。
因此代码不会把它当作监督学习标签使用。
"""

from __future__ import annotations

import argparse
import math
import os
import re
import warnings
import zipfile
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

# 当前 Windows/conda 环境里 loky 偶尔无法识别物理核心数。显式给一个保守值，
# 避免运行结束后输出无关 warning，不影响本脚本的主要计算逻辑。必须在导入 sklearn 前设置。
os.environ["LOKY_MAX_CPU_COUNT"] = os.environ.get("LOKY_MAX_CPU_COUNT") or "1"
warnings.filterwarnings("ignore", message="Could not find the number of physical cores.*", category=UserWarning)

import joblib
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.sparse.csgraph import connected_components
from sklearn.cluster import MiniBatchKMeans, SpectralClustering
from sklearn.decomposition import TruncatedSVD
from sklearn.impute import SimpleImputer
from sklearn.metrics import adjusted_rand_score, calinski_harabasz_score, normalized_mutual_info_score, silhouette_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer

RANDOM_STATE = 42
WORD_TOKEN_RE = re.compile(r"\[[^\]]+\]")
CATEGORICAL_COLS = ["tld", "flint_top_country", "flint_top_isp"]

# sklearn 1.8 对部分稀疏矩阵会提示特征名缺失。这里使用矩阵接口是有意为之，
# 屏蔽无关 warning 可以让运行日志更适合提交和复现实验。
warnings.filterwarnings("ignore", message="X does not have valid feature names.*", category=UserWarning)


@dataclass(frozen=True)
class ProjectPaths:
    """集中管理项目路径，保证从任意工作目录运行脚本都能定位到数据和输出。"""

    project_root: Path
    data_dir: Path
    output_dir: Path
    model_dir: Path


@dataclass(frozen=True)
class LowDegreeGraphContext:
    """低度 flint 资源图的组件、过滤边和统计信息。"""

    component_frame: pd.DataFrame
    filtered_edges: pd.DataFrame
    metrics: Dict[str, object]


@dataclass(frozen=True)
class CandidateResult:
    """单个候选提交的标签、明细和模型信息。"""

    name: str
    labels: np.ndarray
    model: Dict[str, object]
    sweep: pd.DataFrame
    detail_frame: pd.DataFrame
    metrics: Dict[str, object]


@dataclass(frozen=True)
class MergeConfig:
    """约束微簇合并的一组候选配置。"""

    name: str
    target_clusters: int
    high_micro_clusters: int
    low_micro_clusters: int
    graph_weight: float


class UnionFind:
    """轻量并查集，用于把共享低度解析资源的域名合并为图社区。"""

    def __init__(self, size: int) -> None:
        self.parent = np.arange(size, dtype=np.int64)
        self.rank = np.zeros(size, dtype=np.int8)

    def find(self, item: int) -> int:
        parent = int(self.parent[item])
        if parent != item:
            self.parent[item] = self.find(parent)
        return int(self.parent[item])

    def union(self, left: int, right: int) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root == right_root:
            return
        if self.rank[left_root] < self.rank[right_root]:
            self.parent[left_root] = right_root
        elif self.rank[left_root] > self.rank[right_root]:
            self.parent[right_root] = left_root
        else:
            self.parent[right_root] = left_root
            self.rank[left_root] += 1


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="DNS3 域名大分类：约束微簇合并版")
    parser.add_argument("--data-dir", type=Path, default=None, help="DNS3 数据目录，默认 data/dns3")
    parser.add_argument("--output-dir", type=Path, default=None, help="输出目录，默认 outputs_constrained_merge")
    parser.add_argument("--model-dir", type=Path, default=None, help="模型保存目录，默认 models_constrained_merge")
    parser.add_argument(
        "--dns2-detail",
        type=Path,
        default=None,
        help="DNS2 prediction_detail.csv，默认读取兄弟目录 完成dns2/outputs_ensemble_rank/tp1000/prediction_detail.csv",
    )
    parser.add_argument(
        "--cluster-count",
        type=int,
        default=None,
        help="固定聚类簇数；不填时从 --cluster-list 中按内部指标自动选择，且至少为 3。",
    )
    parser.add_argument(
        "--cluster-list",
        type=str,
        default="4,6,8,10,12,16,20,24,32",
        help="自动选簇时尝试的候选簇数，逗号分隔。题目要求簇数不能小于 3。",
    )
    parser.add_argument("--svd-components", type=int, default=72, help="SVD 降维维度，默认 72。")
    parser.add_argument("--tfidf-max-features", type=int, default=6000, help="域名字符 n-gram 最大特征数。")
    parser.add_argument("--access-chunksize", type=int, default=1_000_000, help="access.csv 分块读取行数。")
    parser.add_argument("--high-risk-count", type=int, default=1000, help="DNS2 高置信恶意层域名数量，默认 1000。")
    parser.add_argument("--middle-risk-count", type=int, default=2000, help="高风险层之后划入中间不确定层的数量，默认 2000。")
    parser.add_argument("--high-clusters", type=int, default=10, help="高置信恶意层内部聚类簇数，默认 10。")
    parser.add_argument("--low-clusters", type=int, default=12, help="低风险白域名层内部聚类簇数，默认 12。")
    parser.add_argument("--graph-min-degree", type=int, default=2, help="低度资源图保留的最小资源度，默认 2。")
    parser.add_argument("--graph-max-degree", type=int, default=30, help="低度资源图保留的最大资源度，默认 30，以上视为公共资源。")
    parser.add_argument(
        "--graph-large-component-size",
        type=int,
        default=900,
        help="低度资源图组件超过该规模时先按行为特征细分，默认 900。",
    )
    parser.add_argument(
        "--graph-split-size",
        type=int,
        default=500,
        help="大图组件细分时每个子组件的目标规模，默认 500。",
    )
    parser.add_argument(
        "--config-list",
        type=str,
        default="k12_h18_l42_g3.0,k14_h20_l48_g3.0,k16_h22_l54_g3.0,k18_h24_l60_g3.2,k20_h28_l68_g3.4",
        help="约束合并候选配置，格式 k目标簇_h高风险微簇_l低风险微簇_g图权重，逗号分隔。",
    )
    parser.add_argument(
        "--refine-large-targets",
        type=str,
        default="",
        help="可选：对超大最终簇做二次切分的目标最大簇大小，逗号分隔，如 4500,3500。默认不生成二次切分版。",
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="快速自检模式，只读取 access/flint/ip 的部分行，生成的结果不应用于正式提交。",
    )
    parser.add_argument("--quick-rows", type=int, default=250_000, help="quick 模式每个大表最多读取的行数。")
    parser.add_argument("--silhouette-sample", type=int, default=5000, help="内部轮廓系数抽样大小。")
    parser.add_argument("--no-zip", action="store_true", help="只生成 CSV，不额外生成 submission_dns3.zip。")
    return parser.parse_args()


def build_paths(args: argparse.Namespace) -> ProjectPaths:
    project_root = Path(__file__).resolve().parents[1]
    data_dir = args.data_dir.resolve() if args.data_dir else project_root / "data" / "dns3"
    output_dir = args.output_dir.resolve() if args.output_dir else project_root / "outputs_constrained_merge"
    model_dir = args.model_dir.resolve() if args.model_dir else project_root / "models_constrained_merge"
    output_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)
    return ProjectPaths(project_root, data_dir, output_dir, model_dir)


def require_files(data_dir: Path) -> None:
    """启动时检查题目要求的数据文件是否齐全，避免运行到一半才发现缺文件。"""

    required = ["fqdn.csv", "access.csv", "flint.csv", "ip.csv", "ipv6.csv", "label.csv"]
    missing = [name for name in required if not (data_dir / name).exists()]
    if missing:
        raise FileNotFoundError(f"数据目录缺少文件: {missing}; 当前数据目录: {data_dir}")


def parse_cluster_list(raw: str) -> List[int]:
    values: List[int] = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        value = int(item)
        if value >= 3:
            values.append(value)
    if not values:
        raise ValueError("候选簇数不能为空，且每个候选簇数必须不小于 3。")
    return sorted(set(values))


def safe_log1p(series: pd.Series) -> pd.Series:
    """对长尾计数特征做 log1p，降低极端请求量对聚类距离的影响。"""

    return np.log1p(pd.to_numeric(series, errors="coerce").fillna(0.0))


def entropy_from_weights(weights: pd.Series) -> float:
    """根据请求量计算分布熵；熵越低，说明该域名的访问或解析更集中。"""

    values = pd.to_numeric(weights, errors="coerce").fillna(0.0)
    total = float(values.sum())
    if total <= 0:
        return 0.0
    probabilities = values[values > 0] / total
    return float(-(probabilities * np.log2(probabilities)).sum())


def weighted_entropy_by_group(
    frame: pd.DataFrame,
    group_col: str,
    category_col: str,
    weight_col: str,
    output_col: str,
) -> pd.DataFrame:
    """计算每个域名在某个类别维度上的加权熵，例如小时、国家或 ISP 分布。"""

    tmp = (
        frame.groupby([group_col, category_col], observed=True)[weight_col]
        .sum()
        .rename("weight")
        .reset_index()
    )
    return (
        tmp.groupby(group_col, observed=True)["weight"]
        .apply(entropy_from_weights)
        .rename(output_col)
        .reset_index()
    )


def read_fqdn(data_dir: Path) -> pd.DataFrame:
    fqdn = pd.read_csv(data_dir / "fqdn.csv", dtype={"encoded_fqdn": "string", "fqdn_no": "string"})
    if fqdn["fqdn_no"].duplicated().any():
        raise ValueError("fqdn.csv 中 fqdn_no 存在重复，无法作为主键聚合。")
    return fqdn


def build_fqdn_features(fqdn: pd.DataFrame) -> pd.DataFrame:
    """从脱敏后的 encoded_fqdn 提取域名形态特征。"""

    out = fqdn[["fqdn_no", "encoded_fqdn"]].copy()
    encoded = out["encoded_fqdn"].fillna("").astype(str)

    parts = encoded.str.rsplit(".", n=1, expand=True)
    left_part = parts[0].fillna("") if parts.shape[1] > 0 else encoded
    out["tld"] = parts[1].fillna("unknown") if parts.shape[1] > 1 else "unknown"

    labels = encoded.str.split(".")
    label_lengths = labels.apply(lambda items: [len(item) for item in items if item])
    out["fqdn_len"] = encoded.str.len()
    out["fqdn_left_len"] = left_part.str.len()
    out["fqdn_dot_cnt"] = encoded.str.count(r"\.")
    out["fqdn_label_cnt"] = out["fqdn_dot_cnt"] + 1
    out["fqdn_hyphen_cnt"] = encoded.str.count("-")
    out["fqdn_digit_token_cnt"] = encoded.str.count("0")
    out["fqdn_alpha_token_cnt"] = encoded.str.count("a")
    out["fqdn_word_token_cnt"] = encoded.apply(lambda item: len(WORD_TOKEN_RE.findall(item)))
    out["fqdn_digit_run_cnt"] = encoded.str.count(r"0+")
    out["fqdn_alpha_run_cnt"] = encoded.str.count(r"a+")
    out["fqdn_has_word_token"] = (out["fqdn_word_token_cnt"] > 0).astype(int)
    out["fqdn_has_hyphen"] = (out["fqdn_hyphen_cnt"] > 0).astype(int)
    out["fqdn_tld_len"] = out["tld"].astype(str).str.len()
    out["fqdn_max_label_len"] = label_lengths.apply(lambda items: max(items) if items else 0)
    out["fqdn_mean_label_len"] = label_lengths.apply(lambda items: float(np.mean(items)) if items else 0.0)
    out["fqdn_std_label_len"] = label_lengths.apply(lambda items: float(np.std(items)) if items else 0.0)
    out["fqdn_digit_ratio"] = out["fqdn_digit_token_cnt"] / out["fqdn_len"].replace(0, np.nan)
    out["fqdn_word_ratio"] = out["fqdn_word_token_cnt"] / out["fqdn_len"].replace(0, np.nan)
    out["fqdn_hyphen_ratio"] = out["fqdn_hyphen_cnt"] / out["fqdn_len"].replace(0, np.nan)
    return out


def combine_chunk_aggregates(parts: List[pd.DataFrame]) -> pd.DataFrame:
    """合并 access.csv 分块聚合结果。"""

    if not parts:
        return pd.DataFrame({"fqdn_no": pd.Series(dtype="string")})
    stacked = pd.concat(parts, axis=0)

    sum_cols = [
        "access_record_cnt",
        "access_request_sum",
        "access_request_sumsq",
        "access_total_request_sum",
        "access_share_sum",
        "access_share_sumsq",
        "access_night_request",
        "access_work_hour_request",
        "access_weekend_request",
        "access_client_unique_chunk_sum",
    ]
    max_cols = ["access_request_max", "access_share_max"]
    combined_sum = stacked[sum_cols].groupby(level=0, observed=True).sum()
    combined_max = stacked[max_cols].groupby(level=0, observed=True).max()
    return combined_sum.join(combined_max).reset_index().rename(columns={"index": "fqdn_no"})


def build_access_features(data_dir: Path, chunksize: int, quick: bool, quick_rows: int) -> pd.DataFrame:
    """分块汇总 access.csv 的访问行为特征。

    access.csv 是本题最大的文件，直接全量读入会占用较多内存。这里按块读取并维护
    sum/sumsq/max/小时分布/日期集合，最后再合并成每个 fqdn_no 的特征。
    """

    usecols = ["fqdn_no", "encoded_ip", "request_cnt", "total_request", "date", "hour"]
    nrows = quick_rows if quick else None
    aggregate_parts: List[pd.DataFrame] = []
    hour_parts: List[pd.DataFrame] = []
    day_sets: Dict[str, set[str]] = defaultdict(set)
    first_date: Dict[str, int] = {}
    last_date: Dict[str, int] = {}

    reader = pd.read_csv(
        data_dir / "access.csv",
        dtype={"fqdn_no": "string", "encoded_ip": "string", "date": "string"},
        usecols=usecols,
        chunksize=chunksize,
        nrows=nrows,
    )

    for chunk_id, chunk in enumerate(reader, start=1):
        chunk["request_cnt"] = pd.to_numeric(chunk["request_cnt"], errors="coerce").fillna(0.0)
        chunk["total_request"] = pd.to_numeric(chunk["total_request"], errors="coerce").fillna(0.0)
        chunk["hour"] = pd.to_numeric(chunk["hour"], errors="coerce").fillna(-1).astype(int)
        chunk["date_num"] = pd.to_numeric(chunk["date"], errors="coerce")
        chunk["request_share"] = chunk["request_cnt"] / chunk["total_request"].replace(0, np.nan)
        chunk["request_share"] = chunk["request_share"].replace([np.inf, -np.inf], np.nan).fillna(0.0)
        chunk["request_sqr"] = chunk["request_cnt"] * chunk["request_cnt"]
        chunk["share_sqr"] = chunk["request_share"] * chunk["request_share"]

        date_as_datetime = pd.to_datetime(chunk["date"], format="%Y%m%d", errors="coerce")
        chunk["is_night"] = chunk["hour"].isin([0, 1, 2, 3, 4, 5]).astype(int)
        chunk["is_work_hour"] = chunk["hour"].between(9, 17).astype(int)
        chunk["is_weekend"] = date_as_datetime.dt.dayofweek.isin([5, 6]).astype(int)
        chunk["night_request"] = chunk["request_cnt"] * chunk["is_night"]
        chunk["work_hour_request"] = chunk["request_cnt"] * chunk["is_work_hour"]
        chunk["weekend_request"] = chunk["request_cnt"] * chunk["is_weekend"]

        grouped = chunk.groupby("fqdn_no", observed=True)
        aggregate_parts.append(
            grouped.agg(
                access_record_cnt=("request_cnt", "size"),
                access_request_sum=("request_cnt", "sum"),
                access_request_sumsq=("request_sqr", "sum"),
                access_request_max=("request_cnt", "max"),
                access_total_request_sum=("total_request", "sum"),
                access_share_sum=("request_share", "sum"),
                access_share_sumsq=("share_sqr", "sum"),
                access_share_max=("request_share", "max"),
                access_night_request=("night_request", "sum"),
                access_work_hour_request=("work_hour_request", "sum"),
                access_weekend_request=("weekend_request", "sum"),
                # 这里是分块去重后求和，可能高估跨块重复 IP，但能稳定刻画访问面宽度。
                access_client_unique_chunk_sum=("encoded_ip", "nunique"),
            )
        )

        hour_pivot = pd.pivot_table(
            chunk,
            index="fqdn_no",
            columns="hour",
            values="request_cnt",
            aggfunc="sum",
            fill_value=0.0,
        )
        for hour in range(24):
            if hour not in hour_pivot.columns:
                hour_pivot[hour] = 0.0
        hour_parts.append(hour_pivot[range(24)])

        for fqdn_no, values in chunk.groupby("fqdn_no", observed=True)["date"]:
            date_values = set(values.dropna().astype(str))
            day_sets[str(fqdn_no)].update(date_values)
        date_stats = grouped["date_num"].agg(["min", "max"]).dropna(how="all")
        for fqdn_no, row in date_stats.iterrows():
            key = str(fqdn_no)
            row_min = int(row["min"]) if pd.notna(row["min"]) else None
            row_max = int(row["max"]) if pd.notna(row["max"]) else None
            if row_min is not None:
                first_date[key] = min(first_date.get(key, row_min), row_min)
            if row_max is not None:
                last_date[key] = max(last_date.get(key, row_max), row_max)

        print(f"    access chunk {chunk_id} processed: {len(chunk):,} rows")

    feat = combine_chunk_aggregates(aggregate_parts)
    if feat.empty:
        return feat

    count = feat["access_record_cnt"].replace(0, np.nan)
    feat["access_request_mean"] = feat["access_request_sum"] / count
    request_var = feat["access_request_sumsq"] / count - feat["access_request_mean"] ** 2
    feat["access_request_std"] = np.sqrt(request_var.clip(lower=0.0))
    feat["access_share_mean"] = feat["access_share_sum"] / count
    share_var = feat["access_share_sumsq"] / count - feat["access_share_mean"] ** 2
    feat["access_share_std"] = np.sqrt(share_var.clip(lower=0.0))
    feat["access_total_request_mean"] = feat["access_total_request_sum"] / count
    feat["access_night_ratio"] = feat["access_night_request"] / feat["access_request_sum"].replace(0, np.nan)
    feat["access_work_hour_ratio"] = feat["access_work_hour_request"] / feat["access_request_sum"].replace(0, np.nan)
    feat["access_weekend_ratio"] = feat["access_weekend_request"] / feat["access_request_sum"].replace(0, np.nan)
    feat["access_burst_ratio"] = feat["access_request_max"] / feat["access_request_mean"].replace(0, np.nan)
    feat["access_share_burst_ratio"] = feat["access_share_max"] / feat["access_share_mean"].replace(0, np.nan)

    day_frame = pd.DataFrame(
        {
            "fqdn_no": list(day_sets.keys()),
            "access_active_day_cnt": [len(values) for values in day_sets.values()],
            "access_first_date": [first_date.get(key, 0) for key in day_sets.keys()],
            "access_last_date": [last_date.get(key, 0) for key in day_sets.keys()],
        }
    )
    day_frame["access_span_days"] = day_frame["access_last_date"] - day_frame["access_first_date"]
    feat = feat.merge(day_frame, on="fqdn_no", how="left")

    hour_pivot = pd.concat(hour_parts, axis=0).groupby(level=0, observed=True).sum()
    hour_pivot = hour_pivot.div(hour_pivot.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)
    hour_pivot.columns = [f"access_hour_{hour:02d}_ratio" for hour in range(24)]
    hour_pivot["access_active_hour_cnt"] = (hour_pivot[[f"access_hour_{hour:02d}_ratio" for hour in range(24)]] > 0).sum(axis=1)
    feat = feat.merge(hour_pivot.reset_index(), on="fqdn_no", how="left")

    for col in [
        "access_record_cnt",
        "access_request_sum",
        "access_client_unique_chunk_sum",
        "access_active_day_cnt",
        "access_total_request_sum",
    ]:
        feat[f"log_{col}"] = safe_log1p(feat[col])

    drop_cols = ["access_request_sumsq", "access_share_sumsq"]
    return feat.drop(columns=drop_cols)


def read_flint(data_dir: Path, quick: bool, quick_rows: int) -> pd.DataFrame:
    nrows = quick_rows if quick else None
    flint = pd.read_csv(
        data_dir / "flint.csv",
        dtype={"fqdn_no": "string", "flintType": "string", "encoded_value": "string", "date": "string"},
        usecols=["fqdn_no", "flintType", "encoded_value", "requestCnt", "ttl", "date"],
        nrows=nrows,
    )
    flint["requestCnt"] = pd.to_numeric(flint["requestCnt"], errors="coerce").fillna(0.0)
    flint["ttl"] = pd.to_numeric(flint["ttl"], errors="coerce")
    flint["date_num"] = pd.to_numeric(flint["date"], errors="coerce")
    return flint


def build_flint_features(flint: pd.DataFrame) -> pd.DataFrame:
    """汇总 DNS 解析记录特征。"""

    frame = flint.copy()
    frame["value_is_fqdn"] = frame["encoded_value"].fillna("").astype(str).str.startswith("fqdn_").astype(int)
    grouped = frame.groupby("fqdn_no", observed=True)
    feat = grouped.agg(
        flint_record_cnt=("requestCnt", "size"),
        flint_total_request=("requestCnt", "sum"),
        flint_mean_request=("requestCnt", "mean"),
        flint_max_request=("requestCnt", "max"),
        flint_std_request=("requestCnt", "std"),
        flint_value_cnt=("encoded_value", "nunique"),
        flint_type_cnt=("flintType", "nunique"),
        flint_date_cnt=("date", "nunique"),
        flint_value_is_fqdn_cnt=("value_is_fqdn", "sum"),
        flint_ttl_mean=("ttl", "mean"),
        flint_ttl_min=("ttl", "min"),
        flint_ttl_max=("ttl", "max"),
        flint_ttl_std=("ttl", "std"),
        flint_first_date=("date_num", "min"),
        flint_last_date=("date_num", "max"),
    ).reset_index()
    feat["flint_span_days"] = feat["flint_last_date"] - feat["flint_first_date"]
    feat["flint_request_per_value"] = feat["flint_total_request"] / feat["flint_value_cnt"].replace(0, np.nan)
    feat["flint_burst_ratio"] = feat["flint_max_request"] / feat["flint_mean_request"].replace(0, np.nan)
    feat["flint_cname_like_ratio"] = feat["flint_value_is_fqdn_cnt"] / feat["flint_record_cnt"].replace(0, np.nan)

    type_count = pd.crosstab(frame["fqdn_no"], frame["flintType"])
    type_count.columns = [f"flint_type_{col}_record_cnt" for col in type_count.columns]
    feat = feat.merge(type_count.reset_index(), on="fqdn_no", how="left")

    type_request = pd.pivot_table(
        frame,
        index="fqdn_no",
        columns="flintType",
        values="requestCnt",
        aggfunc="sum",
        fill_value=0.0,
    )
    type_request.columns = [f"flint_type_{col}_request_sum" for col in type_request.columns]
    feat = feat.merge(type_request.reset_index(), on="fqdn_no", how="left")

    for col in ["flint_record_cnt", "flint_total_request", "flint_value_cnt", "flint_date_cnt"]:
        feat[f"log_{col}"] = safe_log1p(feat[col])
    return feat


def build_resource_graph_features(flint: pd.DataFrame, fqdn: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """把 flint 解析关系视作二部图，提取共享资源和连通分量特征。"""

    edges = flint[["fqdn_no", "encoded_value"]].dropna().drop_duplicates()
    all_domains = fqdn["fqdn_no"].astype(str).tolist()
    if edges.empty:
        return pd.DataFrame({"fqdn_no": all_domains}), {"graph_edge_count": 0, "graph_component_count": len(all_domains)}

    value_degree = edges.groupby("encoded_value", observed=True)["fqdn_no"].nunique().rename("resource_domain_cnt")
    edge_with_degree = edges.merge(value_degree.reset_index(), on="encoded_value", how="left")
    edge_with_degree["is_shared_resource"] = (edge_with_degree["resource_domain_cnt"] > 1).astype(int)
    edge_with_degree["is_low_degree_resource"] = (edge_with_degree["resource_domain_cnt"] <= 5).astype(int)
    edge_with_degree["is_public_resource"] = (edge_with_degree["resource_domain_cnt"] >= 50).astype(int)

    feat = edge_with_degree.groupby("fqdn_no", observed=True).agg(
        graph_resource_cnt=("encoded_value", "nunique"),
        graph_shared_resource_cnt=("is_shared_resource", "sum"),
        graph_low_degree_resource_cnt=("is_low_degree_resource", "sum"),
        graph_public_resource_cnt=("is_public_resource", "sum"),
        graph_resource_degree_mean=("resource_domain_cnt", "mean"),
        graph_resource_degree_max=("resource_domain_cnt", "max"),
        graph_resource_degree_min=("resource_domain_cnt", "min"),
        graph_resource_degree_std=("resource_domain_cnt", "std"),
    ).reset_index()
    feat["graph_shared_resource_ratio"] = feat["graph_shared_resource_cnt"] / feat["graph_resource_cnt"].replace(0, np.nan)
    feat["graph_low_degree_resource_ratio"] = feat["graph_low_degree_resource_cnt"] / feat["graph_resource_cnt"].replace(0, np.nan)
    feat["graph_public_resource_ratio"] = feat["graph_public_resource_cnt"] / feat["graph_resource_cnt"].replace(0, np.nan)

    domain_index = {domain: idx for idx, domain in enumerate(all_domains)}
    resources = edges["encoded_value"].astype(str).unique().tolist()
    resource_index = {resource: idx for idx, resource in enumerate(resources)}
    domain_nodes = edges["fqdn_no"].astype(str).map(domain_index).to_numpy(dtype=np.int64)
    resource_nodes = edges["encoded_value"].astype(str).map(resource_index).to_numpy(dtype=np.int64) + len(all_domains)
    rows = np.concatenate([domain_nodes, resource_nodes])
    cols = np.concatenate([resource_nodes, domain_nodes])
    data = np.ones(len(rows), dtype=np.int8)
    graph = sparse.csr_matrix((data, (rows, cols)), shape=(len(all_domains) + len(resources), len(all_domains) + len(resources)))
    component_count, component_labels = connected_components(graph, directed=False, return_labels=True)

    domain_components = component_labels[: len(all_domains)]
    resource_components = component_labels[len(all_domains) :]
    component_domain_size = np.bincount(domain_components, minlength=component_count)
    component_resource_size = np.bincount(resource_components, minlength=component_count)
    component_feat = pd.DataFrame(
        {
            "fqdn_no": all_domains,
            "graph_component_id": domain_components,
            "graph_component_domain_size": component_domain_size[domain_components],
            "graph_component_resource_size": component_resource_size[domain_components],
        }
    )
    component_feat["log_graph_component_domain_size"] = safe_log1p(component_feat["graph_component_domain_size"])
    component_feat["log_graph_component_resource_size"] = safe_log1p(component_feat["graph_component_resource_size"])
    feat = component_feat.merge(feat, on="fqdn_no", how="left")

    metrics = {
        "graph_edge_count": int(len(edges)),
        "graph_resource_count": int(len(resources)),
        "graph_component_count": int(component_count),
    }
    return feat, metrics


def read_ip_info(data_dir: Path, quick: bool, quick_rows: int) -> pd.DataFrame:
    """合并 IPv4/IPv6 信息，用于解析结果的地理和 ISP 特征。"""

    nrows = quick_rows if quick else None
    columns = ["encoded_ip", "country", "subdivision", "city", "latitude", "longitude", "isp"]
    ipv4 = pd.read_csv(data_dir / "ip.csv", dtype="string", usecols=columns, nrows=nrows)
    ipv6 = pd.read_csv(data_dir / "ipv6.csv", dtype="string", usecols=columns, nrows=nrows)
    ip_info = pd.concat([ipv4, ipv6], ignore_index=True).drop_duplicates("encoded_ip")
    ip_info["latitude"] = pd.to_numeric(ip_info["latitude"], errors="coerce")
    ip_info["longitude"] = pd.to_numeric(ip_info["longitude"], errors="coerce")
    for col in ["country", "subdivision", "city", "isp"]:
        ip_info[col] = ip_info[col].fillna("unknown").astype(str)
    return ip_info


def top_category_by_request(resolved: pd.DataFrame, category_col: str, output_col: str) -> pd.DataFrame:
    """提取每个域名请求量最高的国家或 ISP，作为低基数类别特征。"""

    tmp = (
        resolved.groupby(["fqdn_no", category_col], observed=True)["requestCnt"]
        .sum()
        .rename("request_sum")
        .reset_index()
        .sort_values(["fqdn_no", "request_sum"], ascending=[True, False])
    )
    return tmp.drop_duplicates("fqdn_no", keep="first")[["fqdn_no", category_col]].rename(columns={category_col: output_col})


def build_flint_ip_geo_features(flint: pd.DataFrame, ip_info: pd.DataFrame) -> pd.DataFrame:
    """把 flint 解析结果关联到 IP 地理库，刻画解析基础设施分布。"""

    resolved = flint[["fqdn_no", "encoded_value", "requestCnt"]].merge(
        ip_info,
        left_on="encoded_value",
        right_on="encoded_ip",
        how="inner",
    )
    if resolved.empty:
        return pd.DataFrame({"fqdn_no": pd.Series(dtype="string")})

    resolved["is_china_ip"] = (resolved["country"] == "中国").astype(int)
    resolved["china_request_cnt"] = resolved["requestCnt"] * resolved["is_china_ip"]
    resolved["overseas_request_cnt"] = resolved["requestCnt"] * (1 - resolved["is_china_ip"])

    grouped = resolved.groupby("fqdn_no", observed=True)
    feat = grouped.agg(
        flint_ip_record_cnt=("encoded_ip", "size"),
        flint_ip_unique_cnt=("encoded_ip", "nunique"),
        flint_ip_country_cnt=("country", "nunique"),
        flint_ip_subdivision_cnt=("subdivision", "nunique"),
        flint_ip_city_cnt=("city", "nunique"),
        flint_ip_isp_cnt=("isp", "nunique"),
        flint_ip_request_cnt=("requestCnt", "sum"),
        flint_ip_china_request_cnt=("china_request_cnt", "sum"),
        flint_ip_overseas_request_cnt=("overseas_request_cnt", "sum"),
        flint_ip_latitude_mean=("latitude", "mean"),
        flint_ip_longitude_mean=("longitude", "mean"),
        flint_ip_latitude_std=("latitude", "std"),
        flint_ip_longitude_std=("longitude", "std"),
    ).reset_index()
    feat["flint_ip_china_ratio"] = feat["flint_ip_china_request_cnt"] / feat["flint_ip_request_cnt"].replace(0, np.nan)
    feat["flint_ip_overseas_ratio"] = feat["flint_ip_overseas_request_cnt"] / feat["flint_ip_request_cnt"].replace(0, np.nan)

    country_entropy = weighted_entropy_by_group(resolved, "fqdn_no", "country", "requestCnt", "flint_ip_country_entropy")
    isp_entropy = weighted_entropy_by_group(resolved, "fqdn_no", "isp", "requestCnt", "flint_ip_isp_entropy")
    top_country = top_category_by_request(resolved, "country", "flint_top_country")
    top_isp = top_category_by_request(resolved, "isp", "flint_top_isp")
    feat = (
        feat.merge(country_entropy, on="fqdn_no", how="left")
        .merge(isp_entropy, on="fqdn_no", how="left")
        .merge(top_country, on="fqdn_no", how="left")
        .merge(top_isp, on="fqdn_no", how="left")
    )

    for col in ["flint_ip_record_cnt", "flint_ip_unique_cnt", "flint_ip_request_cnt"]:
        feat[f"log_{col}"] = safe_log1p(feat[col])
    return feat


def merge_feature_parts(parts: Iterable[pd.DataFrame]) -> pd.DataFrame:
    """按 fqdn_no 左连接多个特征表。"""

    iterator = iter(parts)
    base = next(iterator)
    for part in iterator:
        if part.empty:
            continue
        base = base.merge(part, on="fqdn_no", how="left")
    return base


def finalize_features(features: pd.DataFrame) -> pd.DataFrame:
    """统一处理缺失值和列类型，避免后续矩阵构造出现 object 噪声列。"""

    out = features.copy()
    for col in out.columns:
        if col in {"fqdn_no", "encoded_fqdn"}:
            out[col] = out[col].astype(str)
        elif col in CATEGORICAL_COLS:
            out[col] = out[col].fillna("unknown").astype(str)
        else:
            out[col] = pd.to_numeric(out[col], errors="coerce").replace([np.inf, -np.inf], np.nan).fillna(0.0)
    return out


def default_dns2_detail_path(paths: ProjectPaths) -> Path:
    """定位 DNS2 集成排序版输出，DNS2 与 DNS3 使用同一批 fqdn_no。"""

    return paths.project_root.parent / "完成dns2" / "outputs_ensemble_rank" / "tp1000" / "prediction_detail.csv"


def read_dns2_prior_features(paths: ProjectPaths, args: argparse.Namespace, fqdn: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, object]]:
    """读取 DNS2 预测明细，并转换成 DNS3 聚类可用的先验特征。

    DNS2 的 test 集与 DNS3 的 fqdn_no / encoded_fqdn 完全对应。这里不把 DNS2
    的 0/1 结果直接作为 DNS3 答案，而是把分数、图规则分数和已知训练标签作为
    分层聚类的弱先验，帮助先对齐黑白大结构，再在层内细分。
    """

    detail_path = args.dns2_detail.resolve() if args.dns2_detail else default_dns2_detail_path(paths)
    if not detail_path.exists():
        raise FileNotFoundError(f"找不到 DNS2 预测明细: {detail_path}")

    required = ["fqdn_no", "encoded_fqdn", "malicious_score", "ensemble_rank_score", "graph_rule_score", "known_label"]
    detail = pd.read_csv(detail_path, dtype={"fqdn_no": "string", "encoded_fqdn": "string"})
    missing = [col for col in required if col not in detail.columns]
    if missing:
        raise ValueError(f"DNS2 预测明细缺少必要列: {missing}; 当前文件: {detail_path}")

    optional_cols = [
        "label",
        "ranking_score",
        "score_rank",
        "graph_component_domain_cnt",
        "graph_component_label_cnt",
        "graph_component_negative_cnt",
        "graph_component_positive_cnt",
        "graph_component_resource_cnt",
        "graph_component_risk",
        "graph_known_resource_cnt",
        "graph_mean_resource_domain_cnt",
        "graph_min_resource_domain_cnt",
        "graph_pure_black_hit_cnt",
        "graph_pure_white_hit_cnt",
        "graph_resource_risk_max",
        "graph_resource_risk_mean",
        "is_known_train_label",
    ]
    keep_cols = required + [col for col in optional_cols if col in detail.columns]
    prior = detail[keep_cols].copy()

    check = fqdn[["fqdn_no", "encoded_fqdn"]].merge(
        prior[["fqdn_no", "encoded_fqdn"]],
        on="fqdn_no",
        how="left",
        suffixes=("_dns3", "_dns2"),
    )
    missing_prior = int(check["encoded_fqdn_dns2"].isna().sum())
    mismatch = int(
        (
            check["encoded_fqdn_dns2"].notna()
            & (check["encoded_fqdn_dns3"].astype(str) != check["encoded_fqdn_dns2"].astype(str))
        ).sum()
    )
    if missing_prior or mismatch:
        raise ValueError(
            f"DNS2 明细与 DNS3 fqdn.csv 无法一一对应: missing={missing_prior}, mismatch={mismatch}"
        )

    prior = prior.drop(columns=["encoded_fqdn"])
    rename_map = {
        "malicious_score": "dns2_malicious_score",
        "ensemble_rank_score": "dns2_ensemble_rank_score",
        "graph_rule_score": "dns2_graph_rule_score",
        "known_label": "dns2_known_label",
        "label": "dns2_pred_label",
        "ranking_score": "dns2_ranking_score",
        "score_rank": "dns2_score_rank",
        "is_known_train_label": "dns2_is_known_train_label",
    }
    for col in optional_cols:
        if col.startswith("graph_"):
            rename_map[col] = f"dns2_{col}"
    prior = prior.rename(columns=rename_map)

    for col in prior.columns:
        if col == "fqdn_no":
            continue
        prior[col] = pd.to_numeric(prior[col], errors="coerce")

    known_raw = prior["dns2_known_label"].copy()
    prior["dns2_known_label_is_known"] = known_raw.notna().astype(int)
    prior["dns2_known_label"] = known_raw.fillna(-1)
    if "dns2_pred_label" not in prior.columns:
        prior["dns2_pred_label"] = (prior["dns2_ensemble_rank_score"] >= prior["dns2_ensemble_rank_score"].quantile(0.943)).astype(int)
    if "dns2_score_rank" not in prior.columns:
        prior["dns2_score_rank"] = prior["dns2_ensemble_rank_score"].rank(method="first", ascending=False)
    prior["dns2_score_rank_pct"] = prior["dns2_score_rank"] / max(len(prior), 1)
    prior["dns2_high_score_margin"] = (prior["dns2_score_rank"] <= int(args.high_risk_count)).astype(int)

    metrics = {
        "dns2_detail_path": str(detail_path),
        "dns2_prior_rows": int(len(prior)),
        "dns2_known_label_rows": int(prior["dns2_known_label_is_known"].sum()),
        "dns2_known_positive_rows": int((known_raw == 1).sum()),
        "dns2_known_negative_rows": int((known_raw == 0).sum()),
        "dns2_pred_positive_rows": int((prior["dns2_pred_label"] == 1).sum()),
    }
    return prior, metrics


def prepare_features(paths: ProjectPaths, args: argparse.Namespace) -> Tuple[pd.DataFrame, Dict[str, object]]:
    print("[1/7] 读取 fqdn.csv 并构造域名字符串特征...")
    fqdn = read_fqdn(paths.data_dir)
    fqdn_feat = build_fqdn_features(fqdn)

    print("[2/7] 分块汇总 access.csv 访问行为特征...")
    access_feat = build_access_features(paths.data_dir, args.access_chunksize, args.quick, args.quick_rows)

    print("[3/7] 读取并汇总 flint.csv 解析行为特征...")
    flint = read_flint(paths.data_dir, args.quick, args.quick_rows)
    flint_feat = build_flint_features(flint)

    print("[4/7] 基于 flint.csv 构造共享解析资源图特征...")
    graph_feat, graph_metrics = build_resource_graph_features(flint, fqdn)

    print("[5/7] 关联解析 IP 的国家、城市和 ISP 特征...")
    ip_info = read_ip_info(paths.data_dir, args.quick, args.quick_rows)
    geo_feat = build_flint_ip_geo_features(flint, ip_info)

    print("[6/7] 读取 DNS2 集成排序先验特征...")
    dns2_feat, dns2_metrics = read_dns2_prior_features(paths, args, fqdn)

    print("[7/7] 合并并清洗特征表...")
    features = merge_feature_parts([fqdn_feat, access_feat, flint_feat, graph_feat, geo_feat, dns2_feat])
    features = finalize_features(features)
    metrics: Dict[str, object] = {
        "fqdn_rows": int(len(fqdn)),
        "feature_rows": int(len(features)),
        "quick_mode": bool(args.quick),
        "flint_rows_used": int(len(flint)),
        "ip_info_rows_used": int(len(ip_info)),
    }
    metrics.update(graph_metrics)
    metrics.update(dns2_metrics)
    return features, metrics


def make_one_hot_encoder() -> OneHotEncoder:
    """兼容不同 scikit-learn 版本的 OneHotEncoder 参数名。"""

    candidates = [
        {"handle_unknown": "ignore", "min_frequency": 3, "sparse_output": True},
        {"handle_unknown": "ignore", "min_frequency": 3, "sparse": True},
        {"handle_unknown": "ignore"},
    ]
    for kwargs in candidates:
        try:
            return OneHotEncoder(**kwargs)
        except TypeError:
            continue
    raise RuntimeError("无法初始化 OneHotEncoder，请检查 scikit-learn 版本。")


def build_embedding(
    features: pd.DataFrame,
    svd_components: int,
    tfidf_max_features: int,
) -> Tuple[np.ndarray, Dict[str, object], Dict[str, object]]:
    """将结构化、类别和域名字符特征合并为适合聚类的低维向量。"""

    categorical_cols = [col for col in CATEGORICAL_COLS if col in features.columns]
    # graph_component_id 只是连通分量编号，本身没有大小顺序；保留在明细中可以调试，
    # 但不进入距离空间，避免 KMeans 把编号大小误解为相似度。
    excluded_numeric = {"fqdn_no", "encoded_fqdn", "graph_component_id", *categorical_cols}
    numeric_cols = [col for col in features.columns if col not in excluded_numeric]

    numeric_imputer = SimpleImputer(strategy="median")
    numeric_scaler = StandardScaler()
    numeric_matrix = numeric_scaler.fit_transform(numeric_imputer.fit_transform(features[numeric_cols]))
    numeric_sparse = sparse.csr_matrix(numeric_matrix * 1.15)

    one_hot = make_one_hot_encoder()
    category_sparse = one_hot.fit_transform(features[categorical_cols]) if categorical_cols else sparse.csr_matrix((len(features), 0))
    category_sparse = category_sparse * 0.85

    vectorizer = TfidfVectorizer(
        analyzer="char_wb",
        ngram_range=(3, 5),
        min_df=2,
        max_features=tfidf_max_features,
        sublinear_tf=True,
        lowercase=False,
    )
    text_sparse = vectorizer.fit_transform(features["encoded_fqdn"].fillna("").astype(str)) * 0.75

    combined = sparse.hstack([numeric_sparse, category_sparse, text_sparse], format="csr")
    n_components = min(svd_components, combined.shape[1] - 1, len(features) - 1)
    if n_components < 2:
        raise ValueError("特征维度过低，无法进行 SVD 降维。")

    svd = TruncatedSVD(n_components=n_components, random_state=RANDOM_STATE)
    embedding = svd.fit_transform(combined)
    embedding_scaler = StandardScaler()
    embedding = embedding_scaler.fit_transform(embedding)

    transformers = {
        "numeric_imputer": numeric_imputer,
        "numeric_scaler": numeric_scaler,
        "one_hot": one_hot,
        "vectorizer": vectorizer,
        "svd": svd,
        "embedding_scaler": embedding_scaler,
    }
    matrix_metrics = {
        "numeric_feature_count": int(len(numeric_cols)),
        "categorical_columns": ", ".join(categorical_cols) if categorical_cols else "none",
        "combined_sparse_shape": tuple(int(v) for v in combined.shape),
        "svd_components": int(n_components),
        "svd_explained_variance_ratio_sum": float(svd.explained_variance_ratio_.sum()),
    }
    feature_meta = {"numeric_columns": numeric_cols, "categorical_columns": categorical_cols}
    return embedding, {**transformers, **feature_meta}, matrix_metrics


def cluster_balance_score(counts: np.ndarray) -> float:
    """用簇大小熵衡量聚类是否过度塌缩到少数大簇。"""

    total = counts.sum()
    if total <= 0 or len(counts) <= 1:
        return 0.0
    probabilities = counts[counts > 0] / total
    return float(-(probabilities * np.log(probabilities)).sum() / math.log(len(counts)))


def remap_labels_by_size(labels: np.ndarray) -> np.ndarray:
    """将最大簇编号映射为 0、次大簇为 1，保证输出稳定可读。"""

    counts = pd.Series(labels).value_counts().sort_values(ascending=False)
    label_map = {old_label: new_label for new_label, old_label in enumerate(counts.index.tolist())}
    return np.array([label_map[item] for item in labels], dtype=int)


def evaluate_candidate_labels(
    embedding: np.ndarray,
    labels: np.ndarray,
    cluster_count: int,
    sample_size: int,
) -> Dict[str, float]:
    """计算无监督内部指标，用于在多个簇数之间选择较稳的方案。"""

    counts = np.bincount(labels, minlength=cluster_count)
    rng = np.random.default_rng(RANDOM_STATE)
    sample_n = min(sample_size, len(labels))
    sample_index = rng.choice(len(labels), size=sample_n, replace=False) if sample_n < len(labels) else np.arange(len(labels))
    sample_labels = labels[sample_index]
    if len(np.unique(sample_labels)) < 2:
        silhouette = -1.0
    else:
        silhouette = float(silhouette_score(embedding[sample_index], sample_labels, metric="euclidean"))

    if len(np.unique(labels)) < 2:
        calinski = 0.0
    else:
        calinski = float(calinski_harabasz_score(embedding, labels))

    balance = cluster_balance_score(counts)
    tiny_limit = max(2, int(0.002 * len(labels)))
    tiny_ratio = float((counts < tiny_limit).mean())
    # silhouette 是主体指标；balance 防止全部落入少数大簇；tiny_ratio 惩罚大量极小簇。
    internal_score = silhouette + 0.04 * balance - 0.04 * tiny_ratio
    return {
        "cluster_count": float(cluster_count),
        "silhouette": float(silhouette),
        "calinski_harabasz": float(calinski),
        "balance": float(balance),
        "tiny_ratio": float(tiny_ratio),
        "internal_score": float(internal_score),
        "min_cluster_size": float(counts.min()),
        "max_cluster_size": float(counts.max()),
    }


def fit_clusters(
    embedding: np.ndarray,
    candidate_counts: Sequence[int],
    sample_size: int,
) -> Tuple[np.ndarray, MiniBatchKMeans, pd.DataFrame]:
    """对候选簇数逐一聚类，并根据内部指标选择最终方案。"""

    rows: List[Dict[str, float]] = []
    best_model: MiniBatchKMeans | None = None
    best_labels: np.ndarray | None = None
    best_score = -np.inf

    for cluster_count in candidate_counts:
        if cluster_count < 3:
            continue
        if cluster_count >= len(embedding):
            continue
        print(f"    clustering k={cluster_count} ...")
        model = MiniBatchKMeans(
            n_clusters=cluster_count,
            batch_size=2048,
            n_init=10,
            max_iter=300,
            random_state=RANDOM_STATE,
        )
        labels = model.fit_predict(embedding)
        metrics = evaluate_candidate_labels(embedding, labels, cluster_count, sample_size)
        rows.append(metrics)
        if metrics["internal_score"] > best_score:
            best_score = metrics["internal_score"]
            best_model = model
            best_labels = labels

    if best_model is None or best_labels is None:
        raise ValueError("没有可用的聚类簇数，请检查 --cluster-count 或 --cluster-list。")
    return remap_labels_by_size(best_labels), best_model, pd.DataFrame(rows).sort_values("internal_score", ascending=False)


def choose_layer_columns(features: pd.DataFrame, layer_name: str) -> List[str]:
    """为不同 DNS2 风险层选择额外加权的结构化特征。"""

    if layer_name == "high":
        prefixes = (
            "graph_",
            "flint_",
            "flint_ip_",
            "dns2_graph_",
            "dns2_malicious_score",
            "dns2_ensemble_rank_score",
            "dns2_graph_rule_score",
            "dns2_ranking_score",
        )
    elif layer_name == "low":
        prefixes = (
            "access_",
            "log_access_",
            "fqdn_",
            "flint_ip_country_entropy",
            "flint_ip_isp_entropy",
            "dns2_malicious_score",
            "dns2_ensemble_rank_score",
            "dns2_score_rank_pct",
        )
    else:
        prefixes = ()

    excluded = {"fqdn_no", "encoded_fqdn", "graph_component_id", *CATEGORICAL_COLS}
    cols = [
        col
        for col in features.columns
        if col not in excluded and any(col.startswith(prefix) for prefix in prefixes)
    ]
    return cols


def make_layer_embedding(
    features: pd.DataFrame,
    base_embedding: np.ndarray,
    indices: np.ndarray,
    layer_name: str,
) -> Tuple[np.ndarray, List[str]]:
    """在全局 embedding 上叠加层内重点特征，形成分层聚类视图。"""

    selected_cols = choose_layer_columns(features, layer_name)
    base = base_embedding[indices] * 0.65
    if not selected_cols:
        return base, selected_cols

    extra = features.iloc[indices][selected_cols]
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    extra_matrix = scaler.fit_transform(imputer.fit_transform(extra))
    weight = 1.55 if layer_name == "high" else 1.25
    return np.hstack([base, extra_matrix * weight]), selected_cols


def fit_layer_kmeans(
    layer_embedding: np.ndarray,
    requested_clusters: int,
    layer_name: str,
) -> Tuple[np.ndarray, MiniBatchKMeans | None]:
    """对单个风险层聚类，小样本层自动下调簇数。"""

    if len(layer_embedding) == 0:
        return np.array([], dtype=int), None
    cluster_count = min(max(1, requested_clusters), len(layer_embedding))
    if cluster_count == 1:
        return np.zeros(len(layer_embedding), dtype=int), None

    print(f"    {layer_name} layer clustering k={cluster_count}, rows={len(layer_embedding):,} ...")
    model = MiniBatchKMeans(
        n_clusters=cluster_count,
        batch_size=min(2048, max(128, len(layer_embedding))),
        n_init=20,
        max_iter=400,
        random_state=RANDOM_STATE,
    )
    return model.fit_predict(layer_embedding), model


def build_dns2_layer_masks(features: pd.DataFrame, args: argparse.Namespace) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, object]]:
    """按 DNS2 分数划分高风险、低风险和中间不确定层。"""

    rank = pd.to_numeric(features["dns2_score_rank"], errors="coerce").fillna(len(features) + 1).to_numpy()
    pred_label = pd.to_numeric(features["dns2_pred_label"], errors="coerce").fillna(0).to_numpy()
    known_label = pd.to_numeric(features["dns2_known_label"], errors="coerce").fillna(-1).to_numpy()

    high_mask = (rank <= int(args.high_risk_count)) | (pred_label == 1) | (known_label == 1)
    # 已知白样本作为低风险锚点，避免被“高分附近”的不确定域名带偏。
    known_white_mask = known_label == 0
    middle_upper_rank = int(args.high_risk_count + args.middle_risk_count)
    middle_mask = (~high_mask) & (~known_white_mask) & (rank <= middle_upper_rank)
    low_mask = ~(high_mask | middle_mask)
    low_mask = low_mask | known_white_mask
    middle_mask = middle_mask & (~low_mask)

    metrics = {
        "layer_high_rows": int(high_mask.sum()),
        "layer_middle_rows": int(middle_mask.sum()),
        "layer_low_rows": int(low_mask.sum()),
        "layer_high_risk_count_arg": int(args.high_risk_count),
        "layer_middle_risk_count_arg": int(args.middle_risk_count),
    }
    return high_mask, middle_mask, low_mask, metrics


def assign_middle_by_nearest_centroid(
    base_embedding: np.ndarray,
    labels: np.ndarray,
    assigned_mask: np.ndarray,
    middle_indices: np.ndarray,
) -> np.ndarray:
    """将中间不确定域名按全局 embedding 最近质心归入高/低层已有簇。"""

    if len(middle_indices) == 0:
        return labels

    assigned_labels = sorted(set(labels[assigned_mask].astype(int)))
    centroids = []
    for label in assigned_labels:
        centroids.append(base_embedding[(labels == label) & assigned_mask].mean(axis=0))
    centroid_matrix = np.vstack(centroids)

    middle_embedding = base_embedding[middle_indices]
    # 数据量不大，直接计算欧氏距离矩阵更清晰。
    distances = ((middle_embedding[:, None, :] - centroid_matrix[None, :, :]) ** 2).sum(axis=2)
    nearest = distances.argmin(axis=1)
    labels[middle_indices] = np.array([assigned_labels[pos] for pos in nearest], dtype=int)
    return labels


def fit_layered_clusters(
    features: pd.DataFrame,
    embedding: np.ndarray,
    args: argparse.Namespace,
) -> Tuple[np.ndarray, Dict[str, object], pd.DataFrame, pd.DataFrame, Dict[str, object]]:
    """DNS2 先验分层聚类。

    - 高置信恶意层：使用 flint 图、解析 IP/ISP、DNS2 图规则等特征加权聚类；
    - 低风险白域名层：使用访问行为、域名形态、地理/ISP 分布加权聚类；
    - 中间不确定层：不新开簇，按最近质心归入已有高/低层簇，减少边界样本噪声。
    """

    high_mask, middle_mask, low_mask, layer_metrics = build_dns2_layer_masks(features, args)
    high_indices = np.flatnonzero(high_mask)
    low_indices = np.flatnonzero(low_mask)
    middle_indices = np.flatnonzero(middle_mask)

    if args.cluster_count is not None:
        if args.cluster_count < 3:
            raise ValueError("PDF 要求簇数不能小于 3，--cluster-count 必须 >= 3。")
        high_cluster_count = max(1, min(args.high_clusters, args.cluster_count - 1))
        low_cluster_count = max(1, args.cluster_count - high_cluster_count)
    else:
        high_cluster_count = int(args.high_clusters)
        low_cluster_count = int(args.low_clusters)

    high_embedding, high_cols = make_layer_embedding(features, embedding, high_indices, "high")
    low_embedding, low_cols = make_layer_embedding(features, embedding, low_indices, "low")
    high_labels, high_model = fit_layer_kmeans(high_embedding, high_cluster_count, "high-risk")
    low_labels, low_model = fit_layer_kmeans(low_embedding, low_cluster_count, "low-risk")

    labels = np.full(len(features), -1, dtype=int)
    labels[high_indices] = high_labels
    low_offset = int(high_labels.max() + 1) if len(high_labels) else 0
    labels[low_indices] = low_labels + low_offset
    assigned_mask = labels >= 0
    labels = assign_middle_by_nearest_centroid(embedding, labels, assigned_mask, middle_indices)
    if (labels < 0).any():
        raise RuntimeError("分层聚类后仍存在未分配域名。")

    labels = remap_labels_by_size(labels)
    layer_frame = pd.DataFrame(
        {
            "fqdn_no": features["fqdn_no"].astype(str),
            "risk_layer": np.select(
                [high_mask, middle_mask, low_mask],
                ["high", "middle", "low"],
                default="unknown",
            ),
            "dns2_malicious_score": features["dns2_malicious_score"],
            "dns2_ensemble_rank_score": features["dns2_ensemble_rank_score"],
            "dns2_graph_rule_score": features["dns2_graph_rule_score"],
            "dns2_known_label": features["dns2_known_label"],
            "dns2_pred_label": features["dns2_pred_label"],
            "dns2_score_rank": features["dns2_score_rank"],
        }
    )

    sweep = pd.DataFrame(
        [
            {
                "layer": "high",
                "rows": int(len(high_indices)),
                "requested_clusters": int(high_cluster_count),
                "actual_clusters": int(len(set(high_labels))) if len(high_labels) else 0,
                "weighted_feature_count": int(len(high_cols)),
            },
            {
                "layer": "middle",
                "rows": int(len(middle_indices)),
                "requested_clusters": 0,
                "actual_clusters": 0,
                "weighted_feature_count": 0,
            },
            {
                "layer": "low",
                "rows": int(len(low_indices)),
                "requested_clusters": int(low_cluster_count),
                "actual_clusters": int(len(set(low_labels))) if len(low_labels) else 0,
                "weighted_feature_count": int(len(low_cols)),
            },
        ]
    )

    model_bundle = {
        "high_model": high_model,
        "low_model": low_model,
        "high_weighted_columns": high_cols,
        "low_weighted_columns": low_cols,
    }
    metrics: Dict[str, object] = {
        "layered_clustering_enabled": True,
        "high_clusters_arg": int(args.high_clusters),
        "low_clusters_arg": int(args.low_clusters),
        "actual_cluster_count_before_size_remap": int(len(set(labels))),
        "high_weighted_feature_count": int(len(high_cols)),
        "low_weighted_feature_count": int(len(low_cols)),
    }
    metrics.update(layer_metrics)
    return labels, model_bundle, sweep, layer_frame, metrics


def evaluate_dns2_known_alignment(features: pd.DataFrame, labels: np.ndarray) -> Dict[str, object]:
    """用 DNS2 训练集中已知黑白标签作为弱验证，观察聚类是否对齐黑白大结构。"""

    known_mask = features["dns2_known_label_is_known"].to_numpy(dtype=bool)
    if known_mask.sum() < 2:
        return {"dns2_known_alignment_enabled": False}
    y_true = features.loc[known_mask, "dns2_known_label"].to_numpy(dtype=int)
    y_pred = labels[known_mask]
    return {
        "dns2_known_alignment_enabled": True,
        "dns2_known_alignment_rows": int(known_mask.sum()),
        "dns2_known_alignment_nmi": float(normalized_mutual_info_score(y_true, y_pred)),
        "dns2_known_alignment_ari": float(adjusted_rand_score(y_true, y_pred)),
    }


def clone_args(args: argparse.Namespace, **overrides: object) -> argparse.Namespace:
    """复制 argparse 参数对象，用于为不同候选设置不同簇数。"""

    cloned = argparse.Namespace(**vars(args))
    for key, value in overrides.items():
        setattr(cloned, key, value)
    return cloned


def parse_candidate_list(raw: str) -> List[str]:
    candidates = [item.strip() for item in raw.split(",") if item.strip()]
    if not candidates:
        raise ValueError("--candidate-list 至少需要一个候选名称。")
    return candidates


def build_risk_layer_frame(features: pd.DataFrame, args: argparse.Namespace) -> pd.DataFrame:
    """生成统一的 DNS2 风险层明细，供图优先和 consensus 候选复用。"""

    high_mask, middle_mask, low_mask, _ = build_dns2_layer_masks(features, args)
    return pd.DataFrame(
        {
            "fqdn_no": features["fqdn_no"].astype(str),
            "risk_layer": np.select([high_mask, middle_mask, low_mask], ["high", "middle", "low"], default="unknown"),
            "dns2_malicious_score": features["dns2_malicious_score"],
            "dns2_ensemble_rank_score": features["dns2_ensemble_rank_score"],
            "dns2_graph_rule_score": features["dns2_graph_rule_score"],
            "dns2_known_label": features["dns2_known_label"],
            "dns2_pred_label": features["dns2_pred_label"],
            "dns2_score_rank": features["dns2_score_rank"],
        }
    )


def build_low_degree_graph_context(
    features: pd.DataFrame,
    flint: pd.DataFrame,
    args: argparse.Namespace,
) -> LowDegreeGraphContext:
    """用 flint 低度共享资源构造域名社区。

    degree=1 的资源不能连接域名，degree 大于 graph_max_degree 的资源往往是公共
    CDN/公共解析结果，会把无关域名误连到一起，因此仅保留 degree 2-30 左右的资源。
    """

    domains = features["fqdn_no"].astype(str).tolist()
    domain_index = {fqdn_no: idx for idx, fqdn_no in enumerate(domains)}
    edges = flint[["fqdn_no", "encoded_value"]].dropna().drop_duplicates().copy()
    edges["fqdn_no"] = edges["fqdn_no"].astype(str)
    edges["encoded_value"] = edges["encoded_value"].astype(str)

    degree = edges.groupby("encoded_value", observed=True)["fqdn_no"].nunique().rename("resource_degree")
    degree_frame = degree.reset_index()
    kept_resources = degree_frame[
        degree_frame["resource_degree"].between(int(args.graph_min_degree), int(args.graph_max_degree))
    ][["encoded_value", "resource_degree"]]
    filtered = edges.merge(kept_resources, on="encoded_value", how="inner")
    filtered = filtered[filtered["fqdn_no"].isin(domain_index)].copy()

    union_find = UnionFind(len(domains))
    filtered["domain_idx"] = filtered["fqdn_no"].map(domain_index).astype(np.int64)
    for _, group in filtered.groupby("encoded_value", observed=True):
        domain_ids = group["domain_idx"].to_numpy(dtype=np.int64)
        if len(domain_ids) < 2:
            continue
        first = int(domain_ids[0])
        for item in domain_ids[1:]:
            union_find.union(first, int(item))

    roots = np.array([union_find.find(idx) for idx in range(len(domains))], dtype=np.int64)
    root_counts = pd.Series(roots).value_counts().sort_values(ascending=False)
    root_to_component = {root: comp_id for comp_id, root in enumerate(root_counts.index.tolist())}
    component_ids = np.array([root_to_component[root] for root in roots], dtype=np.int64)
    component_sizes = pd.Series(component_ids).value_counts().to_dict()
    component_frame = pd.DataFrame(
        {
            "fqdn_no": domains,
            "low_graph_component_id": component_ids,
            "low_graph_component_size": [int(component_sizes[item]) for item in component_ids],
        }
    )

    if filtered.empty:
        component_frame["low_graph_component_resource_cnt"] = 0
    else:
        filtered = filtered.merge(component_frame[["fqdn_no", "low_graph_component_id"]], on="fqdn_no", how="left")
        resource_cnt = (
            filtered.groupby("low_graph_component_id", observed=True)["encoded_value"]
            .nunique()
            .rename("low_graph_component_resource_cnt")
            .reset_index()
        )
        component_frame = component_frame.merge(resource_cnt, on="low_graph_component_id", how="left")
        component_frame["low_graph_component_resource_cnt"] = component_frame["low_graph_component_resource_cnt"].fillna(0)

    metrics = {
        "low_graph_total_resource_count": int(len(degree_frame)),
        "low_graph_kept_resource_count": int(len(kept_resources)),
        "low_graph_filtered_edge_count": int(len(filtered)),
        "low_graph_component_count": int(component_frame["low_graph_component_id"].nunique()),
        "low_graph_largest_component_size": int(component_frame["low_graph_component_size"].max()),
        "low_graph_min_degree": int(args.graph_min_degree),
        "low_graph_max_degree": int(args.graph_max_degree),
    }
    return LowDegreeGraphContext(component_frame=component_frame, filtered_edges=filtered, metrics=metrics)


def make_graph_priority_embedding(features: pd.DataFrame, embedding: np.ndarray) -> Tuple[np.ndarray, List[str]]:
    """构造图优先视图：全局 embedding + 加权的图/解析/行为特征。"""

    prefixes = (
        "graph_",
        "flint_",
        "flint_ip_",
        "access_",
        "log_access_",
        "dns2_graph_",
        "dns2_malicious_score",
        "dns2_ensemble_rank_score",
        "dns2_graph_rule_score",
        "dns2_score_rank_pct",
    )
    excluded = {"fqdn_no", "encoded_fqdn", "graph_component_id", *CATEGORICAL_COLS}
    cols = [col for col in features.columns if col not in excluded and any(col.startswith(prefix) for prefix in prefixes)]
    if not cols:
        return embedding, cols
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    extra = scaler.fit_transform(imputer.fit_transform(features[cols]))
    return np.hstack([embedding * 0.55, extra * 1.45]), cols


def split_large_low_graph_components(
    features: pd.DataFrame,
    graph_embedding: np.ndarray,
    graph_context: LowDegreeGraphContext,
    args: argparse.Namespace,
) -> Tuple[np.ndarray, pd.DataFrame]:
    """低度图组件作为原子社区；大组件再按行为/解析特征细分为伪组件。"""

    component_frame = graph_context.component_frame
    component_ids = component_frame["low_graph_component_id"].to_numpy(dtype=np.int64)
    pseudo_ids = np.full(len(component_frame), -1, dtype=np.int64)
    records: List[Dict[str, object]] = []
    next_pseudo_id = 0

    for component_id, index_values in component_frame.groupby("low_graph_component_id", observed=True).indices.items():
        indices = np.array(index_values, dtype=np.int64)
        component_size = len(indices)
        if component_size >= int(args.graph_large_component_size):
            split_count = min(
                component_size,
                max(2, int(math.ceil(component_size / max(int(args.graph_split_size), 1)))),
            )
            print(f"    split low-degree graph component {component_id} size={component_size:,} into {split_count} parts")
            model = MiniBatchKMeans(
                n_clusters=split_count,
                batch_size=min(2048, max(128, component_size)),
                n_init=20,
                max_iter=400,
                random_state=RANDOM_STATE + int(component_id) % 997,
            )
            split_labels = model.fit_predict(graph_embedding[indices])
        else:
            split_count = 1
            split_labels = np.zeros(component_size, dtype=int)

        for split_label in sorted(set(split_labels.astype(int))):
            split_indices = indices[split_labels == split_label]
            pseudo_ids[split_indices] = next_pseudo_id
            records.append(
                {
                    "pseudo_component_id": int(next_pseudo_id),
                    "low_graph_component_id": int(component_id),
                    "low_graph_component_size": int(component_size),
                    "split_label": int(split_label),
                    "pseudo_component_size": int(len(split_indices)),
                    "was_large_component_split": int(split_count > 1),
                }
            )
            next_pseudo_id += 1

    if (pseudo_ids < 0).any():
        raise RuntimeError("低度图伪组件构造失败，存在未分配域名。")
    pseudo_frame = pd.DataFrame.from_records(records)
    return pseudo_ids, pseudo_frame


def fit_graph_component_candidate(
    name: str,
    target_k: int,
    features: pd.DataFrame,
    embedding: np.ndarray,
    graph_context: LowDegreeGraphContext,
    args: argparse.Namespace,
) -> CandidateResult:
    """图优先候选：低度资源组件优先，组件层面再合并到目标簇数。"""

    graph_embedding, graph_cols = make_graph_priority_embedding(features, embedding)
    pseudo_ids, pseudo_frame = split_large_low_graph_components(features, graph_embedding, graph_context, args)
    pseudo_count = int(pseudo_ids.max() + 1)

    centroid_rows = []
    weights = []
    for pseudo_id in range(pseudo_count):
        indices = np.flatnonzero(pseudo_ids == pseudo_id)
        centroid_rows.append(graph_embedding[indices].mean(axis=0))
        weights.append(len(indices))
    pseudo_centroids = np.vstack(centroid_rows)
    weights_array = np.array(weights, dtype=float)
    cluster_count = min(max(3, int(target_k)), pseudo_count)

    print(f"    graph component candidate {name}: pseudo_components={pseudo_count:,}, k={cluster_count}")
    model = MiniBatchKMeans(
        n_clusters=cluster_count,
        batch_size=min(2048, max(128, pseudo_count)),
        n_init=30,
        max_iter=500,
        random_state=RANDOM_STATE,
    )
    try:
        pseudo_cluster = model.fit_predict(pseudo_centroids, sample_weight=weights_array)
    except TypeError:
        pseudo_cluster = model.fit_predict(pseudo_centroids)
    labels = remap_labels_by_size(pseudo_cluster[pseudo_ids])

    detail = build_risk_layer_frame(features, args).merge(graph_context.component_frame, on="fqdn_no", how="left")
    detail["pseudo_component_id"] = pseudo_ids
    detail = detail.merge(pseudo_frame, on="pseudo_component_id", how="left", suffixes=("", "_pseudo"))

    sweep = pd.DataFrame(
        [
            {
                "variant": name,
                "target_clusters": int(target_k),
                "actual_clusters": int(len(set(labels))),
                "low_graph_components": int(graph_context.component_frame["low_graph_component_id"].nunique()),
                "pseudo_components": int(pseudo_count),
                "graph_weighted_feature_count": int(len(graph_cols)),
            }
        ]
    )
    metrics: Dict[str, object] = {
        "candidate_type": "graph_component",
        "candidate_target_clusters": int(target_k),
        "graph_weighted_feature_count": int(len(graph_cols)),
        "graph_pseudo_component_count": int(pseudo_count),
        "graph_split_pseudo_component_count": int(pseudo_frame["was_large_component_split"].sum()),
    }
    return CandidateResult(
        name=name,
        labels=labels,
        model={"graph_component_model": model, "graph_weighted_columns": graph_cols, "pseudo_frame": pseudo_frame},
        sweep=sweep,
        detail_frame=detail,
        metrics=metrics,
    )


def fit_dns2_split_candidate(
    name: str,
    total_k: int,
    high_k: int,
    features: pd.DataFrame,
    embedding: np.ndarray,
    args: argparse.Namespace,
) -> CandidateResult:
    """复用 DNS2 先验分层逻辑，生成固定簇数候选。"""

    local_args = clone_args(
        args,
        cluster_count=None,
        high_clusters=int(high_k),
        low_clusters=int(total_k - high_k),
    )
    labels, model, sweep, detail, metrics = fit_layered_clusters(features, embedding, local_args)
    metrics.update({"candidate_type": "dns2_split", "candidate_target_clusters": int(total_k), "candidate_high_clusters": int(high_k)})
    sweep.insert(0, "variant", name)
    return CandidateResult(name=name, labels=labels, model=model, sweep=sweep, detail_frame=detail, metrics=metrics)


def fit_consensus_candidate(
    name: str,
    target_k: int,
    dns2_labels: np.ndarray,
    graph_labels: np.ndarray,
    features: pd.DataFrame,
    embedding: np.ndarray,
    graph_context: LowDegreeGraphContext,
    args: argparse.Namespace,
) -> CandidateResult:
    """把 DNS2 分层标签和图组件标签作为强类别视图，再聚成目标簇数。"""

    consensus_categories = pd.DataFrame(
        {
            "dns2_split_label": pd.Series(dns2_labels).astype(str),
            "graph_component_label": pd.Series(graph_labels).astype(str),
            "dns2_pred_label": features["dns2_pred_label"].astype(int).astype(str),
        }
    )
    encoder = make_one_hot_encoder()
    category_matrix = encoder.fit_transform(consensus_categories) * 2.2
    score_cols = ["dns2_malicious_score", "dns2_ensemble_rank_score", "dns2_graph_rule_score", "dns2_score_rank_pct"]
    score_matrix = StandardScaler().fit_transform(SimpleImputer(strategy="median").fit_transform(features[score_cols]))
    combined = sparse.hstack([sparse.csr_matrix(embedding * 0.65), category_matrix, sparse.csr_matrix(score_matrix * 1.4)], format="csr")

    print(f"    consensus candidate {name}: k={target_k}")
    model = MiniBatchKMeans(
        n_clusters=int(target_k),
        batch_size=2048,
        n_init=30,
        max_iter=500,
        random_state=RANDOM_STATE,
    )
    labels = remap_labels_by_size(model.fit_predict(combined))

    detail = build_risk_layer_frame(features, args).merge(graph_context.component_frame, on="fqdn_no", how="left")
    detail["dns2_split_pre_label"] = dns2_labels
    detail["graph_component_pre_label"] = graph_labels
    sweep = pd.DataFrame(
        [
            {
                "variant": name,
                "target_clusters": int(target_k),
                "actual_clusters": int(len(set(labels))),
                "source_dns2_clusters": int(len(set(dns2_labels))),
                "source_graph_clusters": int(len(set(graph_labels))),
            }
        ]
    )
    metrics: Dict[str, object] = {
        "candidate_type": "consensus",
        "candidate_target_clusters": int(target_k),
        "source_dns2_cluster_count": int(len(set(dns2_labels))),
        "source_graph_cluster_count": int(len(set(graph_labels))),
    }
    return CandidateResult(name=name, labels=labels, model={"consensus_model": model, "consensus_encoder": encoder}, sweep=sweep, detail_frame=detail, metrics=metrics)


def evaluate_low_graph_resource_purity(
    graph_context: LowDegreeGraphContext,
    features: pd.DataFrame,
    labels: np.ndarray,
) -> Dict[str, object]:
    """评估低度共享资源是否被候选标签拆散，作为图优先候选的内部检查。"""

    if graph_context.filtered_edges.empty:
        return {
            "low_graph_resource_purity_enabled": False,
            "low_graph_resource_pure_ratio": None,
        }
    label_frame = pd.DataFrame({"fqdn_no": features["fqdn_no"].astype(str), "candidate_label": labels.astype(int)})
    merged = graph_context.filtered_edges[["encoded_value", "fqdn_no", "resource_degree"]].merge(label_frame, on="fqdn_no", how="inner")
    resource_stats = merged.groupby("encoded_value", observed=True).agg(
        domain_cnt=("fqdn_no", "nunique"),
        label_cnt=("candidate_label", "nunique"),
        resource_degree=("resource_degree", "first"),
    )
    pure_mask = resource_stats["label_cnt"] == 1
    return {
        "low_graph_resource_purity_enabled": True,
        "low_graph_resource_eval_count": int(len(resource_stats)),
        "low_graph_resource_pure_ratio": float(pure_mask.mean()),
        "low_graph_resource_weighted_pure_ratio": float(
            resource_stats.loc[pure_mask, "domain_cnt"].sum() / resource_stats["domain_cnt"].sum()
        ),
    }


def parse_merge_configs(raw: str) -> List[MergeConfig]:
    """解析 k12_h18_l42_g3.0 形式的候选配置。"""

    configs: List[MergeConfig] = []
    pattern = re.compile(r"^k(?P<k>\d+)_h(?P<h>\d+)_l(?P<l>\d+)_g(?P<g>\d+(?:\.\d+)?)$")
    for item in [part.strip() for part in raw.split(",") if part.strip()]:
        match = pattern.match(item)
        if not match:
            raise ValueError(f"无法解析配置 `{item}`，期望格式如 k12_h18_l42_g3.0")
        target_k = int(match.group("k"))
        high_micro = int(match.group("h"))
        low_micro = int(match.group("l"))
        graph_weight = float(match.group("g"))
        if target_k < 3:
            raise ValueError(f"{item}: 目标簇数必须 >= 3")
        if high_micro < 2 or low_micro < 2:
            raise ValueError(f"{item}: 高/低风险微簇数必须 >= 2")
        configs.append(MergeConfig(item, target_k, high_micro, low_micro, graph_weight))
    if not configs:
        raise ValueError("--config-list 至少需要一个配置。")
    return configs


def build_microclusters(
    features: pd.DataFrame,
    embedding: np.ndarray,
    config: MergeConfig,
    args: argparse.Namespace,
) -> Tuple[np.ndarray, pd.DataFrame, Dict[str, object]]:
    """沿用 DNS2 分层，但先切成更多微簇，为后续约束合并做准备。"""

    local_args = clone_args(
        args,
        cluster_count=None,
        high_clusters=config.high_micro_clusters,
        low_clusters=config.low_micro_clusters,
    )
    high_mask, middle_mask, low_mask, layer_metrics = build_dns2_layer_masks(features, local_args)
    high_indices = np.flatnonzero(high_mask)
    low_indices = np.flatnonzero(low_mask)
    middle_indices = np.flatnonzero(middle_mask)

    high_embedding, high_cols = make_layer_embedding(features, embedding, high_indices, "high")
    low_embedding, low_cols = make_layer_embedding(features, embedding, low_indices, "low")
    high_labels, high_model = fit_layer_kmeans(high_embedding, config.high_micro_clusters, f"{config.name} high micro")
    low_labels, low_model = fit_layer_kmeans(low_embedding, config.low_micro_clusters, f"{config.name} low micro")

    micro_labels = np.full(len(features), -1, dtype=int)
    micro_labels[high_indices] = high_labels
    low_offset = int(high_labels.max() + 1) if len(high_labels) else 0
    micro_labels[low_indices] = low_labels + low_offset
    micro_labels = assign_middle_by_nearest_centroid(embedding, micro_labels, micro_labels >= 0, middle_indices)
    if (micro_labels < 0).any():
        raise RuntimeError(f"{config.name}: 微簇阶段仍存在未分配域名。")

    layer_values = np.select([high_mask, middle_mask, low_mask], ["high", "middle", "low"], default="unknown")
    micro_frame = pd.DataFrame(
        {
            "fqdn_no": features["fqdn_no"].astype(str),
            "risk_layer": layer_values,
            "micro_cluster_id": micro_labels.astype(int),
            "dns2_malicious_score": features["dns2_malicious_score"],
            "dns2_ensemble_rank_score": features["dns2_ensemble_rank_score"],
            "dns2_graph_rule_score": features["dns2_graph_rule_score"],
            "dns2_known_label": features["dns2_known_label"],
            "dns2_pred_label": features["dns2_pred_label"],
            "dns2_score_rank": features["dns2_score_rank"],
        }
    )
    model_info = {
        "high_micro_model": high_model,
        "low_micro_model": low_model,
        "high_weighted_columns": high_cols,
        "low_weighted_columns": low_cols,
        "layer_metrics": layer_metrics,
    }
    return micro_labels.astype(int), micro_frame, model_info


def normalize_rows(matrix: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    return matrix / np.where(norms == 0, 1.0, norms)


def build_micro_affinity(
    features: pd.DataFrame,
    flint: pd.DataFrame,
    graph_context: LowDegreeGraphContext,
    micro_labels: np.ndarray,
    micro_embedding: np.ndarray,
    config: MergeConfig,
) -> Tuple[np.ndarray, pd.DataFrame]:
    """构造微簇图相似度矩阵。

    边权由三部分组成：
    - must-link：低度共享资源和低度 CNAME 链；
    - soft-link：微簇 embedding、DNS2 分数和风险层相似；
    - cannot-link：DNS2 已知黑/白锚点冲突、极高风险与低风险冲突时压低权重。
    """

    micro_count = int(micro_labels.max() + 1)
    domain_to_micro = dict(zip(features["fqdn_no"].astype(str), micro_labels.astype(int)))
    centroids = np.vstack([micro_embedding[micro_labels == idx].mean(axis=0) for idx in range(micro_count)])
    norm_centroids = normalize_rows(centroids)
    cosine_sim = np.clip((norm_centroids @ norm_centroids.T + 1.0) / 2.0, 0.0, 1.0)
    affinity = 0.18 * cosine_sim
    np.fill_diagonal(affinity, 1.0)

    micro_stats = pd.DataFrame(
        {
            "micro_cluster_id": micro_labels,
            "risk_layer": build_risk_layer_frame(features, argparse.Namespace(high_risk_count=1000, middle_risk_count=2000))["risk_layer"].to_numpy(),
            "dns2_score": features["dns2_ensemble_rank_score"].to_numpy(dtype=float),
            "dns2_pred": features["dns2_pred_label"].to_numpy(dtype=float),
            "dns2_known": features["dns2_known_label"].to_numpy(dtype=float),
        }
    )
    micro_summary = micro_stats.groupby("micro_cluster_id", observed=True).agg(
        size=("dns2_score", "size"),
        mean_dns2_score=("dns2_score", "mean"),
        pred_positive_ratio=("dns2_pred", "mean"),
        known_positive_cnt=("dns2_known", lambda values: int((values == 1).sum())),
        known_negative_cnt=("dns2_known", lambda values: int((values == 0).sum())),
        high_layer_ratio=("risk_layer", lambda values: float((values == "high").mean())),
        low_layer_ratio=("risk_layer", lambda values: float((values == "low").mean())),
    ).reset_index()
    micro_summary["known_total"] = micro_summary["known_positive_cnt"] + micro_summary["known_negative_cnt"]
    micro_summary["known_positive_ratio"] = micro_summary["known_positive_cnt"] / micro_summary["known_total"].replace(0, np.nan)
    micro_summary["known_negative_ratio"] = micro_summary["known_negative_cnt"] / micro_summary["known_total"].replace(0, np.nan)
    micro_summary = micro_summary.fillna(0.0).sort_values("micro_cluster_id").reset_index(drop=True)

    score_values = micro_summary["mean_dns2_score"].to_numpy()
    score_diff = np.abs(score_values[:, None] - score_values[None, :])
    affinity += 0.28 * np.exp(-score_diff / 0.12)

    high_ratio = micro_summary["high_layer_ratio"].to_numpy()
    low_ratio = micro_summary["low_layer_ratio"].to_numpy()
    same_high = (high_ratio[:, None] > 0.6) & (high_ratio[None, :] > 0.6)
    same_low = (low_ratio[:, None] > 0.6) & (low_ratio[None, :] > 0.6)
    affinity += 0.18 * (same_high | same_low)

    # 低度资源 must-link：degree 越低越可信，多个共享资源会自然累加。
    if not graph_context.filtered_edges.empty:
        edge_micro = graph_context.filtered_edges[["encoded_value", "fqdn_no", "resource_degree"]].copy()
        edge_micro["micro_cluster_id"] = edge_micro["fqdn_no"].map(domain_to_micro)
        edge_micro = edge_micro.dropna(subset=["micro_cluster_id"])
        edge_micro["micro_cluster_id"] = edge_micro["micro_cluster_id"].astype(int)
        for _, group in edge_micro.groupby("encoded_value", observed=True):
            micro_ids = sorted(set(group["micro_cluster_id"].tolist()))
            if len(micro_ids) < 2:
                continue
            degree = float(group["resource_degree"].iloc[0])
            weight = config.graph_weight / math.log2(degree + 2.0)
            for left_pos, left in enumerate(micro_ids):
                for right in micro_ids[left_pos + 1 :]:
                    affinity[left, right] += weight
                    affinity[right, left] += weight

    # CNAME 链是强基础设施信号；只保留目标域名也在 DNS3 中的边。
    cname_edges = flint[
        (flint["flintType"].astype(str) == "5")
        & flint["encoded_value"].fillna("").astype(str).str.startswith("fqdn_")
    ][["fqdn_no", "encoded_value"]].dropna().drop_duplicates()
    for row in cname_edges.itertuples(index=False):
        left = domain_to_micro.get(str(row.fqdn_no))
        right = domain_to_micro.get(str(row.encoded_value))
        if left is None or right is None or left == right:
            continue
        affinity[left, right] += config.graph_weight * 0.65
        affinity[right, left] += config.graph_weight * 0.65

    # cannot-link 软惩罚：已知黑锚点和已知白锚点不要轻易合并。
    pos_ratio = micro_summary["known_positive_ratio"].to_numpy()
    neg_ratio = micro_summary["known_negative_ratio"].to_numpy()
    conflict = ((pos_ratio[:, None] >= 0.6) & (neg_ratio[None, :] >= 0.6)) | (
        (neg_ratio[:, None] >= 0.6) & (pos_ratio[None, :] >= 0.6)
    )
    affinity[conflict] *= 0.03

    # 极高风险微簇和低风险微簇之间也压低，但不完全禁止，避免真实类别跨层时被硬切断。
    cross_layer = ((high_ratio[:, None] > 0.7) & (low_ratio[None, :] > 0.7)) | (
        (low_ratio[:, None] > 0.7) & (high_ratio[None, :] > 0.7)
    )
    affinity[cross_layer] *= 0.12
    affinity = np.maximum(affinity, 0.0)
    affinity = (affinity + affinity.T) / 2.0
    np.fill_diagonal(affinity, 1.0)
    return affinity, micro_summary


def fit_constrained_merge_candidate(
    config: MergeConfig,
    features: pd.DataFrame,
    embedding: np.ndarray,
    flint: pd.DataFrame,
    graph_context: LowDegreeGraphContext,
    args: argparse.Namespace,
) -> CandidateResult:
    """生成一个约束微簇合并候选。"""

    micro_labels, micro_frame, micro_model = build_microclusters(features, embedding, config, args)
    micro_embedding, graph_cols = make_graph_priority_embedding(features, embedding)
    affinity, micro_summary = build_micro_affinity(features, flint, graph_context, micro_labels, micro_embedding, config)
    target_k = min(config.target_clusters, affinity.shape[0])
    print(
        f"    constrained merge {config.name}: micro={affinity.shape[0]}, "
        f"target_k={target_k}, graph_weight={config.graph_weight}"
    )
    spectral = SpectralClustering(
        n_clusters=target_k,
        affinity="precomputed",
        assign_labels="kmeans",
        random_state=RANDOM_STATE,
        n_init=20,
    )
    micro_final = spectral.fit_predict(affinity)
    labels = remap_labels_by_size(micro_final[micro_labels])

    detail = micro_frame.merge(graph_context.component_frame, on="fqdn_no", how="left")
    detail["final_micro_cluster_label"] = micro_final[micro_labels]
    sweep = pd.DataFrame(
        [
            {
                "variant": config.name,
                "target_clusters": int(config.target_clusters),
                "actual_clusters": int(len(set(labels))),
                "high_micro_clusters": int(config.high_micro_clusters),
                "low_micro_clusters": int(config.low_micro_clusters),
                "total_micro_clusters": int(affinity.shape[0]),
                "graph_weight": float(config.graph_weight),
                "graph_weighted_feature_count": int(len(graph_cols)),
            }
        ]
    )
    metrics: Dict[str, object] = {
        "candidate_type": "constrained_micro_merge",
        "candidate_target_clusters": int(config.target_clusters),
        "high_micro_clusters": int(config.high_micro_clusters),
        "low_micro_clusters": int(config.low_micro_clusters),
        "total_micro_clusters": int(affinity.shape[0]),
        "constraint_graph_weight": float(config.graph_weight),
        "graph_weighted_feature_count": int(len(graph_cols)),
    }
    metrics.update({f"micro_{key}": value for key, value in micro_model["layer_metrics"].items()})
    return CandidateResult(
        name=config.name,
        labels=labels,
        model={
            "spectral_model": spectral,
            "micro_model": micro_model,
            "micro_summary": micro_summary,
            "graph_weighted_columns": graph_cols,
        },
        sweep=sweep,
        detail_frame=detail,
        metrics=metrics,
    )


def balance_entropy(labels: np.ndarray) -> float:
    counts = pd.Series(labels).value_counts().to_numpy(dtype=float)
    return cluster_balance_score(counts)


def proxy_score(metrics: Dict[str, object], labels: np.ndarray) -> float:
    """隐藏 NMI 不可见时的排序分数。偏向 DNS2 已知结构，同时奖励图约束一致性。"""

    dns2_nmi = float(metrics.get("dns2_known_alignment_nmi") or 0.0)
    graph_pure = float(metrics.get("low_graph_resource_weighted_pure_ratio") or 0.0)
    balance = balance_entropy(labels)
    min_size = int(pd.Series(labels).value_counts().min())
    tiny_penalty = max(0.0, (30.0 - min_size) / 30.0)
    return 0.54 * dns2_nmi + 0.28 * graph_pure + 0.14 * balance - 0.08 * tiny_penalty


def parse_refine_targets(raw: str) -> List[int]:
    targets: List[int] = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        value = int(item)
        if value <= 0:
            raise ValueError("--refine-large-targets 中的值必须为正整数。")
        targets.append(value)
    return sorted(set(targets), reverse=True)


def refine_large_clusters(
    result: CandidateResult,
    features: pd.DataFrame,
    refinement_embedding: np.ndarray,
    max_cluster_size: int,
) -> CandidateResult | None:
    """对过大的最终簇做二次切分，降低“一个大白簇吃掉全部结构”的风险。"""

    labels = result.labels.copy()
    counts = pd.Series(labels).value_counts()
    large_labels = [int(label) for label, count in counts.items() if int(count) > max_cluster_size]
    if not large_labels:
        return None

    pre_refine_labels = labels.copy()
    next_label = int(labels.max() + 1)
    split_records: List[Dict[str, object]] = []
    split_models: Dict[int, MiniBatchKMeans] = {}
    for label in large_labels:
        indices = np.flatnonzero(labels == label)
        split_count = max(2, int(math.ceil(len(indices) / max_cluster_size)))
        print(f"    refine {result.name}: split label={label}, size={len(indices):,}, parts={split_count}")
        model = MiniBatchKMeans(
            n_clusters=split_count,
            batch_size=min(2048, max(128, len(indices))),
            n_init=20,
            max_iter=400,
            random_state=RANDOM_STATE + label,
        )
        split_labels = model.fit_predict(refinement_embedding[indices])
        split_models[label] = model

        # 最大子簇保留原 label，其余子簇分配新 label，之后再统一按大小重映射。
        split_counts = pd.Series(split_labels).value_counts().sort_values(ascending=False)
        keep_split = int(split_counts.index[0])
        for split_label in sorted(set(split_labels.astype(int))):
            split_indices = indices[split_labels == split_label]
            if split_label == keep_split:
                new_label = label
            else:
                new_label = next_label
                next_label += 1
            labels[split_indices] = new_label
            split_records.append(
                {
                    "original_label": int(label),
                    "split_label": int(split_label),
                    "new_label_before_remap": int(new_label),
                    "split_size": int(len(split_indices)),
                    "max_cluster_size": int(max_cluster_size),
                }
            )

    labels = remap_labels_by_size(labels)
    detail = result.detail_frame.copy()
    detail["pre_refine_label"] = pre_refine_labels
    detail["refined_large_cluster_target"] = int(max_cluster_size)
    sweep = pd.concat(
        [
            result.sweep.copy(),
            pd.DataFrame(
                [
                    {
                        "variant": f"{result.name}_refine{max_cluster_size}",
                        "refined_from": result.name,
                        "refine_max_cluster_size": int(max_cluster_size),
                        "split_original_cluster_count": int(len(large_labels)),
                        "actual_clusters": int(len(set(labels))),
                    }
                ]
            ),
        ],
        ignore_index=True,
    )
    metrics = dict(result.metrics)
    metrics.update(
        {
            "candidate_type": "constrained_micro_merge_refined",
            "refined_from": result.name,
            "refine_max_cluster_size": int(max_cluster_size),
            "refine_split_original_cluster_count": int(len(large_labels)),
            "refine_split_piece_count": int(len(split_records)),
        }
    )
    return CandidateResult(
        name=f"{result.name}_refine{max_cluster_size}",
        labels=labels,
        model={
            "base_model": result.model,
            "split_models": split_models,
            "split_records": pd.DataFrame.from_records(split_records),
        },
        sweep=sweep,
        detail_frame=detail,
        metrics=metrics,
    )


def make_variant_paths(paths: ProjectPaths, variant_name: str) -> ProjectPaths:
    """每个候选写到独立目录，避免互相覆盖。"""

    output_dir = paths.output_dir / variant_name
    model_dir = paths.model_dir / variant_name
    output_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)
    return ProjectPaths(paths.project_root, paths.data_dir, output_dir, model_dir)


def write_outputs(
    paths: ProjectPaths,
    features: pd.DataFrame,
    embedding: np.ndarray,
    labels: np.ndarray,
    metrics: Dict[str, object],
    sweep: pd.DataFrame,
    no_zip: bool,
    layer_frame: pd.DataFrame | None = None,
) -> Tuple[Path, Path, Path | None]:
    """写出 label.csv、预测明细、运行报告和提交压缩包。"""

    # 保持 fqdn.csv 原始顺序输出，平台通常会按 fqdn_no 读取，但原始顺序更利于人工核查。
    submit = pd.DataFrame({"fqdn_no": features["fqdn_no"].astype(str), "label": labels.astype(int)})
    submit_path = paths.output_dir / "label.csv"
    submit.to_csv(submit_path, index=False, encoding="utf-8")

    distances = np.linalg.norm(embedding - pd.DataFrame(embedding).groupby(labels).transform("mean").to_numpy(), axis=1)
    detail = features[["fqdn_no", "encoded_fqdn"]].copy()
    detail["label"] = labels.astype(int)
    detail["cluster_distance_to_centroid_like_mean"] = distances
    cluster_size_map = pd.Series(labels).value_counts().to_dict()
    detail["cluster_size"] = detail["label"].map(cluster_size_map)
    if layer_frame is not None:
        detail = detail.merge(layer_frame, on="fqdn_no", how="left")
    detail = detail.sort_values(["label", "cluster_distance_to_centroid_like_mean", "fqdn_no"])
    detail_path = paths.output_dir / "prediction_detail.csv"
    detail.to_csv(detail_path, index=False, encoding="utf-8")

    sweep_path = paths.output_dir / "cluster_sweep.csv"
    sweep.to_csv(sweep_path, index=False, encoding="utf-8")

    cluster_counts = pd.Series(labels).value_counts().sort_index()
    metrics["selected_cluster_count"] = int(len(cluster_counts))
    metrics["min_cluster_size"] = int(cluster_counts.min())
    metrics["max_cluster_size"] = int(cluster_counts.max())

    report_lines = [
        "# DNS3 约束微簇合并运行报告",
        "",
        "## 数据与输出",
        "",
        f"- 数据目录：`{paths.data_dir}`",
        f"- 提交文件：`{submit_path}`",
        f"- 预测明细：`{detail_path}`",
        f"- 簇数：`{len(cluster_counts)}`",
        "",
        "## 聚类规模",
        "",
    ]
    for label, count in cluster_counts.items():
        report_lines.append(f"- cluster `{label}`: `{int(count)}`")
    report_lines.extend(["", "## 指标与参数", ""])
    for key, value in metrics.items():
        report_lines.append(f"- `{key}`: `{value}`")
    report_lines.extend(
        [
            "",
            "## 说明",
            "",
            "- 本题是无监督聚类，`data/dns3/label.csv` 只作为提交格式样例，不参与训练。",
            "- 本版本引入 DNS2 `prediction_detail.csv` 的分数和已知黑白标签作为弱先验特征。",
            "- 本版本先做 DNS2 分层过聚类，再把低度 flint 资源、CNAME 和 DNS2 分数相似性转成微簇约束图。",
            "- 微簇图使用谱聚类合并到目标簇数，目标是保留 DNS2 大结构，同时减少共享低度资源被拆散。",
            "- 输出 `label.csv` 覆盖 `fqdn.csv` 中的全部域名，字段为 `fqdn_no,label`。",
            "- `cluster_sweep.csv` 记录该候选的微簇数、目标簇数和图权重配置。",
        ]
    )
    report_path = paths.output_dir / "run_report.md"
    report_path.write_text("\n".join(report_lines), encoding="utf-8")

    zip_path: Path | None = None
    if not no_zip:
        zip_path = paths.output_dir / "submission_dns3.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.write(submit_path, arcname="label.csv")
            zf.write(report_path, arcname="run_report.md")
    return submit_path, detail_path, zip_path


def main() -> None:
    args = parse_args()
    paths = build_paths(args)
    require_files(paths.data_dir)

    features, data_metrics = prepare_features(paths, args)
    print(f"[信息] 特征表规模: {features.shape[0]:,} 个域名, {features.shape[1] - 2:,} 个结构化特征列")

    print("[向量化] 合并数值、类别和 encoded_fqdn 字符 n-gram 特征...")
    embedding, transformers, matrix_metrics = build_embedding(features, args.svd_components, args.tfidf_max_features)

    print("[图构建] 基于 flint.csv 构造低度共享资源社区...")
    flint_for_graph = read_flint(paths.data_dir, args.quick, args.quick_rows)
    low_graph_context = build_low_degree_graph_context(features, flint_for_graph, args)

    configs = parse_merge_configs(args.config_list)
    refine_targets = parse_refine_targets(args.refine_large_targets)
    refinement_embedding, _ = make_graph_priority_embedding(features, embedding) if refine_targets else (embedding, [])
    summary_rows: List[Dict[str, object]] = []

    for config in configs:
        print(f"[候选] 生成约束合并配置 {config.name} ...")
        result = fit_constrained_merge_candidate(config, features, embedding, flint_for_graph, low_graph_context, args)
        results_to_write = [result]
        for target in refine_targets:
            refined = refine_large_clusters(result, features, refinement_embedding, target)
            if refined is not None:
                results_to_write.append(refined)

        for result in results_to_write:
            metrics: Dict[str, object] = {}
            metrics.update(data_metrics)
            metrics.update(matrix_metrics)
            metrics.update(low_graph_context.metrics)
            metrics.update(result.metrics)
            metrics.update(evaluate_dns2_known_alignment(features, result.labels))
            metrics.update(evaluate_low_graph_resource_purity(low_graph_context, features, result.labels))
            metrics["proxy_score"] = proxy_score(metrics, result.labels)
            metrics["balance_entropy"] = balance_entropy(result.labels)
            metrics["candidate_variant"] = result.name
            metrics["silhouette_sample"] = int(args.silhouette_sample)

            variant_paths = make_variant_paths(paths, result.name)
            submit_path, detail_path, zip_path = write_outputs(
                variant_paths,
                features,
                embedding,
                result.labels,
                metrics,
                result.sweep,
                args.no_zip,
                layer_frame=result.detail_frame,
            )

            model_bundle = {
                "transformers": transformers,
                "candidate_model": result.model,
                "metrics": metrics,
                "sweep": result.sweep,
                "detail_frame": result.detail_frame,
                "low_graph_metrics": low_graph_context.metrics,
                "data_dir": str(paths.data_dir),
            }
            model_path = variant_paths.model_dir / f"{result.name}_pipeline.joblib"
            joblib.dump(model_bundle, model_path)

            summary = {
                "variant": result.name,
                "label_path": str(submit_path),
                "zip_path": str(zip_path) if zip_path is not None else "",
                "model_path": str(model_path),
                "cluster_count": int(len(set(result.labels))),
                "min_cluster_size": int(pd.Series(result.labels).value_counts().min()),
                "max_cluster_size": int(pd.Series(result.labels).value_counts().max()),
                "balance_entropy": metrics.get("balance_entropy"),
                "proxy_score": metrics.get("proxy_score"),
            }
            for key in [
                "candidate_type",
                "dns2_known_alignment_nmi",
                "dns2_known_alignment_ari",
                "low_graph_resource_pure_ratio",
                "low_graph_resource_weighted_pure_ratio",
            ]:
                summary[key] = metrics.get(key)
            summary_rows.append(summary)
            print(f"[完成] {result.name}: {submit_path}")

    summary_frame = pd.DataFrame(summary_rows)
    summary_frame = summary_frame.sort_values("proxy_score", ascending=False)
    summary_path = paths.output_dir / "sweep_summary.csv"
    summary_frame.to_csv(summary_path, index=False, encoding="utf-8")

    common_model_path = paths.model_dir / "common_feature_embedding.joblib"
    joblib.dump(
        {
            "transformers": transformers,
            "data_metrics": data_metrics,
            "matrix_metrics": matrix_metrics,
            "low_graph_metrics": low_graph_context.metrics,
            "candidate_summary": summary_frame,
            "data_dir": str(paths.data_dir),
        },
        common_model_path,
    )
    print(f"[完成] 候选汇总: {summary_path}")
    print(f"[完成] 公共特征模型: {common_model_path}")
    if not summary_frame.empty:
        best = summary_frame.iloc[0]
        print(f"[建议] 当前代理指标最优: {best['variant']} -> {best['label_path']}")


if __name__ == "__main__":
    main()
