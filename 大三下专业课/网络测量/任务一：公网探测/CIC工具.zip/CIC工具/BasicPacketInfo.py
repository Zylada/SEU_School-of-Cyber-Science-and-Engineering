class BasicPacketInfo:
    """Common packet representation for flow assembly."""

    TCP_PROTOCOL = 6
    UDP_PROTOCOL = 17

    def __init__(
        self,
        generator,
        srcIP,
        dstIP,
        srcPort,
        dstPort,
        protocol,
        timeStamp,
        headBytes,
        payloadBytes,
        flags,
        TCPWindow,
        payload,
    ):
        self.id = generator.nextId()
        self.srcIP = srcIP
        self.dstIP = dstIP
        self.srcPort = srcPort
        self.dstPort = dstPort
        self.protocol = protocol
        self.timeStamp = timeStamp
        self.headBytes = headBytes
        self.payloadBytes = payloadBytes
        self.flags = flags
        self.TCPWindow = TCPWindow
        self.payload = payload
        self.fwdFlowId = self.generateFlowId(True)
        self.bwdFlowId = self.generateFlowId(False)

    def generateFlowId(self, forward: bool) -> str:
        if forward:
            return (
                f"{self.srcIP}-{self.srcPort}-"
                f"{self.dstIP}-{self.dstPort}-{self.protocol}"
            )

        return (
            f"{self.dstIP}-{self.dstPort}-"
            f"{self.srcIP}-{self.srcPort}-{self.protocol}"
        )

    def getSrcIP(self) -> str:
        return self.srcIP

    def getDstIP(self) -> str:
        return self.dstIP

    def getSrcPort(self) -> int:
        return self.srcPort

    def getDstPort(self) -> int:
        return self.dstPort

    def getProtocol(self) -> int:
        return self.protocol

    def getTimeStamp(self) -> int:
        return self.timeStamp

    def getHeadBytes(self) -> int:
        return self.headBytes

    def getPayloadBytes(self) -> int:
        return self.payloadBytes

    def getFlags(self) -> int:
        return self.flags

    def getTCPWindow(self) -> int:
        return self.TCPWindow

    def getPayload(self):
        return self.payload

    def getFwdFlowId(self) -> str:
        return self.fwdFlowId

    def getBwdFlowId(self) -> str:
        return self.bwdFlowId

    def isTCP(self) -> bool:
        return self.protocol == self.TCP_PROTOCOL

    def isUDP(self) -> bool:
        return self.protocol == self.UDP_PROTOCOL

    def hasFlagFIN(self) -> bool:
        return bool(self.flags & 1)

    def hasFlagSYN(self) -> bool:
        return bool((self.flags >> 1) & 1)

    def hasFlagRST(self) -> bool:
        return bool((self.flags >> 2) & 1)

    def hasFlagPSH(self) -> bool:
        return bool((self.flags >> 3) & 1)

    def hasFlagACK(self) -> bool:
        return bool((self.flags >> 4) & 1)

    def hasFlagURG(self) -> bool:
        return bool((self.flags >> 5) & 1)

    def hasFlagECE(self) -> bool:
        return bool((self.flags >> 6) & 1)

    def hasFlagCWR(self) -> bool:
        return bool((self.flags >> 7) & 1)
