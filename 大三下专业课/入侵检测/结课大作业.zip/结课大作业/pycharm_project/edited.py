import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings('ignore')

# ======================== 请修改这里的路径 ========================
DATA_PATH = r'C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question'
OUTPUT_PATH = r'C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\result'
# ================================================================

os.makedirs(OUTPUT_PATH, exist_ok=True)

print("正在读取数据...")
fqdn_df = pd.read_csv(os.path.join(DATA_PATH, 'fqdn.csv'))
access_df = pd.read_csv(os.path.join(DATA_PATH, 'access.csv'))
flint_df = pd.read_csv(os.path.join(DATA_PATH, 'flint.csv'))
ip_df = pd.read_csv(os.path.join(DATA_PATH, 'ip.csv'))
ipv6_df = pd.read_csv(os.path.join(DATA_PATH, 'ipv6.csv'))
print("数据读取完成。")

# ======================== 1. 特征工程 ========================

# ---------- 1.1 access.csv 特征 ----------
access_agg = access_df.groupby('fqdn_no').agg(
    total_requests=('request_cnt', 'sum'),
    active_hours=('hour', 'nunique'),
    avg_total_req=('total_request', 'mean')
).reset_index()

# 凌晨请求比例
access_df['is_night'] = (access_df['hour'] < 6).astype(int)
night_req = access_df[access_df['is_night']==1].groupby('fqdn_no')['request_cnt'].sum().rename('night_requests')
access_agg = access_agg.merge(night_req, on='fqdn_no', how='left')
access_agg['night_ratio'] = access_agg['night_requests'] / (access_agg['total_requests'] + 1e-6)
access_agg.fillna(0, inplace=True)
access_agg.drop('night_requests', axis=1, inplace=True)

# 时间分布熵
hourly_sum = access_df.groupby(['fqdn_no', 'hour'])['request_cnt'].sum().reset_index()
def entropy(series):
    probs = series / (series.sum() + 1e-9)
    return -np.sum(probs * np.log2(probs + 1e-9))
hourly_entropy = hourly_sum.groupby('fqdn_no')['request_cnt'].apply(entropy).rename('hour_entropy')
access_agg = access_agg.merge(hourly_entropy, on='fqdn_no', how='left')
access_agg['hour_entropy'].fillna(0, inplace=True)

# ---------- 1.2 flint.csv 特征 ----------
# 确保 ttl 列为数值
flint_df['ttl'] = pd.to_numeric(flint_df['ttl'], errors='coerce')
flint_agg = flint_df.groupby('fqdn_no').agg(
    avg_ttl=('ttl', 'mean'),
    std_ttl=('ttl', 'std'),
    unique_resolved=('encoded_value', 'nunique'),
    cname_ratio=('flintType', lambda x: (x == 'cname').mean())
).reset_index()
flint_agg['total_records'] = flint_df.groupby('fqdn_no').size().values
flint_agg.fillna(0, inplace=True)

# ---------- 1.3 IP 地理特征（IPv4 + IPv6） ----------
ip_all = pd.concat([ip_df, ipv6_df], ignore_index=True)
ip_records = flint_df[flint_df['flintType'].isin(['A', 'AAAA'])].copy()
ip_records = ip_records[ip_records['encoded_value'].str.contains(':', na=False)]
if not ip_records.empty:
    ip_info = ip_records.merge(ip_all, left_on='encoded_value', right_on='encoded_ip', how='left')
    country_agg = ip_info.groupby('fqdn_no')['country'].nunique().rename('n_countries').reset_index()
    isp_agg = ip_info.groupby('fqdn_no')['isp'].nunique().rename('n_isp').reset_index()
    flint_agg = flint_agg.merge(country_agg, on='fqdn_no', how='left')
    flint_agg = flint_agg.merge(isp_agg, on='fqdn_no', how='left')
    flint_agg[['n_countries', 'n_isp']] = flint_agg[['n_countries', 'n_isp']].fillna(0)
else:
    flint_agg['n_countries'] = 0
    flint_agg['n_isp'] = 0

# ---------- 1.4 域名结构特征 ----------
fqdn_df['tld'] = fqdn_df['encoded_fqdn'].str.split('.').str[-1]
top_tlds = fqdn_df['tld'].value_counts().head(5).index.tolist()
fqdn_df['tld_group'] = fqdn_df['tld'].apply(lambda x: x if x in top_tlds else 'other')
tld_dummies = pd.get_dummies(fqdn_df['tld_group'], prefix='tld')
fqdn_df = pd.concat([fqdn_df, tld_dummies], axis=1)

# ---------- 1.5 合并所有特征 ----------
all_fqdn = fqdn_df[['fqdn_no']].copy()
feature_df = all_fqdn.merge(access_agg, on='fqdn_no', how='left')
feature_df = feature_df.merge(flint_agg, on='fqdn_no', how='left')
tld_cols = [c for c in fqdn_df.columns if c.startswith('tld_')]
feature_df = feature_df.merge(fqdn_df[['fqdn_no'] + tld_cols], on='fqdn_no', how='left')
feature_df.fillna(0, inplace=True)

# ========== 关键修复：确保所有特征列都是数值类型 ==========
feature_cols = [
    'total_requests', 'active_hours', 'avg_total_req', 'night_ratio', 'hour_entropy',
    'avg_ttl', 'std_ttl', 'unique_resolved', 'cname_ratio', 'total_records',
    'n_countries', 'n_isp'
] + tld_cols

# 强制转换所有特征列为数值，非数值转为 NaN 后再填充 0
for col in feature_cols:
    if col in feature_df.columns:
        feature_df[col] = pd.to_numeric(feature_df[col], errors='coerce')
feature_df[feature_cols] = feature_df[feature_cols].fillna(0)

# 移除零方差特征
valid_cols = []
for col in feature_cols:
    if col in feature_df.columns:
        if feature_df[col].std() != 0:
            valid_cols.append(col)
        else:
            print(f"移除零方差特征: {col}")

X = feature_df[valid_cols].values

# 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

print(f"特征矩阵形状: {X_scaled.shape}")

# ======================== 2. 聚类（固定簇数） ========================
FINAL_K = 5
print(f"使用固定簇数: {FINAL_K}")

kmeans = KMeans(n_clusters=FINAL_K, random_state=42, n_init=10)
cluster_labels = kmeans.fit_predict(X_scaled)

result_df = feature_df[['fqdn_no']].copy()
result_df['label'] = cluster_labels

# ======================== 3. 保存结果 ========================
result_df.to_csv(os.path.join(OUTPUT_PATH, 'label.csv'), index=False)
print(f"结果已保存至 {OUTPUT_PATH}\\label.csv")
print("前10行预览：")
print(result_df.head(10))
print("\n各簇样本数：")
print(result_df['label'].value_counts().sort_index())