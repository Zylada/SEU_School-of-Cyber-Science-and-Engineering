# ===== DBSCAN_final.py：13特征 + 相关性分析 + 精简特征 + DBSCAN =====
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import DBSCAN, KMeans
from sklearn.preprocessing import StandardScaler
from sklearn import metrics

# ==================== 路径 ====================
base =r'C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question'
# =============================================

# ---------- 1. 读取数据 ----------
print("正在读取数据...")
fqdn_all = pd.read_csv(f"{base}/fqdn.csv")
access_all = pd.read_csv(f"{base}/access.csv")
flint_all = pd.read_csv(f"{base}/flint.csv")

# 读取 IPv4 和 IPv6 信息，合并为一张统一的 IP 表
ip_v4 = pd.read_csv(f"{base}/ip.csv")
ip_v6 = pd.read_csv(f"{base}/ipv6.csv")
ip_all = pd.concat([ip_v4, ip_v6], ignore_index=True)
print(f"合并后 IP 信息表形状: {ip_all.shape}")

# ---------- 2. 特征工程 ----------
print("正在聚合 access 特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique'),
    active_hours=('hour', 'nunique'),
    request_variance=('request_cnt', 'var')
).reset_index()

print("正在聚合 flint 特征...")
flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean'),
    ttl_std=('ttl', 'std'),
    unique_resolved_values=('encoded_value', 'nunique')
).reset_index()

print("正在聚合 IP 特征...")
ip_info = ip_all[['encoded_ip', 'country', 'city', 'isp']]
access_with_ip = access_all.merge(ip_info, on='encoded_ip', how='left')
ip_feat = access_with_ip.groupby('fqdn_no').agg(
    num_countries=('country', 'nunique'),
    overseas_ratio=('country', lambda x: (x != '中国').mean()),
    num_cities=('city', 'nunique'),
    num_isps=('isp', 'nunique'),
    cloud_ratio=('isp', lambda x: x.str.lower().str.contains(
        'amazon|google|cloud|azure|tencent|aliyun', na=False).mean())
).reset_index()
ip_feat.fillna({'num_countries': 0, 'overseas_ratio': 0,
                'num_cities': 0, 'num_isps': 0, 'cloud_ratio': 0}, inplace=True)

# ---------- 3. 拼接 ----------
features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features = features.merge(ip_feat, on='fqdn_no', how='left')
features.fillna(0, inplace=True)
features.to_csv('features_raw_DBSCAN.csv', index=False)

print(f"特征矩阵形状: {features.shape}")

# ---------- 4. 13个特征的列表 ----------
feature_cols_13 = [
    'total_request_cnt', 'unique_ips', 'active_hours', 'request_variance',
    'flint_records', 'avg_ttl', 'ttl_std', 'unique_resolved_values',
    'num_countries', 'overseas_ratio', 'num_cities', 'num_isps', 'cloud_ratio'
]

# ---------- 5. 相关性分析 ----------
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

corr_matrix = features[feature_cols_13].corr()

plt.figure(figsize=(14, 10))
sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='coolwarm',
            square=True, linewidths=0.5)
plt.title('13个特征之间的相关系数矩阵')
plt.tight_layout()
plt.savefig('feature_correlation_dbscan.png', dpi=150)
plt.show()

print("\n高度相关的特征对（|r| > 0.85）：")
for i in range(len(feature_cols_13)):
    for j in range(i+1, len(feature_cols_13)):
        if abs(corr_matrix.iloc[i, j]) > 0.85:
            print(f"  {feature_cols_13[i]} <-> {feature_cols_13[j]}: {corr_matrix.iloc[i, j]:.3f}")

# ---------- 6. 精简特征集 ----------
feature_cols_selected = [
    'active_hours',          # F值最高，关键特征
    'num_isps',              # F值第二高
    'num_countries',         # F值第三高（与num_isps相关0.85，可二选一，但都保留试试）
    'num_cities',            # F值第四高
    'ttl_std',               # TTL波动，恶意域名常见
    'avg_ttl',               # 平均TTL
    'unique_ips',            # F值88，比total_request_cnt高（23）
    'overseas_ratio'         # 虽然F值不高，但理论上重要，且均值表中差异明显
]

print(f"\n精简特征集: {feature_cols_selected}")

# ---------- 7. 标准化 + DBSCAN ----------
X = features[feature_cols_selected].values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 参数测试
param_grid = [
    (0.5, 5), (0.5, 10), (0.7, 5), (0.7, 10),
    (1.0, 5), (1.0, 10), (1.2, 5), (1.2, 10)
]

print("\n===== DBSCAN 参数搜索 =====")
for eps, min_s in param_grid:
    db = DBSCAN(eps=eps, min_samples=min_s, n_jobs=-1)
    labels = db.fit_predict(X_scaled)
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise = list(labels).count(-1)
    if n_clusters > 1:
        sil = metrics.silhouette_score(X_scaled, labels)
    else:
        sil = -1
    print(f"eps={eps}, min_samples={min_s}: 簇数={n_clusters}, 噪声点={n_noise}, 轮廓系数={sil:.4f}")

# 选择最优参数
best_eps = 1.2
best_min_samples = 10
print(f"\n选择 eps={best_eps}, min_samples={best_min_samples} 进行最终聚类...")

dbscan = DBSCAN(eps=best_eps, min_samples=best_min_samples, n_jobs=-1)
features['label'] = dbscan.fit_predict(X_scaled)

# 若簇数不等于5，简单合并噪声点
if len(set(features['label'])) - (1 if -1 in features['label'].values else 0) != 5:
    print("簇数不等于5，进行后处理...")
    mask_non_noise = features['label'] != -1
    X_non = X_scaled[mask_non_noise]
    km = KMeans(n_clusters=5, random_state=42, n_init=10)
    new_labels = km.fit_predict(X_non)
    final = np.full(len(features), -1, dtype=int)
    final[mask_non_noise] = new_labels
    # 噪声点分配到最近质心
    from scipy.spatial.distance import cdist
    noise_idx = np.where(~mask_non_noise)[0]
    dists = cdist(X_scaled[noise_idx], km.cluster_centers_, metric='euclidean')
    final[noise_idx] = np.argmin(dists, axis=1)
    features['label'] = final

features['label'] = features['label'].astype(int)
print("最终簇分布:")
print(features['label'].value_counts().sort_index())

# ---------- 8. 保存 ----------
submit = features[['fqdn_no', 'label']]
submit['label'] = submit['label'].astype(int)
submit.to_csv('result_dbscan2.csv', index=False)
print("\n结果已保存为 result_dbscan2.csv")