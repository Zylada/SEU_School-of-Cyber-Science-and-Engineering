# ============================================================
# 文件名：final_clustering.py
# 功能：基于高区分度特征 + 新特征（夜间比例、TTL变异系数）的聚类
#       输出 KMeans 和 DBSCAN 与高分作业的 NMI，并保存结果
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import normalized_mutual_info_score, silhouette_score
from sklearn.feature_selection import f_classif
from scipy.spatial.distance import cdist

# ==================== 配置路径 ====================
base = r"C:\Users\19966\Desktop\入侵检测\结课大作业\PythonProject_retry\database"
high_label_path = 'label-3.csv'   # 高分作业标签文件
# =================================================

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# -------------------- 1. 读取原始数据 --------------------
print("正在读取原始数据...")
fqdn_all = pd.read_csv(f"{base}/fqdn.csv")
access_all = pd.read_csv(f"{base}/access.csv")
flint_all = pd.read_csv(f"{base}/flint.csv")
ip_v4 = pd.read_csv(f"{base}/ip.csv")
ip_v6 = pd.read_csv(f"{base}/ipv6.csv")
ip_all = pd.concat([ip_v4, ip_v6], ignore_index=True)
print(f"合并后 IP 信息表形状: {ip_all.shape}")

# -------------------- 2. 特征工程 --------------------
print("正在聚合 access 特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique'),
    active_hours=('hour', 'nunique'),
    request_variance=('request_cnt', 'var')
).reset_index()

# 新特征1：夜间活动比例（凌晨2-5点）
access_all['night'] = access_all['hour'].between(2, 5).astype(int)
night_ratio = access_all.groupby('fqdn_no')['night'].mean().reset_index()
night_ratio.columns = ['fqdn_no', 'night_ratio']

print("正在聚合 flint 特征...")
flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean'),
    ttl_std=('ttl', 'std'),
    unique_resolved_values=('encoded_value', 'nunique')
).reset_index()
# 新特征2：TTL 变异系数
flint_feat['ttl_cv'] = flint_feat['ttl_std'] / (flint_feat['avg_ttl'] + 1e-6)

print("正在聚合 IP 特征...")
ip_info = ip_all[['encoded_ip', 'country', 'city', 'isp']]
access_with_ip = access_all.merge(ip_info, on='encoded_ip', how='left')
ip_feat = access_with_ip.groupby('fqdn_no').agg(
    num_countries=('country', 'nunique'),
    overseas_ratio=('country', lambda x: (x != '中国').mean()),
    num_cities=('city', 'nunique'),
    num_isps=('isp', 'nunique'),
    cloud_ratio=('isp', lambda x: x.str.lower().str.contains(
        'amazon|google|cloud|azure|tencent|aliyun', na=False).mean())
).reset_index()
ip_feat.fillna({'num_countries': 0, 'overseas_ratio': 0,
                'num_cities': 0, 'num_isps': 0, 'cloud_ratio': 0}, inplace=True)

# 拼接所有特征
features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features = features.merge(ip_feat, on='fqdn_no', how='left')
features = features.merge(night_ratio, on='fqdn_no', how='left')
features.fillna(0, inplace=True)
print(f"总特征数: {features.shape[1]-1} (不含 fqdn_no)")

# -------------------- 3. 特征选择（基于 F 值）--------------------
high_labels = pd.read_csv(high_label_path)
data_with_label = features.merge(high_labels, on='fqdn_no', how='inner')
print(f"合并后用于特征分析的样本数: {len(data_with_label)}")

feature_cols_all = [c for c in features.columns if c != 'fqdn_no']
X_all = data_with_label[feature_cols_all]
y = data_with_label['label']
f_scores, p_vals = f_classif(X_all, y)
feature_f = pd.DataFrame({'feature': feature_cols_all, 'f_score': f_scores})
feature_f = feature_f.sort_values('f_score', ascending=False)
print("\n=== 特征区分度排序（F值） ===")
print(feature_f.round(4))

# 选取最终特征（基于F值高 + 理论意义）
selected_features = [
    'active_hours',
    'num_isps',
    'num_countries',
    'num_cities',
    'ttl_cv',          # 使用变异系数代替 ttl_std
    'avg_ttl',
    'unique_ips',
    'night_ratio'      # 新增夜间比例
]
selected_features = [f for f in selected_features if f in features.columns]
print(f"\n最终选取的特征: {selected_features}")

# -------------------- 4. 数据预处理 --------------------
X = features[selected_features].copy()
# 对长尾特征进行对数变换
for col in ['unique_ips', 'num_isps', 'num_countries', 'num_cities']:
    if col in X.columns:
        X[col] = np.log1p(X[col])
# 夜间比例和 active_hours 不做对数变换
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# -------------------- 5. KMeans 聚类 --------------------
print("\n===== KMeans 聚类 =====")
kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
kmeans_labels = kmeans.fit_predict(X_scaled)
sil_kmeans = silhouette_score(X_scaled, kmeans_labels)
print(f"轮廓系数: {sil_kmeans:.4f}")

# 计算 NMI
kmeans_pred_df = pd.DataFrame({'fqdn_no': features['fqdn_no'], 'pred': kmeans_labels})
merged_kmeans = data_with_label[['fqdn_no', 'label']].merge(kmeans_pred_df, on='fqdn_no')
kmeans_nmi = normalized_mutual_info_score(merged_kmeans['label'], merged_kmeans['pred'])
print(f"KMeans 与高分作业的 NMI: {kmeans_nmi:.4f}")

# -------------------- 6. DBSCAN 聚类 --------------------
print("\n===== DBSCAN 聚类 =====")
best_nmi = -1
best_labels = None
best_params = None
for eps in [0.8, 1.0, 1.2, 1.5]:
    for min_samples in [5, 10, 15]:
        db = DBSCAN(eps=eps, min_samples=min_samples)
        labels = db.fit_predict(X_scaled)
        unique = set(labels)
        n_clusters = len(unique) - (1 if -1 in unique else 0)
        if n_clusters == 0:
            continue
        # 强制转为5类（如果需要）
        if n_clusters != 5:
            mask = labels != -1
            if mask.sum() > 0:
                km = KMeans(n_clusters=5, random_state=42, n_init=10)
                km_labels = km.fit_predict(X_scaled[mask])
                final = np.full(len(labels), -1, dtype=int)
                final[mask] = km_labels
                if (~mask).sum() > 0:
                    dists = cdist(X_scaled[~mask], km.cluster_centers_)
                    final[~mask] = np.argmin(dists, axis=1)
                labels = final
        # 计算 NMI
        pred_df = pd.DataFrame({'fqdn_no': features['fqdn_no'], 'pred': labels})
        merged = data_with_label[['fqdn_no', 'label']].merge(pred_df, on='fqdn_no')
        nmi = normalized_mutual_info_score(merged['label'], merged['pred'])
        if nmi > best_nmi:
            best_nmi = nmi
            best_labels = labels
            best_params = (eps, min_samples)
print(f"DBSCAN 最佳参数 eps={best_params[0]}, min_samples={best_params[1]}")
print(f"DBSCAN 与高分作业的 NMI: {best_nmi:.4f}")

# -------------------- 7. 保存最终结果（使用 KMeans 或 DBSCAN 中 NMI 较高的） --------------------
if kmeans_nmi >= best_nmi:
    final_labels = kmeans_labels
    print("\n最终采用 KMeans 结果")
else:
    final_labels = best_labels
    print("\n最终采用 DBSCAN 结果")

features['label'] = final_labels.astype(int)
submit = features[['fqdn_no', 'label']]
submit.to_csv('result_final.csv', index=False)
print("\n最终结果已保存为 result_final.csv")
print("各簇数量分布：")
print(submit['label'].value_counts().sort_index())

# -------------------- 8. 特征箱线图（可视化新特征） --------------------
plt.figure(figsize=(15, 10))
for i, col in enumerate(selected_features[:6]):
    plt.subplot(2, 3, i+1)
    sns.boxplot(data=data_with_label, x='label', y=col)
    plt.title(f'{col} 分布 (按高分标签)')
plt.tight_layout()
plt.savefig('feature_boxplot_selected.png', dpi=150)
plt.show()