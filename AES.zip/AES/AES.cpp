#include<iostream>
#include <vector>
#include"Rijndael.h"
#pragma warning(disable:4996)
using namespace std;
//Nk：4列
//Nr：10轮round

//AES加密函数
void AesEncrypt(vector<vector<unsigned char>>& state, vector<vector<unsigned char>>& expandedKey, int Nr)
{
	int round;
	//第1轮之前：轮密钥加
	AddRoundKey(state, expandedKey, 0);
	//第1-9轮：字节代换、行移位、列混合、轮密钥加
	for (round = 1; round <= (Nr - 1); round++)
	{
		SubBytes(state);
		ShiftRows(state);
		MixColumns(state);
		AddRoundKey(state, expandedKey, round);
	}
	//第10轮：字节代换、行移位、轮密钥加
	SubBytes(state);
	ShiftRows(state);
	AddRoundKey(state, expandedKey, Nr);
}
//AES 解密函数
void AesDecrypt(vector<vector<unsigned char>>& state, vector<vector<unsigned char>>& expandedKey, int Nr)
{
	int x;
	AddRoundKey(state, expandedKey, Nr);
	InvShiftRows(state);
	InvSubBytes(state);
	for (x = (Nr - 1); x >= 1; x--)
	{
		AddRoundKey(state, expandedKey, x);
		InvMixColumns(state);
		InvShiftRows(state);
		InvSubBytes(state);
	}
	AddRoundKey(state, expandedKey, 0);
}
int main()
{
	vector<unsigned char> key(17);
	vector<vector<unsigned char>> plainText(4, vector<unsigned char>(4, 0));
	vector<vector<unsigned char>> expansionKey(16, vector<unsigned char>(16, 0));
	cout << "Please enter plaintext (length = 16):\n";
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cin >> plainText[i][j];
		}
	}
	cout<<"please input key (length = 16):\n";
	for (int i = 0; i < 16; i++)
	{
		cin >> key[i];
	}
	
	//加密过程
	ScheduleKey(key, expansionKey);//密钥扩展生成
	AesEncrypt(plainText, expansionKey, 10);//调用AES 加密
	cout << "The ciphertext is: ";
	//输出密文
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cout << "%02x ", plainText[i][j];
		}
	}
	//解密过程
	AesDecrypt(plainText, expansionKey, 10);
	cout << "The decrypted plaintext is: ";
	//输出明文
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			cout << plainText[i][j];
		}
	}
	cout << endl;
	return 0;
}
