import pandas as pd

# 读前10行
ip = pd.read_csv(r'C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\ip.csv', nrows=10)
print(ip.head())
print(f"\n列名: {list(ip.columns)}")
print(f"总行数估计: 全读后再看")