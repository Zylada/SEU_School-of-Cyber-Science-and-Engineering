import pandas as pd

label1 = pd.read_csv(r"C:\Users\19966\Desktop\label-1.csv")  # 任务一的标签文件
print("唯一家族编号:", sorted(label1['family_no'].unique()))
print("各类数量:\n", label1['family_no'].value_counts().sort_index())