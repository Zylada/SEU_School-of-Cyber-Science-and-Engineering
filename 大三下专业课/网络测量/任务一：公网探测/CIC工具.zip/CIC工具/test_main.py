from PacketReader import PacketReader
from FlowGenerator import FlowGenerator
import os
"""
    struct.unpack用法
    H--integer 2个字节
    I--integer 4个字节
    符号! 表示以大端模式(Big-Endian)读取字节,
    即 高位字节 排放在 内存的低地址端,低位字节 排放在 内存的高地址端
    不加符号 表示以小端模式(Little-Endian)读取字节,
    即 高位字节 排放在 内存的高地址端,低位字节 排放在 内存的低地址端
    例如内存中由低到高存放了两个字节 0x12 0x34,
    大端模式下其值为 4*1+3*16+2*256+1*4096=4660
    小端模式下其值为 2*1+1*16+4*256+3*4096=13330
"""

file_path = "D:/26418/python code/视频流量/kuaishou/kuaishou2024_07_30_152749.pcap"
flowTimeout = 120000000
activityTimeout = 5000000
subFlowTimeout = 1000000
bulkTimeout = 1000000
print(f"开始读取文件: {file_path}")

packetReader = PacketReader(file_path)
flowGenerator = FlowGenerator(flowTimeout, activityTimeout, subFlowTimeout, bulkTimeout, file_path)

# 统计信息
total_packets = 0
processed_packets = 0

basicPacket = packetReader.nextPacket()
while basicPacket != None:
    total_packets += 1
    if basicPacket:  # 确保数据包有效
        processed_packets += 1
        flowGenerator.addPacket(basicPacket)

    # 每处理1000个包输出一次进度
    if total_packets % 1000 == 0:
        print(f"已处理 {total_packets} 个数据包，有效包: {processed_packets}")

    basicPacket = packetReader.nextPacket()

print(f"数据包读取完成，总计: {total_packets}，有效包: {processed_packets}")

# 清理并生成特征
flowGenerator.clearFlow()
print(f"生成的流数量: {len(flowGenerator.finishedFlows)}")

if len(flowGenerator.finishedFlows) > 0:
    flowGenerator.dumpFeatureToCSV()
    print("特征提取完成！")
else:
    print("警告：没有生成任何流特征！")

file_path = "D:/26418/python code/视频流量/kuaishou/kuaishou2024_07_30_152749.pcap"
print(f"文件大小: {os.path.getsize(file_path)} 字节")

    # 读取文件头检查格式
with open(file_path, 'rb') as f:
     header = f.read(4)
     print(f"文件头: {header.hex()}")