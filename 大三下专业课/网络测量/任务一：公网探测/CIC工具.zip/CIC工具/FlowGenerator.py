import csv
import os

from BasicPacketInfo import BasicPacketInfo
from BasicFlow import BasicFlow
import FlowFeature


class FlowGenerator:
    """Reassemble packets into bidirectional flows."""

    def __init__(
        self,
        flowTimeout,
        activityTimeout,
        subFlowTimeout,
        bulkTimeout,
        input_filename=None,
        output_dir=None,
    ):
        self.currentFlows = {}
        self.finishedFlows = []
        self.flowTimeout = flowTimeout
        self.activityTimeout = activityTimeout
        self.subFlowTimeout = subFlowTimeout
        self.bulkTimeout = bulkTimeout
        self.input_filename = input_filename
        self.output_dir = output_dir

    def addPacket(self, packet: BasicPacketInfo):
        if packet is None:
            return

        currentTS = packet.getTimeStamp()
        pktFwdFlowId = packet.getFwdFlowId()
        pktBwdFlowId = packet.getBwdFlowId()

        if (pktFwdFlowId in self.currentFlows) or (pktBwdFlowId in self.currentFlows):
            flowId = pktFwdFlowId if pktFwdFlowId in self.currentFlows else pktBwdFlowId
            flow = flowType(self.currentFlows[flowId])

            if currentTS - flow.getFlowLastTime() > self.flowTimeout:
                self.finishFlow(flow)
                self.currentFlows[flowId] = self.buildFlow(packet)

                if len(self.finishedFlows) % 100 == 0:
                    print(len(self.finishedFlows))

            elif packet.isTCP() and packet.hasFlagRST():
                flow.addPacket(packet=packet)
                self.finishFlow(flow)
                self.currentFlows.pop(flowId)

                if len(self.finishedFlows) % 100 == 0:
                    print(len(self.finishedFlows))

            elif (
                packet.isTCP()
                and flow.getFwdFINFlags() == 1
                and flow.getBwdFINFlags() == 1
            ):
                flow.addPacket(packet=packet)

                if packet.getPayloadBytes() == 0:
                    self.finishFlow(flow)
                    self.currentFlows.pop(flowId)

                    if len(self.finishedFlows) % 100 == 0:
                        print(len(self.finishedFlows))

            else:
                flow.addPacket(packet=packet)
                if packet.isTCP() and packet.hasFlagFIN():
                    if flow.getSrcIP() == packet.getSrcIP():
                        flow.setFwdFINFlags()
                    else:
                        flow.setBwdFINFlags()
        else:
            self.currentFlows[pktFwdFlowId] = self.buildFlow(packet)

    def buildFlow(self, packet: BasicPacketInfo) -> BasicFlow:
        return BasicFlow(
            packet=packet,
            activityTimeout=self.activityTimeout,
            subFlowTimeout=self.subFlowTimeout,
            bulkTimeout=self.bulkTimeout,
        )

    def finishFlow(self, flow: BasicFlow):
        flow = flowType(flow)
        if flow.getPktCnt() <= 0:
            return

        flow.endSession()
        self.finishedFlows.append(flow)

    def clearFlow(self):
        for flow in self.currentFlows.values():
            self.finishFlow(flow)
        self.currentFlows.clear()

    def dumpFeatureToCSV(self):
        output_dir = self.output_dir or os.path.abspath("result")
        os.makedirs(output_dir, exist_ok=True)

        if self.input_filename:
            base_name = os.path.basename(self.input_filename)
            csv_filename = os.path.join(
                output_dir, os.path.splitext(base_name)[0] + ".csv"
            )
        else:
            csv_filename = os.path.join(output_dir, "test.csv")

        with open(csv_filename, "w", newline="", encoding="utf-8") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(FlowFeature.getCsvColName())

            for flow in self.finishedFlows:
                flow = flowType(flow)
                writer.writerow(flow.generateFlowFeatures())

        print(f"Features saved to: {csv_filename}")


def flowType(flow: BasicFlow) -> BasicFlow:
    return flow
