#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include "crypto.h"
#include <stdio.h>
#include <time.h>
using namespace std;

Crypto::Crypto()//无参构造函数
{
	this->_g = (unsigned)rand() % 9 + 2;
	this->_p = create_big_integer();
	this->_private = (size_t)rand() % this->_p; 
	this->_pub_key = pow_mod(this->_g, this->_private, this->_p);
	this->_pri_key = new char[2 * sizeof(size_t) + 1];
	this->_public = new size_t[2];
}

Crypto::Crypto(size_t g, size_t p)//包含公共参数g,p的构造函数
{
	this->_g = g;
	this->_p = p;
	this->_private = (size_t)rand() % this->_p; 
	this->_pub_key = pow_mod(this->_g, this->_private, this->_p);
	this->_pri_key = new char[2*sizeof(size_t) + 1];
	this->_public = new size_t[2];
}

void Crypto::init()//种子初始化
{
	srand((unsigned)time(0));
}

size_t* Crypto::get_public()//获得并输出公共参数
{
	this->_public[0] = _g;
	this->_public[1] = _p;
	cout <<"The (g,p) is :" << "(" << _g << "," << _p << ")" << endl;
	return this->_public;
}

size_t Crypto::get_pub_key()//获得并输出公钥
{
	return this->_pub_key;
}

char* Crypto::get_key(size_t pub_key)//获得8位的密钥
{
	size_t tmp = pow_mod(pub_key, this->_private, this->_p);
	this->_pri_key = new char[9]; 
	sprintf(this->_pri_key, "%08zx", tmp); 
	return this->_pri_key;
}

void Crypto::crypto(char* data, size_t size, const char* key)//加解密函数
{
	size_t len = sizeof(key);
	for (size_t i = 0; i < size; ++i)
	{
		data[i] ^= key[i % len];
	}
}

size_t Crypto::create_big_integer()//使用两个size_t的组合获得32位的随机大整数
{
	return ((size_t)((size_t)rand() << 16) | (size_t)rand());
}

size_t Crypto::pow_mod(size_t n, unsigned int times, size_t mod)//模幂运算
{
	size_t tmp = 1;
	for (unsigned int i = 0; i < times; i++)
	{
		tmp = tmp * n % mod;
	}
	return tmp;
}

Crypto::~Crypto()//析构函数
{
	delete[] this->_public;
	delete[] this->_pri_key;
}

