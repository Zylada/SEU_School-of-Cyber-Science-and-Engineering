# DNS3 约束微簇合并运行报告

## 数据与输出

- 数据目录：`E:\大三下\入侵检测\大作业\完成dns3\data\dns3`
- 提交文件：`E:\大三下\入侵检测\大作业\完成dns3\outputs_constrained_merge\k12_h18_l42_g3.0\label.csv`
- 预测明细：`E:\大三下\入侵检测\大作业\完成dns3\outputs_constrained_merge\k12_h18_l42_g3.0\prediction_detail.csv`
- 簇数：`12`

## 聚类规模

- cluster `0`: `14229`
- cluster `1`: `1069`
- cluster `2`: `675`
- cluster `3`: `375`
- cluster `4`: `291`
- cluster `5`: `262`
- cluster `6`: `201`
- cluster `7`: `137`
- cluster `8`: `120`
- cluster `9`: `49`
- cluster `10`: `41`
- cluster `11`: `19`

## 指标与参数

- `fqdn_rows`: `17468`
- `feature_rows`: `17468`
- `quick_mode`: `False`
- `flint_rows_used`: `2203260`
- `ip_info_rows_used`: `1906654`
- `graph_edge_count`: `119148`
- `graph_resource_count`: `83963`
- `graph_component_count`: `11477`
- `dns2_detail_path`: `E:\大三下\入侵检测\大作业\完成dns2\outputs_ensemble_rank\tp1000\prediction_detail.csv`
- `dns2_prior_rows`: `17468`
- `dns2_known_label_rows`: `1988`
- `dns2_known_positive_rows`: `687`
- `dns2_known_negative_rows`: `1301`
- `dns2_pred_positive_rows`: `1000`
- `numeric_feature_count`: `165`
- `categorical_columns`: `tld, flint_top_country, flint_top_isp`
- `combined_sparse_shape`: `(17468, 4042)`
- `svd_components`: `72`
- `svd_explained_variance_ratio_sum`: `0.9580420763000468`
- `low_graph_total_resource_count`: `83963`
- `low_graph_kept_resource_count`: `6531`
- `low_graph_filtered_edge_count`: `23139`
- `low_graph_component_count`: `12597`
- `low_graph_largest_component_size`: `2156`
- `low_graph_min_degree`: `2`
- `low_graph_max_degree`: `30`
- `candidate_type`: `constrained_micro_merge`
- `candidate_target_clusters`: `12`
- `high_micro_clusters`: `18`
- `low_micro_clusters`: `42`
- `total_micro_clusters`: `60`
- `constraint_graph_weight`: `3.0`
- `graph_weighted_feature_count`: `130`
- `micro_layer_high_rows`: `1410`
- `micro_layer_middle_rows`: `1764`
- `micro_layer_low_rows`: `14294`
- `micro_layer_high_risk_count_arg`: `1000`
- `micro_layer_middle_risk_count_arg`: `2000`
- `dns2_known_alignment_enabled`: `True`
- `dns2_known_alignment_rows`: `1988`
- `dns2_known_alignment_nmi`: `0.6687474970569236`
- `dns2_known_alignment_ari`: `0.8112434936263172`
- `low_graph_resource_purity_enabled`: `True`
- `low_graph_resource_eval_count`: `6531`
- `low_graph_resource_pure_ratio`: `0.8765885775532077`
- `low_graph_resource_weighted_pure_ratio`: `0.8040537620467609`
- `proxy_score`: `0.6042028834932486`
- `balance_entropy`: `0.33769653601964267`
- `candidate_variant`: `k12_h18_l42_g3.0`
- `silhouette_sample`: `5000`
- `selected_cluster_count`: `12`
- `min_cluster_size`: `19`
- `max_cluster_size`: `14229`

## 说明

- 本题是无监督聚类，`data/dns3/label.csv` 只作为提交格式样例，不参与训练。
- 本版本引入 DNS2 `prediction_detail.csv` 的分数和已知黑白标签作为弱先验特征。
`outputs_ensemble_rank/tp1000/prediction_detail.csv` 是 **集成排序版的预测明细文件**，不是最终提交文件。

它对应的提交文件是：

`outputs_ensemble_rank/tp1000/label.csv`

这个 `prediction_detail.csv` 主要用于分析每个测试域名为什么被判黑/白，里面保存了每个域名的模型分数、图规则分数、排序和最终标签。

关键列含义：

- `fqdn_no`：域名编号
- `encoded_fqdn`：编码后的域名特征
- `lgbm_score`：LightGBM 预测黑的概率
- `extra_trees_score`：ExtraTrees 预测黑的概率
- `text_ngram_score`：字符 n-gram 线性模型预测黑的概率
- `graph_rule_score`：图规则参考分数
- `ensemble_rank_score`：三路模型 rank average 后的集成排序分数
- `ranking_score`：最终用于排序截断的分数，基本就是 `ensemble_rank_score`
- `known_label`：如果该域名在训练标签中出现，这里是已知标签
- `is_known_train_label`：是否是训练集中已知标签
- `label`：这一版最终给出的预测标签

这个文件有：

- 行数：`17468`
- 最终预测黑：`1000`
- 最终预测白：`16468`
- 已知训练标签行：`1988`
- 未知测试域名行：`15480`

简单说：  
`prediction_detail.csv` 是“打分过程明细”，方便你看每个域名的模型依据；真正提交平台的是同目录下的 `label.csv`。


- 本版本先做 DNS2 分层过聚类，再把低度 flint 资源、CNAME 和 DNS2 分数相似性转成微簇约束图。
- 微簇图使用谱聚类合并到目标簇数，目标是保留 DNS2 大结构，同时减少共享低度资源被拆散。
- 输出 `label.csv` 覆盖 `fqdn.csv` 中的全部域名，字段为 `fqdn_no,label`。
- `cluster_sweep.csv` 记录该候选的微簇数、目标簇数和图权重配置。