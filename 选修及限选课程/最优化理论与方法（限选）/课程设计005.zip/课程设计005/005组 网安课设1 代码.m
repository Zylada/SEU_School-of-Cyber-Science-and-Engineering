clear;
clc;

%%%%%%%%%%%%%% Parameter Setting %%%%%%%%%%%%%%%%%%%%%%
K = 8; % Number of users
K1 = 4; % Number of secure users
N = 64; % Number of subcarriers

NIte = 500; % Number of iterations

C = 0.3 * ones(K1, 1); % Secure requirement
load a.mat; % Use given test sample
b = zeros(K, N); % The largest CNR of other users
w = ones(K - K1, 1); % Weights for non-secure users

% Compute the largest CNR of other users (b)
for k = 1:K
    for n = 1:N
        tmp = a(:, n);
        tmp(k) = [];
        b(k, n) = max(tmp);
    end
end

% 扩大信噪比范围为0—80
SNR = 0:5:80;  
NSNR = length(SNR);
Rate = zeros(4, NSNR); % Store rates for different schemes
Rate_iteration = zeros(NIte, NSNR); % Store rates for each iteration

% FSA subcarrier allocation strategies
FSA1_SubCarrierAllocation = mod(0:N - 1, K) + 1;
FSA2_SubCarrierAllocation = [repmat(1:K1, 1, 12), repmat(K1 + 1:K, 1, 4)];
FSA3_SubCarrierAllocation = mod(0:N - 1, K - K1) + K1 + 1;

for nsnr = 1:NSNR
    P = 10 ^ (SNR(nsnr) / 10); % Total power constraint
    lambda0 = 1; % Lagrange multiplier for power constraint
    mu0 = ones(K1, 1) + SNR(nsnr) / 20; % Adjust secure constraints with SNR

    for ite = 1:NIte
        %%%%%%%%%%%%%%%%%% Power Allocation %%%%%%%%%%%%%%%%%%
        p_sa = zeros(K, N); % Power allocation matrix
        % Secure users
        for k = 1:K1
            for n = 1:N
                temp1 = (1 / a(k, n) - 1 / b(k, n));
                temp2 = (4 * mu0(k) / lambda0) * (1 / b(k, n) - 1 / a(k, n));
                temp_sqrt = temp1 ^ 2 + temp2;
                if temp_sqrt >= 0
                    p_sa(k, n) = max(0, 0.5 * (sqrt(temp_sqrt + 1e-10) - (1 / a(k, n) + 1 / b(k, n))));
                else
                    p_sa(k, n) = 0;
                end
            end
        end
        % Non-secure users
        for k = K1 + 1:K
            for n = 1:N
                temp_result = w(k - K1) / lambda0 - 1 / a(k, n);
                if temp_result >= 0
                    p_sa(k, n) = temp_result;
                else
                    p_sa(k, n) = 0;
                end
            end
        end
        % Normalize power to satisfy total power constraint
        total_power = sum(p_sa(:));
        if total_power > P
            p_sa = P * p_sa / total_power;
        end

        %%%%%%%%%%%%%%%%%% Subcarrier Assignment %%%%%%%%%%%%%%%%%%
        SubCarrierAllocation = zeros(N, 1);
        for n = 1:N
            H = zeros(K, 1);
            for k = 1:K1
                if p_sa(k, n) > 0
                    H(k) = mu0(k) * (log(1 + p_sa(k, n) * a(k, n)) - log(1 + p_sa(k, n) * b(k, n))) - lambda0 * p_sa(k, n);
                else
                    H(k) = -Inf;
                end
            end
            for k = K1 + 1:K
                if p_sa(k, n) > 0
                    H(k) = w(k - K1) * log(1 + p_sa(k, n) * a(k, n)) - lambda0 * p_sa(k, n);
                else
                    H(k) = -Inf;
                end
            end
            [~, SubCarrierAllocation(n)] = max(H);
        end

        %%%%%%%%%%%%%%%%%% Subgradient Update %%%%%%%%%%%%%%%%%%
        step_size = 1 / sqrt(ite + SNR(nsnr)); % Dynamic step size
        r_s = zeros(K1, 1); % Secure rates
        for k = 1:K1
            for n = 1:N
                if SubCarrierAllocation(n) == k
                    r_s(k) = r_s(k) + log(1 + p_sa(k, n) * a(k, n)) - log(1 + p_sa(k, n) * b(k, n));
                end
            end
        end
        Delta_mu = r_s - C;
        Delta_lambda = P - sum(sum(p_sa));
        mu0 = max(0, mu0 - step_size * Delta_mu);
        lambda0 = max(0, lambda0 - step_size * Delta_lambda);

        %%%%%%%%%%%%%%%%%% Rate Calculation %%%%%%%%%%%%%%%%%%
        NRate = 0;
        for n = 1:N
            k = SubCarrierAllocation(n);
            if k > 0
                NRate = NRate + log(1 + p_sa(k, n) * a(k, n));
            end
        end
        Rate_iteration(ite, nsnr) = NRate;
    end

    Rate(1, nsnr) = mean(Rate_iteration(:, nsnr));

    % FSA Rates
    for scheme = 2:4
        FSARate = 0;
        FSAAllocation = eval(['FSA' num2str(scheme - 1) '_SubCarrierAllocation']);
        for n = 1:N
            k = FSAAllocation(n);
            if k > 0
                FSARate = FSARate + log(1 + p_sa(k, n) * a(k, n));
            end
        end
        Rate(scheme, nsnr) = FSARate;
    end
end

% Plot results
figure;
plot(SNR, Rate(1, :), 'r-*', 'LineWidth', 2, 'MarkerSize', 8);
hold on;
plot(SNR, Rate(2, :), 'b-o', 'LineWidth', 2, 'MarkerSize', 8);
plot(SNR, Rate(3, :), 'g-s', 'LineWidth', 2, 'MarkerSize', 8);
plot(SNR, Rate(4, :), 'm-d', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('SNR (dB)');
ylabel('Normal Rate');
legend('OptimalScheme', 'FSA1', 'FSA2', 'FSA3');
grid on;
ylim([0, max(max(Rate)) * 1.2]);
yticks(0:20:ceil(max(max(Rate))));
