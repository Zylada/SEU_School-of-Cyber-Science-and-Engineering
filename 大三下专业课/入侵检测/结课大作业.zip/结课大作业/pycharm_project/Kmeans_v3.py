import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['SimHei']    # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False      # 正常显示负号


print("正在读取数据...")
fqdn_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\fqdn.csv")
access_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\access.csv")
flint_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\flint.csv")

access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique'),
    active_hours=('hour', 'nunique'),
    request_variance=('request_cnt', 'var')
).reset_index()

flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean'),
    ttl_std=('ttl', 'std'),
    unique_resolved_values=('encoded_value', 'nunique')
).reset_index()

features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features.fillna(0, inplace=True)

feature_cols = [
    'total_request_cnt', 'unique_ips', 'active_hours', 'request_variance',
    'flint_records', 'avg_ttl', 'ttl_std', 'unique_resolved_values'
]
X = features[feature_cols]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
features['cluster'] = kmeans.fit_predict(X_scaled)

print("各簇数量：")
print(features['cluster'].value_counts().sort_index())

print("\n每个簇的原始特征均值：")
for c in sorted(features['cluster'].unique()):
    subset = features[features['cluster'] == c]
    print(f"\n--- 簇 {c}，共 {subset.shape[0]} 个 ---")
    print(subset[feature_cols].mean())

submit = features[['fqdn_no', 'cluster']].rename(columns={'cluster': 'label'})
submit.to_csv('result_submit.csv', index=False)
print("\n结果已保存为 result_v3.csv")

pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X_scaled)

plt.figure(figsize=(12, 8))
scatter = plt.scatter(
    X_pca[:, 0], X_pca[:, 1],
    c=features['cluster'],
    cmap='tab10',
    alpha=0.6,
    s=5
)

plt.xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.2%} 方差解释)')
plt.ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.2%} 方差解释)')
plt.title('K-Means v3 聚类结果（PCA降维可视化，K=5）')

legend1 = plt.legend(
    *scatter.legend_elements(),
    title="簇编号",
    loc="upper right"
)
plt.gca().add_artist(legend1)

plt.savefig('cluster_pca.png', dpi=150, bbox_inches='tight')
plt.show()

print("图片已保存为 Kmeans_v3.png")