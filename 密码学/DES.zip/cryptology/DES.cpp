#include<iostream>
#include<cmath>
#include"Feistel.h"
using namespace std;

//加密函数
void encryption(int* p,int* c)
{
	permutation(p0, p1, IP, 64); //明文进行初始置换 
	for (i = 0; i < 32; i++)//明文第0轮的左半部分 
		plaintext_l[0][i] = p1[i];
	for (i = 32; i < 64; i++)//明文的右半部分 
		plaintext_r[0][i - 32] = p1[i];
	permutation(k0, k1, pc1, 56);//密钥进行PC-1置换  
	int run = 1;
	for (int i = 0; i < 28; i++) {
		key_l[0][i] = k1[i];
		key_r[0][i] = k1[i + 28];
	}
	for (r = 1; r <= 16; r++) 
	{
		circulationShift(key_l[run], key_l[run - 1]);
		circulationShift(key_r[run], key_r[run - 1]);
		run++;
	}
	//结合 
	for (r = 1; r <= 16; r++) {
		for (i = 0; i < 28; i++) {
			key_2[r][i] = key_l[r][i];
			key_2[r][i + 28] = key_r[r][i];
		}
	}
	//pc-2置换
	for (r = 1; r <= 16; r++) {
		permutation(key_2[r], key_3[r], pc2, 48);
	}
	//真正的16轮密钥到此生成 
	int temp6[48], temp1[32];
	for (int r = 1; r <= 16; r++) 
	{
		assignment(plaintext_l[r], plaintext_r[r - 1], 32);//左半部分等于上一轮右半部分 
		permutation(plaintext_r[r - 1], temp6, E, 48);//E置换
		XOR(temp6, key_3[r], 48);//准备S盒置换 
		Sbox(temp1, temp6);//s盒替换
		permutation(temp1, temp6, p, 32);//P置换 
		XOR(temp6, plaintext_l[r - 1], 32);
		assignment(plaintext_r[r], temp6, 32);
		cout << "the ciphertext on the " << 17 - r << ' ' << "round is " << endl;
		for (i = 0; i < 32; i++) {
			cout << plaintext_l[r][i];
		}
		for (i = 0; i < 32; i++) {
			cout << plaintext_r[r][i];
		}
		cout << endl;
	}
	for (i = 0; i < 32; i++) {
		ciphertext1[i] = plaintext_r[16][i];
		ciphertext1[i + 32] = plaintext_l[16][i];
	}
	permutation(ciphertext1, ciphertext2, IP_1, 64);
	BiToDE(ciphertext2, ciphertext3, 64);
	cout << "The plaintext is translated as:" << endl;
	for (i = 0; i < 8; i++) 
	{
		cout << ciphertext3[i] << endl;
	}
	cout << endl;
}
//解密函数
void decryption(int* c,int* p)
{
	permutation(ciphertext2, ciphertext1, IP, 64);//IP_1置换 
	for (i = 0; i < 32; i++) 
	{
		plaintext_l[16][i] = ciphertext1[i + 32];
		plaintext_r[16][i] = ciphertext1[i];
	}
	for (int r = 16; r >= 1; r--) 
	{
		assignment(plaintext_r[r - 1], plaintext_l[r], 32);//这一轮的左等于上一轮的右 	
		permutation(plaintext_r[r - 1], ciphertext1, E, 48);//E扩展 
		XOR(ciphertext1, key_3[r], 48);//与密钥异或
		Sbox(ciphertext2, ciphertext1);//S盒置换
		permutation(ciphertext2, ciphertext1, p, 32);//p盒置换
		assignment(plaintext_l[r - 1], ciphertext1, 32);
		XOR(plaintext_l[r - 1], plaintext_r[r], 32);//异或 
		cout << "the plaintext on the " << 17 - r <<' ' << "round is " << endl;
		for (i = 0; i < 32; i++) {
			cout << plaintext_l[r - 1][i];
		}
		for (i = 0; i < 32; i++) 
		{
			cout << plaintext_r[r - 1][i];
		}
		cout << endl;
	}
	for (i = 0; i < 32; i++) 
	{
		ciphertext1[i + 32] = plaintext_r[0][i];
		ciphertext1[i] = plaintext_l[0][i];
	}
	permutation(ciphertext1, ciphertext2, IP_1, 64);
	cout << "The ciphertext is translated as" << endl;
	BiToDE(ciphertext2, min_ciphertext, 64);
	for (i = 0; i < 8; i++) 
	{
		cout << min_ciphertext[i] << endl;
	}
	cout << endl;
}

int main()
{
	cout << "Please enter the 8-bit plaintext:";//将明文转化为2进制
	for (int i = 0; i < 8; i++)
	{
		cin >> plaintext0[i];
		DeToBi(p0, (int)plaintext0[i], i, 64);
	}
	cout << "Please enter the 8-bit key:";
	for (int i = 0; i < 8; i++)//将密钥转化为2进制
	{
		cin >> key0[i];
		DeToBi(k0, (int)key0[i], i, 64);
	}
	cout << "Start encryption"<<endl;
	encryption(p0, k0);
	cout << "Start decryption" << endl;
	decryption(p0, k0);
	return 0;
}