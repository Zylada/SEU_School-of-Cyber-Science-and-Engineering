import pandas as pd
import numpy as np

fqdn = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\fqdn.csv")
print("===== fqdn.csv =====")
print(f"形状: {fqdn.shape}")
print(fqdn.head())

access = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\access.csv", nrows=100)
print("\n===== access.csv (前100行) =====")
print(f"形状(前100): {access.shape}")
print(access.head())
print(f"\n列名: {list(access.columns)}")

flint = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\flint.csv", nrows=100)
print("\n===== flint.csv (前100行) =====")
print(f"形状(前100): {flint.shape}")
print(flint.head())
print(f"\n列名: {list(flint.columns)}")

ip = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\ip.csv", nrows=100)
print("\n===== ip.csv (前100行) =====")
print(f"形状(前100): {ip.shape}")
print(ip.head())
print(f"\n列名: {list(ip.columns)}")

ipv6 = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\ipv6.csv", nrows=100)
print("\n===== ipv6.csv (前100行) =====")
print(f"形状(前100): {ipv6.shape}")
print(ipv6.head())
print(f"\n列名: {list(ipv6.columns)}")

label = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\label.csv")
print("\n===== label.csv =====")
print(f"形状: {label.shape}")
print(label.head())

access_sample = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\access.csv", nrows=10000)
flint_sample = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\flint.csv", nrows=10000)

print("===== access 每个域名的记录数分布（样本前10000行）=====")
access_per_fqdn = access_sample['fqdn_no'].value_counts()
print(access_per_fqdn.describe())
print(f"\n有记录的唯一域名数: {access_per_fqdn.shape[0]}")

print("\n===== flint 每个域名的记录数分布（样本前10000行）=====")
flint_per_fqdn = flint_sample['fqdn_no'].value_counts()
print(flint_per_fqdn.describe())
print(f"\n有记录的唯一域名数: {flint_per_fqdn.shape[0]}")