#include <iostream>
#include<iomanip>
#include <string.h>
#include "crypto.h"
using namespace std;

void print(char* data, int size)//自定义print输出函数，防止输出结果为数据的ASCII码
{
	for (int i = 0; i < size; ++i)
	{
		cout << dec<< setw(2) << setfill('0') << (int)data[i] << " ";
	}
	cout << endl;
}

int main(int argc, char** argv)
{
	Crypto::init(); //种子初始化

	//模拟会话
	Crypto A;
	size_t* g_p = A.get_public(); //生成 (g, p) 
	size_t X = A.get_pub_key();   //A计算公钥X
	cout << "The private key of A is :" << X << endl;
	Crypto B(g_p[0], g_p[1]);     //获得(g, p)  
	size_t Y = B.get_pub_key();   //B计算公钥Y 
	cout << "The private key of B is :" << Y << endl;
	char* KB = B.get_key(X);      //B计算私钥KB 
	char* KA = A.get_key(Y);      //A通过B发的Y计算私钥KA
	cout << "The public key is :" << KA << endl << "The public key is :" << KB << endl << endl;
	if (strcmp(KA, KB))
	{
		cout << "ERROR when generate the keys!" << endl;
		return 0;
	}
   
	char data[21];     //明文   
	char encrypted_data[21]; //用于存储加密后的数据  
	char decrypted_data[21]; //用于存储解密后的数据  

	cout << "please enter your plaintext:" << endl;
	cin >> data;

	//复制原始数据到加密数组  
	for (int i = 0; i < 20 && data[i] != '\0'; ++i) 
	{
		encrypted_data[i] = data[i];
	}
	encrypted_data[20] = '\0';// 确保字符串以null结尾

	cout << "A does the encryption: " << endl;
	A.crypto(encrypted_data, 20, KA);       //使用密钥加密   
	print(encrypted_data, 20);
	cout << "==========" << endl;

	//将加密数据复制到解密数组  
	for (int i = 0; i < 20 && encrypted_data[i] != '\0'; ++i) 
	{
		decrypted_data[i] = encrypted_data[i];
	}
	decrypted_data[20] = '\0';//确保字符串以null结尾

	cout << "B does the decryption: " << endl;
	B.crypto(decrypted_data, 20, KB);       //使用密钥解密   
	//直接打印解密后的数据，而不是调用print函数  
	cout << decrypted_data << endl;
	cout << "==========" << endl;
	return 0;
}
