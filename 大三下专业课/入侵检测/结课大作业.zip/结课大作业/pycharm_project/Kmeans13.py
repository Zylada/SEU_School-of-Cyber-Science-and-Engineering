# ===== KMeans_13features.py：13 特征 + KMeans (K=5) =====
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn import metrics

# ==================== 路径 ====================
base = r'C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question'
# =============================================

print("正在读取数据...")
fqdn_all = pd.read_csv(f"{base}/fqdn.csv")
access_all = pd.read_csv(f"{base}/access.csv")
flint_all = pd.read_csv(f"{base}/flint.csv")
ip_all = pd.read_csv(f"{base}/ip.csv")

# ---------- 聚合 access 特征 ----------
print("正在聚合 access 特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique'),
    active_hours=('hour', 'nunique'),
    request_variance=('request_cnt', 'var')
).reset_index()

# ---------- 聚合 flint 特征 ----------
print("正在聚合 flint 特征...")
flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean'),
    ttl_std=('ttl', 'std'),
    unique_resolved_values=('encoded_value', 'nunique')
).reset_index()

# ---------- 聚合 IP 特征 ----------
print("正在聚合 IP 特征...")
ip_info = ip_all[['encoded_ip', 'country', 'city', 'isp']]
access_with_ip = access_all.merge(ip_info, on='encoded_ip', how='left')

ip_feat = access_with_ip.groupby('fqdn_no').agg(
    num_countries=('country', 'nunique'),
    overseas_ratio=('country', lambda x: (x != '中国').mean()),
    num_cities=('city', 'nunique'),
    num_isps=('isp', 'nunique'),
    cloud_ratio=('isp', lambda x: x.str.lower().str.contains(
        'amazon|google|cloud|azure|tencent|aliyun', na=False).mean())
).reset_index()

# 填充缺失值
ip_feat.fillna({'num_countries': 0, 'overseas_ratio': 0,
                'num_cities': 0, 'num_isps': 0, 'cloud_ratio': 0}, inplace=True)

# ---------- 拼接所有特征 ----------
features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features = features.merge(ip_feat, on='fqdn_no', how='left')
features.fillna(0, inplace=True)

print(f"特征矩阵形状: {features.shape}")

# ---------- 特征列 ----------
feature_cols = [
    'total_request_cnt', 'unique_ips', 'active_hours', 'request_variance',
    'flint_records', 'avg_ttl', 'ttl_std', 'unique_resolved_values',
    'num_countries', 'overseas_ratio', 'num_cities', 'num_isps', 'cloud_ratio'
]

# ---------- 标准化 ----------
X = features[feature_cols].values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ---------- KMeans, K=5 ----------
print("正在进行 KMeans 聚类 (K=5)...")
kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
features['label'] = kmeans.fit_predict(X_scaled)

# 轮廓系数
sil = metrics.silhouette_score(X_scaled, features['label'])
print(f"轮廓系数: {sil:.4f}")

print("\n各簇数量：")
print(features['label'].value_counts().sort_index())

# ---------- 保存提交文件 ----------
submit = features[['fqdn_no', 'label']]
submit['label'] = submit['label'].astype(int)
submit.to_csv('result_kmeans_13.csv', index=False)
print("\n结果已保存为 result_kmeans_13.csv")