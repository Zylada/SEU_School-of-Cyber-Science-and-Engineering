# ===== 方案A：先分离沉寂域名，再对活跃域名聚类 =====
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

print("正在读取数据...")
fqdn_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\fqdn.csv")
access_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\access.csv")
flint_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\flint.csv")

print("正在聚合特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique')
).reset_index()

flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean')
).reset_index()

features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features.fillna(0, inplace=True)

# 分离沉寂域名和活跃域名 沉寂域名：完全没有请求记录，也没有解析记录
silent_mask = (features['total_request_cnt'] == 0) & (features['flint_records'] == 0)
silent_domains = features[silent_mask].copy()
active_domains = features[~silent_mask].copy()   # ~ 表示"非"

print(f"沉寂域名数量: {silent_domains.shape[0]}")
print(f"活跃域名数量: {active_domains.shape[0]}")

# 题目要求总簇数 ≥ 3，把活跃域名分成 2 簇，加沉寂的那 1 簇，总共 3 簇
X_active = active_domains[['total_request_cnt', 'unique_ips', 'flint_records', 'avg_ttl']]
scaler = StandardScaler()
X_active_scaled = scaler.fit_transform(X_active)

kmeans = KMeans(n_clusters=2, random_state=42)
active_domains['cluster'] = kmeans.fit_predict(X_active_scaled)

silent_domains['cluster'] = 2

result = pd.concat([active_domains, silent_domains], ignore_index=True)
result = result[['fqdn_no', 'cluster']].sort_values('fqdn_no')

print("\n各簇数量：")
print(result['cluster'].value_counts().sort_index())

print("\n活跃域名的簇内样例（前3个）：")
for c in [0, 1]:
    subset = active_domains[active_domains['cluster'] == c][['fqdn_no', 'total_request_cnt', 'unique_ips', 'avg_ttl']]
    print(f"\n--- 活跃簇 {c}，共 {subset.shape[0]} 个 ---")
    print(subset.head(3))

print(f"\n沉寂簇样例（前3个）：")
print(silent_domains[['fqdn_no', 'total_request_cnt', 'flint_records']].head(3))

submit = result.rename(columns={'cluster': 'label'})
submit.to_csv('result_A.csv', index=False)
print("\n结果已保存为 result_A.csv")