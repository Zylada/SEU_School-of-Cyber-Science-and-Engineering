import sys
import math
from collections import Counter
from sklearn.ensemble import RandomForestClassifier


def read_data(filename, has_label=True):
    domains = []
    labels = []
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if has_label:
                parts = line.split(',')
                if len(parts) == 2:
                    domain = parts[0].strip()
                    label = parts[1].strip()
                    domains.append(domain)
                    labels.append(label)
            else:
                domains.append(line)
    if has_label:
        return domains, labels
    else:
        return domains


def entropy(s):
    if not s:
        return 0.0
    freq = Counter(s)
    length = len(s)
    ent = 0.0
    for count in freq.values():
        p = count / length
        ent -= p * math.log2(p)
    return ent


def extract_features(domain):
    # 提取主域名部分：如果域名无点，则取整体
    if '.' in domain:
        main_part = domain.split('.')[0].lower()
    else:
        main_part = domain.lower()

    # 整体域名（保留一部分特征，如连续数字最长段可基于整体）
    full = domain.lower()

    # 特征1：主域名长度
    length = len(main_part)
    if length == 0:
        return [0, 0, 0, 0, 0, 0, 0]

    # 特征2：数字比例（主域名中）
    digit_count = sum(1 for ch in main_part if ch.isdigit())
    digit_ratio = digit_count / length

    # 特征3：熵（主域名）
    ent = entropy(main_part)

    # 新增  特征4：元音比例（a,e,i,o,u）
    vowels = set('aeiou')
    vowel_count = sum(1 for ch in main_part if ch in vowels)
    vowel_ratio = vowel_count / length

    # 新增  特征5：辅音比例（字母且非元音）
    consonant_count = sum(1 for ch in main_part if ch.isalpha() and ch not in vowels)
    consonant_ratio = consonant_count / length

    # 新增  特征6：连续数字的最大长度（基于完整域名，因为子域名也可能有数字）
    max_digit_seq = 0
    cur = 0
    for ch in full:
        if ch.isdigit():
            cur += 1
            max_digit_seq = max(max_digit_seq, cur)
        else:
            cur = 0

    # 新增  特征7：域名中唯一字母数（主域名中）归一化
    unique_letters = len(set(ch for ch in main_part if ch.isalpha()))
    letter_diversity = unique_letters / max(1, length)

    return [length, digit_ratio, ent, vowel_ratio, consonant_ratio, max_digit_seq, letter_diversity]


def main():
    train_domains, train_labels = read_data("train.txt", has_label=True)
    test_domains = read_data("test.txt", has_label=False)

    X_train = [extract_features(d) for d in train_domains]
    X_test = [extract_features(d) for d in test_domains]

    # 使用随机森林，增加树的数量，限制最大深度防止过拟合
    clf = RandomForestClassifier(n_estimators=200, max_depth=10, random_state=42)
    clf.fit(X_train, train_labels)

    predictions = clf.predict(X_test)

    with open("result.txt", "w", encoding="utf-8") as f:
        for domain, label in zip(test_domains, predictions):
            f.write(f"{domain},{label}\n")

    print("预测完成，结果已写入 result.txt")


if __name__ == "__main__":
    main()