import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler


print("正在读取 access.csv 全量...")
access_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\access.csv")
print("正在读取 flint.csv 全量...")
flint_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\flint.csv")

print("正在聚合 access 特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),      # 总请求量
    unique_ips=('encoded_ip', 'nunique')           # 不同IP数
).reset_index()

print("正在聚合 flint 特征...")
flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),            # 解析记录数
    avg_ttl=('ttl', 'mean')                        # 平均TTL（忽略NaN）
).reset_index()

fqdn_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\fqdn.csv")

features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features.fillna(0, inplace=True)

print("特征矩阵形状:", features.shape)
print(features.head())

# 标准化后，系统测试多个 K 值
from sklearn.metrics import silhouette_score

X = features[['total_request_cnt', 'unique_ips', 'flint_records', 'avg_ttl']]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

K_range = range(2, 11)
sil_scores = []

print("===== KMeans 原始版：测试多个 K 值 =====")
for k in K_range:
    kmeans_tmp = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels_tmp = kmeans_tmp.fit_predict(X_scaled)
    sil = silhouette_score(X_scaled, labels_tmp)
    sil_scores.append(sil)
    print(f"K={k}, 轮廓系数={sil:.4f}")

best_k = K_range[sil_scores.index(max(sil_scores))]
print(f"\n最优 K = {best_k}，轮廓系数 = {max(sil_scores):.4f}")

# 用最优 K 做最终聚类
kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=10)
features['cluster'] = kmeans.fit_predict(X_scaled)

print("聚类完成！各个簇的数量：")
print(features['cluster'].value_counts())

print("\n每个簇前5个域名：")
for c in sorted(features['cluster'].unique()):
    print(f"\n--- 簇 {c} ---")
    print(features[features['cluster'] == c][['fqdn_no', 'total_request_cnt', 'unique_ips', 'avg_ttl']].head())

# 格式要求：fqdn_no, label
submit = features[['fqdn_no', 'cluster']].copy()
submit.rename(columns={'cluster': 'label'}, inplace=True)
submit.to_csv('first_cluster_result.csv', index=False)
