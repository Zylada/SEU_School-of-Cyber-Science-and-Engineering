# ============================================================
# 修正版 analyze_vs_highscore.py
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import normalized_mutual_info_score
from sklearn.feature_selection import f_classif

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# ==================== 1. 读取数据 ====================
print("正在读取数据...")
high_labels = pd.read_csv('label-3.csv')
features = pd.read_csv('features_raw_DBSCAN.csv')
kmeans_res = pd.read_csv('result_kmeans2.csv')
dbscan_res = pd.read_csv('result_dbscan2.csv')

print(f"高分作业样本数: {len(high_labels)}")
print("高分作业标签分布：")
print(high_labels['label'].value_counts().sort_index())
print(f"特征矩阵形状: {features.shape}")

# 合并特征与高分标签
data = features.merge(high_labels, on='fqdn_no', how='inner')
print(f"合并后用于分析的样本数: {len(data)}")

# 特征列表（根据你的实际情况）
feature_cols = [
    'total_request_cnt', 'unique_ips', 'active_hours', 'request_variance',
    'flint_records', 'avg_ttl', 'ttl_std', 'unique_resolved_values',
    'num_countries', 'overseas_ratio', 'num_cities', 'num_isps', 'cloud_ratio'
]
feature_cols = [col for col in feature_cols if col in data.columns]
print(f"用于分析的特征: {feature_cols}")

# ==================== 2. 特征区分度分析 ====================

# 2.1 分组统计（使用 xs 获取 mean 层）
group_stats = data.groupby('label')[feature_cols].agg(['mean', 'std', 'median'])
print("\n=== 各特征在不同高分标签下的均值 ===")
print(group_stats.xs('mean', axis=1, level=1).round(4))

# 2.2 箱线图
n_features = len(feature_cols)
n_cols = 3
n_rows = (n_features + n_cols - 1) // n_cols
fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 5*n_rows))
axes = axes.flatten()

for i, col in enumerate(feature_cols):
    sns.boxplot(data=data, x='label', y=col, ax=axes[i])
    axes[i].set_title(f'{col} 分布 (按高分标签)')
    axes[i].set_xlabel('label')
for j in range(i+1, len(axes)):
    axes[j].set_visible(False)
plt.tight_layout()
plt.savefig('feature_boxplot_by_high_label.png', dpi=150)
plt.show()

# 2.3 特征相关性热图
plt.figure(figsize=(12, 10))
corr = data[feature_cols].corr()
sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm', square=True)
plt.title('特征相关性矩阵')
plt.tight_layout()
plt.savefig('feature_correlation_heatmap.png', dpi=150)
plt.show()

# ==================== 3. 计算与高分作业的 NMI ====================
kmeans_labels = data.merge(kmeans_res, on='fqdn_no', how='left')['label_y']
dbscan_labels = data.merge(dbscan_res, on='fqdn_no', how='left')['label_y']

nmi_kmeans = normalized_mutual_info_score(data['label'], kmeans_labels)
nmi_dbscan = normalized_mutual_info_score(data['label'], dbscan_labels)

print("\n===== 与高分作业标签的 NMI =====")
print(f"KMeans 聚类结果 NMI: {nmi_kmeans:.4f}")
print(f"DBSCAN 聚类结果 NMI: {nmi_dbscan:.4f}")

# ==================== 4. 特征区分度 F 值排序 ====================
X = data[feature_cols]
y = data['label']
f_scores, p_values = f_classif(X, y)
feature_importance = pd.DataFrame({'feature': feature_cols, 'f_score': f_scores})
feature_importance = feature_importance.sort_values('f_score', ascending=False)
print("\n=== 特征区分度排序（F值越高越好） ===")
print(feature_importance.round(4))

# ==================== 5. 简单建议 ====================
print("\n===== 特征筛选建议 =====")
print("1. 观察箱线图：如果某个特征在不同 label 上的箱线图几乎完全重叠，则该特征区分度低，可删除。")
print("2. 检查相关性热图：若两个特征相关系数 > 0.85，可只保留其中一个。")
print("3. F值较低的特征（如 < 10）可以考虑去除。")
print("4. 根据经验，以下特征通常区分度较好：total_request_cnt, flint_records, avg_ttl, num_countries, overseas_ratio, cloud_ratio。")