使用的工具
Python 3 + opencv-python 库
LSBSteg.py 脚本

隐藏过程
1. 准备原始图片 input.bmp;
2. 准备文本文件 secret.txt，内容为：57123242,王子卓;
3. 运行命令：  
   'python LSBSteg.py encode -i input.bmp -o output.bmp -f secret.txt';
4. 脚本将secret.txt的二进制数据依次写入图片像素的最低有效位，生成output.bmp。

提取过程
1. 对隐写图片output.bmp运行解码命令：  
   python LSBSteg.py decode -i output.bmp -o extracted.txt
2. 脚本从像素最低位读取数据，还原为extracted.txt。
3. 打开extracted.txt，内容与原始secret.txt完全一致，验证成功。

特点
1. 人眼无法区分原始图片和隐写图片。
2. 使用 LSB 技术，数据隐藏在最低位，抗简单检测。