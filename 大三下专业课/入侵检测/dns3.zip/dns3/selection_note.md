# DNS3 final recommended candidate

Recommended primary submission: constrained micro-merge `k12_h18_l42_g3.0`.

Reason:
- Highest local proxy score among all generated candidates.
- DNS2 known-label NMI: 0.6687474970569236.
- DNS2 known-label ARI: 0.8112434936263172.
- Low-degree flint weighted resource purity: 0.8040537620467609.
- Cluster count: 12.

Caveat:
- Largest cluster size is 14229. If platform feedback suggests over-merged normal domains, try `outputs_constrained_merge_refined/k12_h18_l42_g3.0_refine4500` next.
