#ifndef CRYPTO_H
#define CRYPTO_H
#include <stdlib.h>

class Crypto
{
public:
	Crypto();//无参构造函数
	Crypto(size_t g, size_t p);//包含公共参数g,p的构造函数
	static void init();//种子初始化
	size_t* get_public();//获得并输出公共参数
	size_t get_pub_key();//获得并输出公钥
	char* get_key(size_t pub_key);//获得8位的私钥
	void crypto(char* data, size_t size, const char* key);//加解密函数
	virtual ~Crypto();//析构函数

protected:
	size_t create_big_integer();//使用两个size_t的组合获得32位的随机大整数
	size_t pow_mod(size_t n, unsigned int times, size_t mod);//模幂运算

private:
	size_t _g, _p;
	size_t* _public;
	size_t _private;
	size_t _pub_key;
	char* _pri_key;
};
#endif
