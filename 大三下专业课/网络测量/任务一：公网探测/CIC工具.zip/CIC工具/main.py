import os
import sys

from FlowGenerator import FlowGenerator
from PacketReader import PacketReader


FLOW_TIMEOUT = 120000000
ACTIVITY_TIMEOUT = 5000000
SUBFLOW_TIMEOUT = 1000000
BULK_TIMEOUT = 1000000
RESULT_DIR = os.path.join(os.path.dirname(__file__), "result")


def extract_features(file_path):
    print(f"Reading PCAP: {file_path}")
    try:
        packetReader = PacketReader(file_path)
        flowGenerator = FlowGenerator(
            FLOW_TIMEOUT,
            ACTIVITY_TIMEOUT,
            SUBFLOW_TIMEOUT,
            BULK_TIMEOUT,
            file_path,
            RESULT_DIR,
        )

        supported_packets = 0
        basicPacket = packetReader.nextPacket()
        while basicPacket is not None:
            supported_packets += 1
            flowGenerator.addPacket(basicPacket)

            if supported_packets % 1000 == 0:
                print(f"Processed supported packets: {supported_packets}")

            basicPacket = packetReader.nextPacket()

        print(f"Supported TCP/UDP packets: {supported_packets}")

        flowGenerator.clearFlow()
        print(f"Generated flows: {len(flowGenerator.finishedFlows)}")

        if flowGenerator.finishedFlows:
            flowGenerator.dumpFeatureToCSV()
            print("Feature extraction finished.")
        else:
            print("No flow features were generated.")

        return True
    except Exception as exc:
        print(f"Failed to extract features from {file_path}: {exc}")
        return False


def get_pcap_files(folder_path):
    pcap_files = []
    for entry in os.scandir(folder_path):
        if entry.is_file() and entry.name.lower().endswith(".pcap"):
            pcap_files.append(entry.path)
    return sorted(pcap_files, key=str.lower)


def process_input_path(input_path):
    input_path = os.path.abspath(input_path)

    if os.path.isdir(input_path):
        pcap_files = get_pcap_files(input_path)
        if not pcap_files:
            print(f"No PCAP files found in folder: {input_path}")
            return

        print(f"Found {len(pcap_files)} PCAP file(s) in folder: {input_path}")
        success_count = 0

        for index, file_path in enumerate(pcap_files, start=1):
            print(f"\n[{index}/{len(pcap_files)}] Processing {os.path.basename(file_path)}")
            if extract_features(file_path):
                success_count += 1

        print(
            f"\nBatch extraction finished. Success: {success_count}, "
            f"Failed: {len(pcap_files) - success_count}"
        )
        return

    if os.path.isfile(input_path):
        extract_features(input_path)
        return

    print(f"Input path does not exist: {input_path}")


if __name__ == "__main__":
    default_path = os.path.join(os.path.dirname(__file__), "data")
    input_path = sys.argv[1] if len(sys.argv) > 1 else default_path
    process_input_path(input_path)
