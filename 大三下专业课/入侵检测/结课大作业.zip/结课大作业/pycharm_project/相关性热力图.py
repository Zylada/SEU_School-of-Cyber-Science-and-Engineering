import seaborn as sns
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 计算特征之间的相关性
corr_matrix = features[feature_cols].corr()

# 画热力图
plt.figure(figsize=(14, 10))
sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='coolwarm',
            square=True, linewidths=0.5)
plt.title('13个特征之间的相关系数矩阵')
plt.tight_layout()
plt.savefig('feature_correlation.png', dpi=150)
plt.show()

# 打印高度相关的特征对（相关系数 > 0.85）
print("\n高度相关的特征对（|r| > 0.85）：")
high_corr_pairs = []
for i in range(len(feature_cols)):
    for j in range(i+1, len(feature_cols)):
        if abs(corr_matrix.iloc[i, j]) > 0.85:
            high_corr_pairs.append((feature_cols[i], feature_cols[j], corr_matrix.iloc[i, j]))
            print(f"  {feature_cols[i]} <-> {feature_cols[j]}: {corr_matrix.iloc[i, j]:.3f}")