import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from sklearn.metrics import classification_report

# ==================== 路径 ====================
base = r'C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question'
# =============================================

# ---------- 1. 读取数据 ----------
print("正在读取数据...")
fqdn_all = pd.read_csv(f"{base}/fqdn.csv")
access_all = pd.read_csv(f"{base}/access.csv")
flint_all = pd.read_csv(f"{base}/flint.csv")
ip_all = pd.read_csv(f"{base}/ip.csv")
label1 = pd.read_csv(r"C:\Users\19966\Desktop\label-1.csv")  # 任务一的标签文件

# ---------- 2. 特征工程（同之前）----------
print("正在聚合 access 特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique'),
    active_hours=('hour', 'nunique'),
    request_variance=('request_cnt', 'var')
).reset_index()

print("正在聚合 flint 特征...")
flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean'),
    ttl_std=('ttl', 'std'),
    unique_resolved_values=('encoded_value', 'nunique')
).reset_index()

print("正在聚合 IP 特征...")
ip_info = ip_all[['encoded_ip', 'country', 'city', 'isp']]
access_with_ip = access_all.merge(ip_info, on='encoded_ip', how='left')
ip_feat = access_with_ip.groupby('fqdn_no').agg(
    num_countries=('country', 'nunique'),
    overseas_ratio=('country', lambda x: (x != '中国').mean()),
    num_cities=('city', 'nunique'),
    num_isps=('isp', 'nunique'),
    cloud_ratio=('isp', lambda x: x.str.lower().str.contains(
        'amazon|google|cloud|azure|tencent|aliyun', na=False).mean())
).reset_index()
ip_feat.fillna({'num_countries': 0, 'overseas_ratio': 0,
                'num_cities': 0, 'num_isps': 0, 'cloud_ratio': 0}, inplace=True)

# ---------- 3. 拼接特征 ----------
features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features = features.merge(ip_feat, on='fqdn_no', how='left')
features.fillna(0, inplace=True)

print(f"特征矩阵形状: {features.shape}")

# ---------- 4. 准备训练集 ----------
# 从 label1 中筛选出在 features 表中存在的域名
train_data = label1.merge(features, on='fqdn_no', how='inner')
print(f"训练集大小: {train_data.shape[0]}")

# 映射 9 类到 4 类（保留第5类给未标注的正常域名）
def map_family(f):
    if f == 0: return 0
    elif f == 6: return 1
    elif f in [2,3,4,5]: return 2
    elif f in [1,7,8]: return 3
    else: return 4  # 备用，理论上不会执行

train_data['label'] = train_data['family_no'].apply(map_family)

# ---------- 5. 训练 XGBoost 分类器 ----------
feature_cols = [
    'total_request_cnt', 'unique_ips', 'active_hours', 'request_variance',
    'flint_records', 'avg_ttl', 'ttl_std', 'unique_resolved_values',
    'num_countries', 'overseas_ratio', 'num_cities', 'num_isps', 'cloud_ratio'
]

X = train_data[feature_cols].values
y = train_data['label'].values

# 划分训练集和验证集（用于内部评估，不提交）
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)

model = XGBClassifier(n_estimators=200, max_depth=6, learning_rate=0.1, random_state=42)
model.fit(X_train_scaled, y_train)

# 内部验证
y_pred = model.predict(X_val_scaled)
print("\n验证集分类报告:")
print(classification_report(y_val, y_pred, zero_division=0))

# ---------- 6. 预测所有域名 ----------
X_all = features[feature_cols].values
X_all_scaled = scaler.transform(X_all)

# 预测恶意家族
features['pred_label'] = model.predict(X_all_scaled)

# 预测概率，用于筛选“高置信度”的正常域名
proba = model.predict_proba(X_all_scaled)
max_proba = np.max(proba, axis=1)

# 策略：如果模型对所有4类的最大概率都低于阈值（0.6），归为“white”
threshold = 0.6
features.loc[max_proba < threshold, 'pred_label'] = 4

print("\n最终各类数量：")
print(features['pred_label'].value_counts().sort_index())

# ---------- 7. 保存提交文件 ----------
submit = features[['fqdn_no', 'pred_label']].rename(columns={'pred_label': 'label'})
submit['label'] = submit['label'].astype(int)
submit.to_csv('result_xgboost.csv', index=False)
print("\n结果已保存为 result_xgboost.csv")