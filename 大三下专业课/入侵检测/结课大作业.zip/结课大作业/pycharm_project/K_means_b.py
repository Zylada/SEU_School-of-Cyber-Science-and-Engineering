# ===== KMeans_b：对数变换 + 8特征 =====
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

print("正在读取数据...")
fqdn_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\fqdn.csv")
access_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\access.csv")
flint_all = pd.read_csv(r"C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question\flint.csv")

print("正在聚合 access 特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique'),
    active_hours=('hour', 'nunique'),
    request_variance=('request_cnt', 'var')
).reset_index()

print("正在聚合 flint 特征...")
flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean'),
    ttl_std=('ttl', 'std'),
    unique_resolved_values=('encoded_value', 'nunique')
).reset_index()

features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features.fillna(0, inplace=True)

print(f"特征矩阵形状: {features.shape}")

#对数变换
feature_cols = [
    'total_request_cnt', 'unique_ips', 'active_hours', 'request_variance',
    'flint_records', 'avg_ttl', 'ttl_std', 'unique_resolved_values'
]

for col in feature_cols:
    features[col + '_log'] = np.log1p(features[col])

log_cols = [col + '_log' for col in feature_cols]


X = features[log_cols]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

K_range = range(2, 11)
sil_scores = []

print("\n===== KMeans_b（对数变换）：测试多个 K 值 =====")
for k in K_range:
    kmeans_tmp = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels_tmp = kmeans_tmp.fit_predict(X_scaled)
    sil = silhouette_score(X_scaled, labels_tmp)
    sil_scores.append(sil)
    print(f"K={k}, 轮廓系数={sil:.4f}")

best_k = K_range[sil_scores.index(max(sil_scores))]
print(f"\n最优 K = {best_k}，轮廓系数 = {max(sil_scores):.4f}")

kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=10)
features['cluster'] = kmeans.fit_predict(X_scaled)

print("\n各簇数量：")
print(features['cluster'].value_counts().sort_index())

print("\n每个簇的原始特征均值：")
for c in sorted(features['cluster'].unique()):
    subset = features[features['cluster'] == c]
    print(f"\n--- 簇 {c}，共 {subset.shape[0]} 个 ---")
    print(subset[feature_cols].mean())


submit = features[['fqdn_no', 'cluster']].rename(columns={'cluster': 'label'})
submit.to_csv('result_b.csv', index=False)
print("\n结果已保存为 result_B.csv")