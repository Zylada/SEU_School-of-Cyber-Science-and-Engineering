# 网络流特征提取工具

从 PCAP 文件中提取网络流特征，输出为 CSV 文件。可直接提取所选文件夹下所有pcap文件。

## 快速开始

### 1. 输入数据

**文件放置位置**：`data/` 目录

在 `data/` 文件夹中放入要分析的 `.pcap` 文件，例如：
- `data/test.pcap`
- `data/msedge.exe.pcap`

### 2. 运行程序

如果pcap存放位置不是默认同级文件data，则要：
修改main函数95行
default_path = os.path.join(os.path.dirname(__file__), "data")
将‘data’位置替换为自己的文件位置。

修改好之后直接运行：

```bash
python main.py
```

### 3. 输出结果

**文件输出位置**：`result/` 目录

运行完毕后，会在 `result/` 文件夹中生成对应的 `.csv` 文件，例如：
- `result/test.csv`
- `result/msedge.exe.csv`


## 4. 输出说明

输出文件为流级特征表，每一行代表一条流。

常见字段包括：

- `Flow ID`
- `Src IP`
- `Src Port`
- `Dst IP`
- `Dst Port`
- `Protocol`
- `Flow Pkt Num`
- `Flow Duration(ms)`
- `Flow IAT Mean`
- `FIN Count`
- `SYN Count`
- `ACK Count`
- `Fwd Pkts With Pld`
- `Bwd Pkts With Pld`

说明：

- `Protocol = 6` 表示 TCP
- `Protocol = 17` 表示 UDP
- 对 UDP 不适用的 TCP 专属字段通常为 `0`

完整列名定义见 [FlowFeature.py]。

## 5. TCP/UDP 支持说明

当前代码已经支持 TCP 和 UDP 共存提取：

- TCP 和 UDP 都会进入统一流重组流程
- 流 ID 中包含协议号，避免 TCP/UDP 相同四元组互相混淆
- TCP 使用 `FIN/RST` 等逻辑辅助结束流
- UDP 主要依靠超时和最终清理结束流

相关实现位置：

- 协议解析：[PacketReader.py]
- 流 ID 定义：[BasicPacketInfo.py]
- 流生命周期管理：[FlowGenerator.py]

## 6. 已验证结果

本项目已使用完成一次实际测试，成功生成

测试中提取到了 TCP 和 UDP 两类流。

## 7. 注意事项

- 输入文件
- 当前解析逻辑只处理 IPv4 的 TCP/UDP
- 如果抓包文件非常大，程序会一次性读入内存
- `label.py` 依赖 `pandas`，主特征提取流程不依赖 `pandas`

