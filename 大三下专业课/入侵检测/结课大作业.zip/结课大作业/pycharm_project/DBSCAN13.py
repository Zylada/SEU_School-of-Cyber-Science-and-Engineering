# ===== DBSCAN_13features.py：13 特征 + DBSCAN (强制 5 簇输出) =====
import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN, KMeans
from sklearn.preprocessing import StandardScaler
from sklearn import metrics

# ==================== 路径 ====================
base = r'C:\Users\19966\Desktop\入侵检测\结课大作业\我的任务\dns3\question\6_question'
# =============================================

print("正在读取数据...")
fqdn_all = pd.read_csv(f"{base}/fqdn.csv")
access_all = pd.read_csv(f"{base}/access.csv")
flint_all = pd.read_csv(f"{base}/flint.csv")
ip_all = pd.read_csv(f"{base}/ip.csv")

# ---------- 聚合 access 特征 ----------
print("正在聚合 access 特征...")
access_feat = access_all.groupby('fqdn_no').agg(
    total_request_cnt=('request_cnt', 'sum'),
    unique_ips=('encoded_ip', 'nunique'),
    active_hours=('hour', 'nunique'),
    request_variance=('request_cnt', 'var')
).reset_index()

# ---------- 聚合 flint 特征 ----------
print("正在聚合 flint 特征...")
flint_feat = flint_all.groupby('fqdn_no').agg(
    flint_records=('fqdn_no', 'count'),
    avg_ttl=('ttl', 'mean'),
    ttl_std=('ttl', 'std'),
    unique_resolved_values=('encoded_value', 'nunique')
).reset_index()

# ---------- 聚合 IP 特征 ----------
print("正在聚合 IP 特征...")
ip_info = ip_all[['encoded_ip', 'country', 'city', 'isp']]
access_with_ip = access_all.merge(ip_info, on='encoded_ip', how='left')

ip_feat = access_with_ip.groupby('fqdn_no').agg(
    num_countries=('country', 'nunique'),
    overseas_ratio=('country', lambda x: (x != '中国').mean()),
    num_cities=('city', 'nunique'),
    num_isps=('isp', 'nunique'),
    cloud_ratio=('isp', lambda x: x.str.lower().str.contains(
        'amazon|google|cloud|azure|tencent|aliyun', na=False).mean())
).reset_index()

ip_feat.fillna({'num_countries': 0, 'overseas_ratio': 0,
                'num_cities': 0, 'num_isps': 0, 'cloud_ratio': 0}, inplace=True)

# ---------- 拼接所有特征 ----------
features = fqdn_all[['fqdn_no']].merge(access_feat, on='fqdn_no', how='left')
features = features.merge(flint_feat, on='fqdn_no', how='left')
features = features.merge(ip_feat, on='fqdn_no', how='left')
features.fillna(0, inplace=True)

print(f"特征矩阵形状: {features.shape}")

# ---------- 特征列 ----------
feature_cols = [
    'total_request_cnt', 'unique_ips', 'active_hours', 'request_variance',
    'flint_records', 'avg_ttl', 'ttl_std', 'unique_resolved_values',
    'num_countries', 'overseas_ratio', 'num_cities', 'num_isps', 'cloud_ratio'
]

# ---------- 标准化 ----------
X = features[feature_cols].values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ============ DBSCAN 参数（基于 8 特征的最优值，13 特征下先试跑）============
best_eps = 0.5
best_min_samples = 10

print(f"\n使用 eps={best_eps}, min_samples={best_min_samples} 进行 DBSCAN...")
dbscan = DBSCAN(eps=best_eps, min_samples=best_min_samples, n_jobs=-1)
raw_labels = dbscan.fit_predict(X_scaled)

n_clusters = len(set(raw_labels)) - (1 if -1 in raw_labels else 0)
n_noise = list(raw_labels).count(-1)
print(f"自然簇数: {n_clusters}, 噪声点: {n_noise}")

# ============ 强制输出为 5 簇 ============
# 如果自然簇数不等于 5，我们使用与之前相同的后处理：
#   1. 对非噪声点跑 KMeans (5 簇)
#   2. 将噪声点分配到最近的 KMeans 质心
if n_clusters != 5:
    print("自然簇数不等于 5，执行后处理...")
    mask_non_noise = raw_labels != -1
    X_non_noise = X_scaled[mask_non_noise]

    km = KMeans(n_clusters=5, random_state=42, n_init=10)
    new_labels = km.fit_predict(X_non_noise)

    # 创建最终标签数组，初始全部为 -1
    final_labels = np.full(len(raw_labels), -1, dtype=int)
    final_labels[mask_non_noise] = new_labels

    # 噪声点分配到最近质心
    if (~mask_non_noise).sum() > 0:
        from scipy.spatial.distance import cdist

        noise_idx = np.where(~mask_non_noise)[0]
        dists = cdist(X_scaled[noise_idx], km.cluster_centers_, metric='euclidean')
        noise_labels = np.argmin(dists, axis=1)
        final_labels[noise_idx] = noise_labels

    features['label'] = final_labels
else:
    # 自然 5 簇，直接把 -1 换成某个簇编号（这里分配到数量最少的簇，避免破坏平衡）
    # 更简单的做法：将 -1 视为一个新簇，但需要 5 簇，所以把噪声点分配到最近的 DBSCAN 核心点？
    # 我们采用 KMeans 分配噪声点的方式，确保标签为 0-4
    print("自然形成 5 簇，处理噪声点...")
    mask_non_noise = raw_labels != -1
    # 用 DBSCAN 非噪声点的标签直接赋值
    final_labels = raw_labels.copy()
    if (~mask_non_noise).sum() > 0:
        # 对非噪声点训练一个 KMeans 只是为了给噪声点分配簇，保持原簇标签不变
        from sklearn.neighbors import KNeighborsClassifier

        knn = KNeighborsClassifier(n_neighbors=1)
        knn.fit(X_scaled[mask_non_noise], raw_labels[mask_non_noise])
        noise_pred = knn.predict(X_scaled[~mask_non_noise])
        final_labels[~mask_non_noise] = noise_pred
    features['label'] = final_labels

# 确保标签为 0-4 的整数
features['label'] = features['label'].astype(int)
unique_labels = sorted(features['label'].unique())
print(f"最终簇数: {len(unique_labels)}, 标签分布:")
print(features['label'].value_counts().sort_index())

# 轮廓系数
sil = metrics.silhouette_score(X_scaled, features['label'])
print(f"轮廓系数: {sil:.4f}")

# ---------- 保存提交文件 ----------
submit = features[['fqdn_no', 'label']]
submit.to_csv('result_dbscan_13.csv', index=False)
print("\n结果已保存为 result_dbscan_13.csv")