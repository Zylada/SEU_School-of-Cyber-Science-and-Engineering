#include"RSA.h"
int main()
{
    BigInt p("571222173285415169225506842409"), q("415924872698612520126277439911"), N, n, a("1"), b("2");
    BigInt d, e;
    BigInt m, s;
    N = p * q;
    s = gcd(p - a, q - a);
    n = s * ((p - a) / s) * ((q - a) / s);
    cout << "n: " << n << endl;
    cout << "N: " << N << endl;
    while (1) {
        cout << "请输入公钥e：" << endl;
        cin >> e;
        cout << "gcd(e,n): " << gcd(e, n) << endl;
        if (gcd(e, n).values == "1" && (n - e).flag == true) 
        {

            d = mod_inverse(e, n);
            cout << "私钥d为：" << d << endl;
            cout << "请输入需要加密的字符：" << endl;
            cin >> m;
            BigInt t;
            cout << "加密：" << mod_fast(m, e, N) << endl;
            cout << "解密：" << mod_fast(mod_fast(m, e, N), d, N) << endl;
        }
        else {
            cout << "d和N非互素或者非1<e<n！" << endl;
        }
    }

    return 0;
}